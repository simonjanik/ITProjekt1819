package de.hdm.itprojekt.server.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Vector;

import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.bo.User;

/**
 * Die Klasse UserMapper bildet <code>User</code> Objekte auf eine relationale
 * Datenbank ab. Ebenfalls ist es möglich aus Datenbank-Tupel Java-Objekte zu
 * erzeugen.
 * 
 * Zur Verwaltung der Objekte implementiert die Mapper-Klasse entsprechende
 * Methoden wie z.B. (insert, delete).
 */

public class UserMapper {

	/**
	 * Die Klasse UserMapper wird nur einmal instantiiert (Singleton-Eigenschaft).
	 * Damit diese Eigenschaft erfüllt werden kann, wird zunächst eine Variable mit
	 * dem Schlüsselwort static und dem Standardwert null erzeugt. Sie speichert die
	 * Instanz dieser Klasse.
	 */

	private static UserMapper userMapper = null;

	/**
	 * Ein geschützter Konstruktor verhindert das erneute erzeugen von weiteren
	 * Instanzen dieser Klasse durch <code>new</code>.
	 */

	protected UserMapper() {

	}

	/**
	 * Methode zum Sicherstellen der Singleton-Eigenschaft. Diese sorgt dafür, dass
	 * nur eine einzige Instanz der UserMapper-Klasse existiert. Aufgerufen wird die
	 * Klasse somit über UserMapper.userMapper() und nicht über den New-Operator.
	 * 
	 * @return Das <code/>userMapper<code/> Objekt.
	 */

	public static UserMapper UserMapper() {
		if (userMapper == null) {
			userMapper = new UserMapper();
		}
		return userMapper;
	}

	public User findByID(int id) throws MapperException {
		// DB-Verbindung holen
		Connection con = DBConnection.getConnection();

		try {

			PreparedStatement findByID = con
					.prepareStatement("SELECT * FROM itprojekt.user WHERE userid=? AND DeleteDate IS NULL;");
			findByID.setInt(1, id);

			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findByID.executeQuery();

			// stmt.executeQuery(
			// "SELECT id, firstName, lastName, nickName FROM user "+ "WHERE id=" + id +
			// "ORDER BY nickName");

			/*
			 * Da id Primärschlüssel ist, kann max. nur ein Tupel zurückgegeben werden.
			 * Prüfe, ob ein Ergebnis vorliegt.
			 */
			if (rs.next()) {
				// Ergebnis-Tupel in Objekt umwandeln

				return new User(rs.getInt("userid"), rs.getTimestamp("creationDate"), rs.getString("firstName"),
						rs.getString("lastName"), rs.getString("nickName"));
			} else
				return null;
		} catch (SQLException e) {
			throw new MapperException(e);
		}

	}

	public User findByNickname(String nickName) throws MapperException {
		// DB-Verbindung holen
		Connection con = DBConnection.getConnection();

		try {

			PreparedStatement findByNickname = con
					.prepareStatement("SELECT * FROM itprojekt.user WHERE nickName=? AND DeleteDate IS NULL;");
			findByNickname.setString(1, nickName);

			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findByNickname.executeQuery();

			/*
			 * Da id Primärschlüssel ist, kann max. nur ein Tupel zurückgegeben werden.
			 * Prüfe, ob ein Ergebnis vorliegt.
			 */
			if (rs.next()) {
				// Ergebnis-Tupel in Objekt umwandeln
				User u = new User(rs.getInt("userid"), rs.getTimestamp("creationDate"), rs.getString("firstName"),
						rs.getString("lastName"), rs.getString("nickName"));
				;
				return u;
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}

		return null;
	}

	public User insert(User u) throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			PreparedStatement insert = con
					.prepareStatement("INSERT INTO itprojekt.user(firstName,lastName,nickName,email) VALUES (?,?,?,?);");
			// Jetzt erst erfolgt die tatsächliche Einfügeoperation
			insert.setString(1, u.getFirstName());
			insert.setString(2, u.getLastName());
			insert.setString(3, u.getNickName());
			insert.setString(4, u.getEmail().toUpperCase());
			insert.executeUpdate();

			PreparedStatement getnewUser = con
					.prepareStatement("SELECT *FROM itprojekt.user ORDER BY creationDate DESC LIMIT 1;");
			ResultSet rs = getnewUser.executeQuery();
			if (rs.next()) {
				return new User(rs.getInt("userID"), rs.getTimestamp("creationDate"), rs.getString("firstName"),
						rs.getString("lastName"), rs.getString("nickName"));
			}
		}

		catch (SQLException e) {
			throw new MapperException(e);
		}

		/*
		 * Rückgabe, des evtl. korrigierten Users.
		 * 
		 * HINWEIS: Da in Java nur Referenzen auf Objekte und keine physischen Objekte
		 * übergeben werden, wäre die Anpassung des User-Objekts auch ohne diese
		 * explizite Rückgabe au�erhalb dieser Methode sichtbar. Die explizite Rückgabe
		 * von u ist eher ein Stilmittel, um zu signalisieren, dass sich das Objekt
		 * evtl. im Laufe der Methode verändert hat.
		 * 
		 * @author Thies
		 */
		return null;
	}

	public User update(User u) throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			PreparedStatement update = con
					.prepareStatement("UPDATE itprojekt.user SET firstName=? ,lastName=? ,nickName=? WHERE userid=?;");
			update.setString(1, u.getFirstName());
			update.setString(2, u.getLastName());
			update.setString(3, u.getNickName());
			update.setInt(4, u.getId());
			update.executeUpdate();

			PreparedStatement getUpdatedUser = con.prepareStatement("SELECT * FROM itprojekt.user WHERE userID=?;");
			getUpdatedUser.setInt(1, u.getId());
			ResultSet rs = getUpdatedUser.executeQuery();
			if (rs.next()) {
				return new User(rs.getInt("userID"), rs.getTimestamp("creationDate"), rs.getString("firstName"),
						rs.getString("lastName"), rs.getString("nickName"));
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		// Um Analogie zu insert(User u) zu wahren, geben wir u zurück
		return null;
	}

	/**
	 * Löschen der Daten eines <code>User</code>-Objekts aus der Datenbank.
	 * 
	 * @param u das aus der DB zu löschende "Objekt"
	 */

	public void deleteByUserID(int id) throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			PreparedStatement deleteUserByUserID = con
					.prepareStatement("UPDATE itprojekt.user SET `DeleteDate`=NOW() WHERE `UserID`=?;");
			deleteUserByUserID.setInt(1, id);
			deleteUserByUserID.executeUpdate();
			/*
			 * Das Konto des Users wird lokalisiert in der Datenbank und das Konto wird
			 * gelöscht
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

	public Vector<User> findAllByPeriod(Timestamp startDate, Timestamp endDate) throws MapperException {
		// Ergebnisvektor vorbereiten
		Vector<User> result = new Vector<User>();

		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement findAllUserByPeriod = con.prepareStatement("SELECT * FROM itprojekt.user"
//					+ "WHERE creationDate BETWEEN" + startDate + "and" + endDate 
					+ ";");
			ResultSet rs = findAllUserByPeriod.executeQuery();

			// Für jeden Eintrag im Suchergebnis wird nun ein Customer-Objekt
			// erstellt.
			while (rs.next()) {
				User u = new User(rs.getInt("userid"), rs.getTimestamp("creationDate"), rs.getString("firstName"),
						rs.getString("lastName"), rs.getString("nickName"));

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.addElement(u);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}

		// Ergebnisvektor zurückgeben
		return result;
	}

	public Vector<String> findAllNickNames() throws MapperException {
		Vector<String> result = new Vector<>();
		Connection con = DBConnection.getConnection();
		try {

			PreparedStatement stm = con
					.prepareStatement("SELECT nickname FROM itprojekt.user  where DeleteDate IS NULL;");
			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				result.add(rs.getString("nickname"));
			}

		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}

		return result;
	}

	public Vector<User> findAllUsers() throws MapperException {
		Vector<User> result = new Vector<>();
		Connection con = DBConnection.getConnection();
		try {

			PreparedStatement stm = con.prepareStatement("SELECT * FROM itprojekt.user where DeleteDate IS NULL order by nickname;");
			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				User u = new User(rs.getInt("userid"), rs.getTimestamp("creationDate"), rs.getString("firstName"),
						rs.getString("lastName"), rs.getString("nickName"));

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.addElement(u);
			}

		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}

		return result;
	}

	public User findByEmail(User u) throws MapperException {

		Connection con = DBConnection.getConnection();

		try {
			
			PreparedStatement stm = con.prepareStatement("Select * from itprojekt.user where email='"+u.getEmail().toUpperCase()+"' and deleteDate is null;");
			ResultSet rs = stm.executeQuery();
			if(rs.next()) {
				return new User(rs.getInt("userid"), rs.getTimestamp("creationDate"), rs.getString("firstName"),
						rs.getString("lastName"), rs.getString("nickName"),rs.getString("email"));
			}else {
				return null;
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}
	}

}
