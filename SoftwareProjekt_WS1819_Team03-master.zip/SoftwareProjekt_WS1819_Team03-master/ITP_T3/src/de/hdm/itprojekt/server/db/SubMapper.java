package de.hdm.itprojekt.server.db;

import java.sql.Connection;
import java.sql.Timestamp;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Vector;

import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.bo.Sub;

/**
 * Die Klasse SubMapper bildet <code>Sub</code> Objekte auf eine relationale
 * Datenbank ab. Ebenfalls ist es möglich aus Datenbank-Tupel Java-Objekte zu
 * erzeugen.
 * 
 * Zur Verwaltung der Objekte implementiert die Mapper-Klasse entsprechende
 * Methoden wie z.B. (insert, delete).
 */

public class SubMapper {

	/**
	 * Die Klasse SubMapper wird nur einmal instantiiert (Singleton-Eigenschaft).
	 * Damit diese Eigenschaft erfüllt werden kann, wird zunächst eine Variable mit
	 * dem Schlüsselwort static und dem Standardwert null erzeugt. Sie speichert die
	 * Instanz dieser Klasse.
	 */

	private static SubMapper subMapper = null;

	/**
	 * Ein geschützter Konstruktor verhindert das erneute erzeugen von weiteren
	 * Instanzen dieser Klasse durch <code>new</code>.
	 */

	protected SubMapper() {

	}

	/**
	 * Methode zum Sicherstellen der Singleton-Eigenschaft. Diese sorgt dafür, dass
	 * nur eine einzige Instanz der SubMapper-Klasse existiert. Aufgerufen wird die
	 * Klasse somit über SubMapper.subMapper() und nicht über den New-Operator.
	 * 
	 * @return Das <code/>subMapper<code/> Objekt.
	 */

	public static SubMapper SubMapper() {
		if (subMapper == null) {
			subMapper = new SubMapper();
		}
		return subMapper;
	}

	public Sub findSubBySubID(int id) throws MapperException {
		Connection con = DBConnection.getConnection();
		Sub s = null;
		try {
			PreparedStatement findSubBySUBID = con.prepareStatement("SELECT * FROM itprojekt.sub WHERE subid=? AND DeleteDate IS NULL;");
			findSubBySUBID.setInt(1, id);
			// Statement ausfüllen und als Query an die DB schicken

			ResultSet rs = findSubBySUBID.executeQuery();
			if (rs.next()) {
				s = new Sub(rs.getInt("subid"), rs.getTimestamp("creationDate"), rs.getInt("userID"),
						rs.getInt("pinboardID"));
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return s;
	}

	public Vector<Sub> findSubByUserID(int id) throws MapperException {
		Connection con = DBConnection.getConnection();
		Vector<Sub> result = new Vector<Sub>();
		try {
			PreparedStatement stm = con.prepareStatement("SELECT * FROM itprojekt.sub WHERE userid=? AND DeleteDate IS NULL;");
			stm.setInt(1, id);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				result.add(new Sub(rs.getInt("subid"), rs.getTimestamp("creationdate"), rs.getInt("userid"),
						rs.getInt("pinboardid")));
			}

		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}
		return result;
	}

	public Vector<Sub> findSubByPinboardID(int id) throws MapperException {
		Connection con = DBConnection.getConnection();
		Vector<Sub> result = new Vector<Sub>();
		try {
			PreparedStatement stm = con.prepareStatement("SELECT * FROM itprojekt.sub WHERE pinboardID=? AND DeleteDate IS NULL;");
			stm.setInt(1, id);

			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				result.add(new Sub(rs.getInt("subid"), rs.getTimestamp("creationdate"), rs.getInt("userid"),
						rs.getInt("pinboardid")));
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}
		return result;
	}

	public Vector<Sub> findAllSubByUserIDAndPeriod(int id, Timestamp startDate, Timestamp endDate) throws MapperException {
		Connection con = DBConnection.getConnection();
		Sub s = null;
		Vector<Sub> result = new Vector<Sub>();
		try {
			PreparedStatement findAllSubByUserID = con.prepareStatement(
					"SELECT * FROM itprojekt.sub "
					+ "where userid=? "
//					+ "and pinboardID <> ? "
					+ "order by subid;");
			findAllSubByUserID.setInt(1, id);
//			findAllSubByUserID.setInt(2, id);
//			findAllSubByUserID.setTimestamp(2, startDate);
//			findAllSubByUserID.setTimestamp(3, endDate);

			ResultSet rs = findAllSubByUserID.executeQuery();

			while (rs.next()) {
				s = new Sub(rs.getInt("subid"), rs.getTimestamp("creationdate"), rs.getInt("userID"),
						rs.getInt("pinboardID"),rs.getTimestamp("deleteDate"));
				result.addElement(s);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return result;
	}

	public Vector<Sub> findAllSubByPinnboardIDAndPeriod(int pinID, int userID, Timestamp startDate, Timestamp endDate) throws MapperException {
		Connection con = DBConnection.getConnection();
		Sub s = null;
		Vector<Sub> result = new Vector<Sub>();
		try {
			PreparedStatement findAllSubByPinboardID = con.prepareStatement(
					"SELECT * From itprojekt.sub "
					+ "WHERE pinboardID=? "
//					+ "and userID <> ?"
//					+ "and creationDate BETWEEN ? and ? "
					+ "Order By pinboardID;");
			findAllSubByPinboardID.setInt(1, pinID);
//			findAllSubByPinboardID.setInt(2, userID);
//			findAllSubByPinboardID.setTimestamp(2, startDate);
//			findAllSubByPinboardID.setTimestamp(3, endDate);

			ResultSet rs = findAllSubByPinboardID.executeQuery();

			while (rs.next()) {
				s = new Sub(rs.getInt("subid"), rs.getTimestamp("creationdate"), rs.getInt("userID"),
						rs.getInt("pinboardID"),rs.getTimestamp("deleteDate"));
				

				result.addElement(s);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return result;
	}


	public Sub insertSub(Sub s) throws MapperException {
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement insertSub = con
					.prepareStatement("INSERT INTO itprojekt.sub (userID, pinboardID) Values (?,?);");
			insertSub.setInt(1, s.getUserID());
			insertSub.setInt(2, s.getPinboardID());
			insertSub.executeUpdate();

			PreparedStatement getNewSub = con
					.prepareStatement("Select * FROM itprojekt.sub ORDER BY subID DESC LIMIT 1;");
			ResultSet rs = getNewSub.executeQuery();
			if (rs.next()) {
				return new Sub(rs.getInt("subid"), rs.getTimestamp("creationDate"), rs.getInt("userid"),
						rs.getInt("pinboardid"));
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return null;
	}

	public void deletSubBySubID(int id) throws MapperException {
		Connection con = DBConnection.getConnection();
		try {
			
			PreparedStatement deletSub = con.prepareStatement("UPDATE `itprojekt`.`sub` SET `DeleteDate`=NOW() WHERE `SubID`=?;");
			deletSub.setInt(1, id);

			deletSub.executeUpdate();
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

	public void deletAllSubByUserID(int id) throws MapperException {
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement deletSub = con.prepareStatement("UPDATE `itprojekt`.`sub` SET `DeleteDate`=NOW() WHERE `UserID`=?;");
			deletSub.setInt(1, id);

			deletSub.executeUpdate();
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

	public void deleteAllSubscribingSubsByPinboardID(int pinboardId) throws MapperException {
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement deletSubscSub = con.prepareStatement("UPDATE `itprojekt`.`sub` SET `DeleteDate`=NOW() WHERE `PinboardID`=?;");
			deletSubscSub.setInt(1, pinboardId);

			deletSubscSub.executeUpdate();
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

}