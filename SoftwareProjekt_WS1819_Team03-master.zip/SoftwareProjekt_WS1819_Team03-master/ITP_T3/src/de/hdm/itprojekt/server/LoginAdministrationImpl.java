package de.hdm.itprojekt.server;

import java.sql.Date;



import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import de.hdm.itprojekt.server.db.UserMapper;
import de.hdm.itprojekt.shared.EditorAdministration;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;

import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.User;
import de.hdm.itprojekt.shared.LoginAdministration;

public class LoginAdministrationImpl extends RemoteServiceServlet implements LoginAdministration {

	private static LoginAdministrationImpl loginAdministration = null;
	private EditorAdministrationImpl editorAdministration = null;
//	

	public LoginAdministrationImpl() throws IllegalArgumentException {

	}

	public static LoginAdministrationImpl getLoginAdministration() {
		if (loginAdministration == null) {
			loginAdministration = new LoginAdministrationImpl();
		}
		return loginAdministration;
	}

	public void init() throws IllegalArgumentException {
		EditorAdministrationImpl e = new EditorAdministrationImpl();
		e.init();
		this.editorAdministration = e;
	}

//	Beim ersten Login für jede Session
	public User login(String requestUri) {

		UserService userService = UserServiceFactory.getUserService();
		com.google.appengine.api.users.User clientApiUser = userService.getCurrentUser();
		User clientBoUser = new User();

		if (clientApiUser != null) {
			clientBoUser.setIsLoggedIn(true);
			clientBoUser.setEmail(clientApiUser.getEmail());
			 clientBoUser.setNickName(clientApiUser.getNickname());
			clientBoUser.setLogoutURL(userService.createLogoutURL(requestUri));

		} else {
			clientBoUser.setIsLoggedIn(false);
			clientBoUser.setLoginURL(userService.createLoginURL(requestUri));
		}

		return clientBoUser;

	}

	public User checkUserKnown(User clientBoUser) throws MapperException, NotLoggedInException {
		if (clientBoUser != null) {
			return editorAdministration.findByEmail(clientBoUser);
		}
		return null;
	}

	public User registerUser(User clientBoUser) throws MapperException,NotLoggedInException {
		if (clientBoUser != null) {
			return editorAdministration.addUser(clientBoUser);
		}
		return null;
	}

	
	public void checkLogin() throws NotLoggedInException {
		UserService userservice = UserServiceFactory.getUserService();
		if(userservice.getCurrentUser() == null) {
			throw new NotLoggedInException("Nicht mehr Eingeloggt");
		}
		
	}

	

}
