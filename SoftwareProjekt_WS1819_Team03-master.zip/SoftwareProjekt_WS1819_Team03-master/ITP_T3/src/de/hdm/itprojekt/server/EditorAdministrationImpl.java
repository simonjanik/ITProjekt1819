package de.hdm.itprojekt.server;

import java.sql.SQLException;
import java.util.Collections;
import java.util.Date;
import java.util.Vector;

import com.google.appengine.api.users.UserService;
import com.google.appengine.api.users.UserServiceFactory;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import de.hdm.itprojekt.server.db.*;
import de.hdm.itprojekt.shared.EditorAdministration;
import de.hdm.itprojekt.shared.LoginAdministration;
import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.*;

public class EditorAdministrationImpl extends RemoteServiceServlet implements EditorAdministration {

	private PostMapper postMapper = null;
	private CommentMapper commentMapper = null;
	private LikeMapper likeMapper = null;
	private UserMapper userMapper = null;
	private SubMapper subMapper = null;
	private PinboardMapper pinboardMapper = null;

	private LoginAdministrationImpl loginAdministration = null;

//	Default-Konstruktor
	public EditorAdministrationImpl() {

	}

	@Override
	public void init() throws IllegalArgumentException {
		this.postMapper = PostMapper.PostMapper();
		this.commentMapper = CommentMapper.CommentMapper();
		this.likeMapper = LikeMapper.LikeMapper();
		this.userMapper = UserMapper.UserMapper();
		this.subMapper = SubMapper.SubMapper();
		this.pinboardMapper = PinboardMapper.PinboardMapper();

		loginAdministration = LoginAdministrationImpl.getLoginAdministration();

	}



	public Like addLike(Like like) throws NotLoggedInException, MapperException {

		loginAdministration.checkLogin();
		
		if (like != null) {
			Like tempLike = new Like();
			tempLike = likeMapper.insertLike(like);
			tempLike.setLikerNickName(userMapper.findByID(tempLike.getUserID()).getNickName());
			return tempLike;
		}
		return null;

	}

	public void deleteLike(int likeID) throws MapperException,NotLoggedInException {
		loginAdministration.checkLogin();
		likeMapper.deleteLike(likeID);
	}

	public Vector<Like> findAllLikesByPost(int postId) throws MapperException, NotLoggedInException {
		Vector<Like> result = likeMapper.findAllByPost(postId);
		for (int i = 0; i < result.size(); i++) {
			User tempUser = userMapper.findByID(result.elementAt(i).getUserID());
			result.elementAt(i).setLikerNickName(tempUser.getNickName());
		}

		return result;
	}

	/*
	 * 
	 * Comment
	 * 
	 */

	public Comment addComment(Comment comment) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		if (comment != null) {
			Comment newComment = commentMapper.insert(comment);
			User tempAuthor = userMapper.findByID(newComment.getAuthorID());
			newComment.setAuthorNickName(tempAuthor.getNickName());

			return newComment;
		}
		return null;
	}

	public Comment updateComment(Comment updatedComment) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		if (updatedComment != null) {
			Comment newComment = commentMapper.update(updatedComment);
			User tempAuthor = userMapper.findByID(newComment.getAuthorID());
			newComment.setAuthorNickName(tempAuthor.getNickName());

			return newComment;
		}
		return null;
	}

	public void deleteComment(int commentID) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		commentMapper.delete(commentID);
	}

	public Vector<Comment> findCommentsByPost(int postID) throws MapperException, NotLoggedInException {
		Vector<Comment> result = commentMapper.findByPost(postID);

		for (int i = 0; i < result.size(); i++) {
			User tempUser = userMapper.findByID(result.get(i).getAuthorID());
			result.elementAt(i).setAuthorNickName(tempUser.getNickName());
		}

		return result;
	}

	/*
	 * 
	 * Post
	 * 
	 */

	public Post addPostToPinboard(Post post) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		if (post != null) {

			Post newPost = postMapper.insert(post);
			int userId = pinboardMapper.findUserIDByPinboardID(newPost.getPinboardID());
			newPost.setAuthorNickName(userMapper.findByID(userId).getNickName());
			return newPost;
		}
		return null;
	}

	public Post updatePost(Post post) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		if (post != null) {
			Post newPost = postMapper.update(post);

			int userId = pinboardMapper.findUserIDByPinboardID(newPost.getPinboardID());
			newPost.setAuthorNickName(userMapper.findByID(userId).getNickName());
			return newPost;
		}
		return null;
	}

	public void deletePost(int postID) throws MapperException, NotLoggedInException {
		
		loginAdministration.checkLogin();
		
//		Löschen aller zugehörigen Likes		
		likeMapper.deleteAllByPost(postID);

//		Löschen aller zugehörigen Kommentare
		commentMapper.delete(postID);

//		Löschen des Posts
		postMapper.delete(postID);
	}

	@Override
	public Vector<Post> findPostsByPinboard(int pinboardID) throws MapperException, NotLoggedInException {
		Vector<Post> result = postMapper.findByPinboardId(pinboardID);

		for (int i = 0; i < result.size(); i++) {
			int userId = pinboardMapper.findUserIDByPinboardID(result.elementAt(i).getPinboardID());
			result.elementAt(i).setAuthorNickName(userMapper.findByID(userId).getNickName());
		}
		return result;
	}

	/*
	 * 
	 * Sub
	 * 
	 */

	public Sub addSub(Sub sub) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		if (sub != null) {
			if (sub.getPinboardID() == 0 && sub.getSubscribedUserNickName() != null) {
				// PinID des Users muss noch hinzugefügt werden

				int subscribedUserId = userMapper.findByNickname(sub.getSubscribedUserNickName()).getId();
				int subscribedPinboardId = pinboardMapper.findbyUserID(subscribedUserId).getId();
				Sub tempSub = new Sub(sub.getUserID(), subscribedPinboardId);

				Sub newSub = subMapper.insertSub(tempSub);
				newSub.setSubscribedUserNickName(sub.getSubscribedUserNickName());

				return newSub;
			}
		}
		return null;
	}


	public void deleteSub(int subID) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		subMapper.deletSubBySubID(subID);
	}

	public Vector<Sub> findSubsByUser(int userID) throws MapperException, NotLoggedInException {
		Vector<Sub> result = subMapper.findSubByUserID(userID);

		for (int i = 0; i < result.size(); i++) {
			int subscribedUserId = pinboardMapper.findUserIDByPinboardID(result.get(i).getPinboardID());
			result.elementAt(i).setSubscribedUserNickName(userMapper.findByID(subscribedUserId).getNickName());
		}

		return result;
	}

	/*
	 * 
	 * User
	 * 
	 */

	public User addUser(User user) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		if (user != null) {
			User newUser = userMapper.insert(user);
			
			Pinboard newPinboard = pinboardMapper.insert(new Pinboard(newUser.getId()));
			subMapper.insertSub(new Sub(newUser.getId(), newPinboard.getId()));

			return newUser;
		}
		return null;
	}

	public User updateUser(User updatedUser) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		if (updatedUser != null) {
			User newUser = userMapper.update(updatedUser);
			return newUser;
		}
		return null;
	}

	public void deleteUser(int userId) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		
		// Mein gesamtes Pinboard heranziehen
		Pinboard pin = pinboardMapper.findbyUserID(userId);

		// Alle Posts, die ich verfasst habe heranziehen
		Vector<Post> allePosts = postMapper.findByPinboardId(pin.getId());

		// Alle likes, die ich getätigt habe, werden gelöscht

		likeMapper.deleteAllByUser(userId);

		// Alle Kommentare, die ich geschrieben habe, werden gelöscht.
		commentMapper.deleteAllByUser(userId);

		int pinboardId = pinboardMapper.findbyUserID(userId).getId();
		postMapper.deleteAllByPinboardID(pinboardId);

		subMapper.deletAllSubByUserID(userId);

		// Alle Likes und Comments von anderen, die zu meinen Beiträgen verfasst wurden,
		// werden gelöscht
		for (int i = 0; i < allePosts.size(); i++) {
			likeMapper.deleteAllByPost(allePosts.elementAt(i).getId());
			commentMapper.deleteAllByPost(allePosts.elementAt(i).getId());
		}
		// Alle Posts löschen
		postMapper.deleteAllByPinboardID(pin.getId());

		// Mein eigenes Pinboard löschen
		pinboardMapper.deleteByPinboardID(pin.getId());

		subMapper.deleteAllSubscribingSubsByPinboardID(pinboardId);

		pinboardMapper.deleteByPinboardID(pinboardId);

		userMapper.deleteByUserID(userId);
	}

	public User findUserByID(int ID) throws MapperException, NotLoggedInException {
		return userMapper.findByID(ID);
	}

	public Vector<String> findAllUserNickNames() throws MapperException, NotLoggedInException {
		return userMapper.findAllNickNames();
	}

	public User findUserByNickname(String nn) throws MapperException, NotLoggedInException {
		User newUser = userMapper.findByNickname(nn);
		return newUser;
	}

	public User findUserByPinboardID(int pinId) throws MapperException, NotLoggedInException {
		// TODO Auto-generated method stub
		int userid = pinboardMapper.findByID(pinId).getUserID();
		return userMapper.findByID(userid);
	}

	public Vector<User> findAllUsers() throws MapperException, NotLoggedInException {
		return userMapper.findAllUsers();
	}

	/*
	 * 
	 * Pinboard
	 * 
	 */


	@Override
	public void deletePinboard(int pinboardID) throws MapperException, NotLoggedInException {
		loginAdministration.checkLogin();
		Vector<Post> postsOnPinboard = postMapper.findByPinboardId(pinboardID);

		for (int i = 0; i < postsOnPinboard.size(); i++) {
			likeMapper.deleteAllByPost(postsOnPinboard.get(i).getId());
			commentMapper.deleteAllByPost(postsOnPinboard.get(i).getId());
		}

		postMapper.deleteAllByPinboardID(pinboardID);

	}

	@Override
	public int findPinboardIDByUserID(int userid) throws MapperException, NotLoggedInException {
		// TODO Auto-generated method stub
		return pinboardMapper.findbyUserID(userid).getId();
	}

	@Override
	public Vector<Post> getPostForNewsFeed(User u) throws MapperException, NotLoggedInException {
		// TODO Auto-generated method stub

		Vector<Post> result = new Vector<>();

		Vector<Sub> subscriptons = subMapper.findSubByUserID(u.getId());

		for (int i = 0; i < subscriptons.size(); i++) {

			int pinID = subscriptons.get(i).getPinboardID();

			Vector<Post> postOnSubPinboard = postMapper.findByPinboardId(pinID);

			for (int j = 0; j < postOnSubPinboard.size(); j++) {

				int userid = pinboardMapper.findUserIDByPinboardID(postOnSubPinboard.get(j).getPinboardID());
				postOnSubPinboard.get(j).setAuthorNickName(userMapper.findByID(userid).getNickName());

				result.add(postOnSubPinboard.get(j));
			}

		}
		Collections.reverse(sortVectorbyDate(result));
		
		if (result.size() > 5) {
			result.setSize(5);
		}
		
		return result;
	}

	// SORT
	public Vector<Post> sortVectorbyDate(Vector<Post> inputVector) {

		for (int i = 1; i < inputVector.size(); i++) {
			for (int j = 0; j < inputVector.size() - i; j++) {

				if (inputVector.get(j).getCreationDate().getTime() > inputVector.get(j + 1).getCreationDate()
						.getTime()) {

						Collections.swap(inputVector, j, (j+1));

				}

			}
		}

		return inputVector;
	}

	public String[] verifyField(String[] arr) {
		// TODO Auto-generated method stub

		for (int i = 0; i < arr.length; i++) {

			if (arr[i] != null) {
				if (arr[i].length() != 0) {
					arr[i] = arr[i].replaceAll("^\\s+", "");
					arr[i] = arr[i].replaceAll("\\s++$", "");

					if (arr[i].length() == 0) {
						return null;
					}

				} else
					return null;

			} else
				return null;

		}

		return arr;

	}


	public User findByEmail(User u) throws MapperException, NotLoggedInException {
		return userMapper.findByEmail(u);
	}
	
}
