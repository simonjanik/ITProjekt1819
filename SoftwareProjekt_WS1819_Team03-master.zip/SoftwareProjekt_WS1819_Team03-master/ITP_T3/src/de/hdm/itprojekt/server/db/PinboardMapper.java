package de.hdm.itprojekt.server.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.util.Date;



import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.bo.Pinboard;

/**
 * Die Klasse PinboardMapper bildet <code>Pinboard</code> Objekte auf eine relationale
 * Datenbank ab. Ebenfalls ist es möglich aus Datenbank-Tupel Java-Objekte zu
 * erzeugen.
 * 
 * Zur Verwaltung der Objekte implementiert die Mapper-Klasse entsprechende
 * Methoden wie z.B. (insert, delete). 
 */

public class PinboardMapper {
	
	/**
	 * Die Klasse PinboardMapper wird nur einmal instantiiert
	 * (Singleton-Eigenschaft). Damit diese Eigenschaft erfüllt werden kann, wird
	 * zunächst eine Variable mit dem Schlüsselwort static und dem Standardwert
	 * null erzeugt. Sie speichert die Instanz dieser Klasse.
	 */

	private static PinboardMapper pinboardMapper = null;
	
	/**
	 * Ein geschützter Konstruktor verhindert das erneute erzeugen von weiteren
	 * Instanzen dieser Klasse durch <code>new</code>.
	 */
	
	protected PinboardMapper() {
		
	}
	
	/**
	 * Methode zum Sicherstellen der Singleton-Eigenschaft. Diese sorgt dafür, dass
	 * nur eine einzige Instanz der PinboardMapper-Klasse existiert. Aufgerufen wird
	 * die Klasse somit über PinboardMapper.pinboardMapper() und nicht über den
	 * New-Operator.
	 * 
	 * @return Das <code/>pinboardMapper<code/> Objekt.
	 */
	
	public static PinboardMapper PinboardMapper() {
		if(pinboardMapper == null) {
			pinboardMapper = new PinboardMapper();
		}
		return pinboardMapper;
	}
	
	public Pinboard findbyUserID(int id)throws MapperException {
		Connection con = DBConnection.getConnection();
		
		try {
			// Prepared Statment <code/>findSubByUserID<code/> erstellen, um das Pinboard eines Nutzers zu finden
			PreparedStatement findSubByUserID = con.prepareStatement("SELECT * FROM itprojekt.pinboard WHERE userid=? and DeleteDate is null;");
			findSubByUserID.setInt(1, id);

			

			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findSubByUserID.executeQuery();
			
			if(rs.next()) {
				return new Pinboard(rs.getInt("pinboardid"), rs.getTimestamp("creationdate"), rs.getInt("userID"));
			}
		
		}
		
		catch(SQLException e){
			throw new MapperException(e);
		}
		return null;
	}
	
	public Pinboard findByID(int id) throws MapperException{
		// DB-Verbindung holen
		Connection con = DBConnection.getConnection();
		Pinboard p = null;
		try {
			// Leeres SQL-Statement (JDBC) anlegen
			// Prepared Statment <code/>findSubByUserID<code/> erstellen, um das Pinboard mit einer bestimmten <code/>pinboardid<code/> zu finden
			PreparedStatement stmt = con.prepareStatement("SELECT * FROM itprojekt.pinboard WHERE pinboardid=? AND DeleteDate IS NULL;");
			stmt.setInt(1, id);
			
			ResultSet rs = stmt.executeQuery();
			
			/*
			 * Da id Primärschlüssel ist, kann max. nur ein Tupel zurückgegeben
			 * werden. Prüfe, ob ein Ergebnis vorliegt.
			 */
			if (rs.next()) {
				// Ergebnis-Tupel in Objekt umwandeln
				p = new Pinboard(rs.getInt("pinboardid"), rs.getTimestamp("creationDate"), rs.getInt("userID"));
			}	
		}
		catch (SQLException e) {
			throw new MapperException(e);
		}
		return p;
	}
	
	public Pinboard insert(Pinboard p) throws MapperException{
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>insert<code/> erstellen, um ein Pinboard für einen neuen User anzulegen
			PreparedStatement insert = con.prepareStatement("INSERT INTO itprojekt.pinboard(userID) VALUES (?);");
			insert.setInt(1, p.getUserID());
			// Jetzt erst erfolgt die tatsächliche Einfügeoperation
			insert.executeUpdate();
			// Prepared Statment <code/>stm<code/> erstellen, um das zuletzt erstellte Pinboard zurück zu geben
			PreparedStatement stm = con.prepareStatement("SELECT * FROM itprojekt.pinboard ORDER BY pinboardID DESC LIMIT 1;");
			ResultSet rs = stm.executeQuery();
			if(rs.next()) {
				return new Pinboard(rs.getInt("pinboardID"), rs.getTimestamp("creationDate"), rs.getInt("userID"));
			}
		} 
		catch (SQLException e) {
			throw new MapperException(e);
		}

		/*
		 * Rückgabe, des evtl. korrigierten Pinboard.
		 * 
		 * HINWEIS: Da in Java nur Referenzen auf Objekte und keine physischen
		 * Objekte übergeben werden, wäre die Anpassung des Pinboard-Objekts
		 * auch ohne diese explizite Rückgabe au�erhalb dieser Methode sichtbar.
		 * Die explizite Rückgabe von u ist eher ein Stilmittel, um zu
		 * signalisieren, dass sich das Objekt evtl. im Laufe der Methode
		 * verändert hat.
		 * @author Thies
		 */
		return null;
	}
	
//	Wird nie aufgerufen, nur deleteByPinboardId oder?
	public void delete(Pinboard p)throws MapperException {
		Connection con = DBConnection.getConnection();

		try {             // von delete zu Update verändert
			// Prepared Statment <code/>delete<code/> erstellen, um ein Pinboard als gelöscht zu markieren, durch das deletiondate
			PreparedStatement delete = con.prepareStatement("Update itprojekt.pinboard SET DeleteDate= NOW() WHERE pinboardid=?;");
			delete.setInt(1, p.getId());
			delete.executeUpdate();
			/*
			 * Das Pinboard wird lokalisiert in der Datenbank und durch ein deletiondate markiert
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}	
	
	public void deleteByPinboardID(int pinboardID) throws MapperException{
		Connection con = DBConnection.getConnection();


		try {                      // von delete zu update verändert
			// Prepared Statment <code/>delete<code/> erstellen, um ein Pinboard mit hilfe der PinboardID zu löschen
			PreparedStatement delete = con.prepareStatement("Update itprojekt.pinboard SET DeleteDate= NOW() WHERE pinboardid=?;");
			delete.setInt(1, pinboardID);
			delete.executeUpdate();
			/*
			 * Das Pinboard wird lokalisiert in der Datenbank und als gelöscht markiert
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}	

	
	public int findUserIDByPinboardID(int pinboardid)throws MapperException {
		
		Connection con = DBConnection.getConnection();
		
		try {
			                                            // and delete Date = null hinzugefügt
			// Prepared Statment <code/>insert<code/> erstellen, um die UserID mit hilfe der PinboardID zu finden
			PreparedStatement stm = con.prepareStatement("Select userID FROM itprojekt.pinboard where pinboardID=? and DeleteDate is null;");
			stm.setInt(1, pinboardid);
			
			ResultSet rs = stm.executeQuery();
			
			if(rs.next()) {
				
				return rs.getInt("userID");
				
			}
			
		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}
		
		
		return 0;
	}
	
}