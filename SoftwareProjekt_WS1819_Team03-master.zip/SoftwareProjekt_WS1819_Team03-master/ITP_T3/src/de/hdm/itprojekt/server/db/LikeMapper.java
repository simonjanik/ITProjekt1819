package de.hdm.itprojekt.server.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Date;
import java.sql.Timestamp;
import java.util.Vector;

import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.bo.Like;

/**
 * Die Klasse LikeMapper bildet <code>Like</code> Objekte auf eine relationale
 * Datenbank ab. Ebenfalls ist es möglich aus Datenbank-Tupel Java-Objekte zu
 * erzeugen.
 * 
 * Zur Verwaltung der Objekte implementiert die Mapper-Klasse entsprechende
 * Methoden wie z.B. (insert, delete).
 */

public class LikeMapper {

	/**
	 * Die Klasse LikeMapper wird nur einmal instantiiert (Singleton-Eigenschaft).
	 * Damit diese Eigenschaft erfüllt werden kann, wird zunächst eine Variable mit
	 * dem Schlüsselwort static und dem Standardwert null erzeugt. Sie speichert die
	 * Instanz dieser Klasse.
	 */

	private static LikeMapper likeMapper = null;

	/**
	 * Ein geschützter Konstruktor verhindert das erneute erzeugen von weiteren
	 * Instanzen dieser Klasse durch <code>new</code>.
	 */

	protected LikeMapper() {

	}

	/**
	 * Methode zum Sicherstellen der Singleton-Eigenschaft. Diese sorgt dafür, dass
	 * nur eine einzige Instanz der LikeMapper-Klasse existiert. Aufgerufen wird die
	 * Klasse somit über LikeMapper.likeMapper() und nicht über den New-Operator.
	 * 
	 * @return Das <code/>likeMapper<code/> Objekt.
	 */

	public static LikeMapper LikeMapper() {
		if (likeMapper == null) {
			likeMapper = new LikeMapper();
		}
		return likeMapper;
	}

	public Vector<Like> findAllByPost(int id) throws MapperException{
		// Ergebnisvektor vorbereiten

		Connection con = DBConnection.getConnection();
		Vector<Like> result = new Vector<Like>();

		try {
			// Prepared Statment <code/>findAllLikeByPostID<code/> erstellen, um alle Likes eines Posts in der Datenbank zu suchen, die nicht gelöscht wurde.
			PreparedStatement findAllLikeByPostID = con.prepareStatement("SELECT * FROM itprojekt.like WHERE postID=? and deleteDate is null;");
			findAllLikeByPostID.setInt(1, id);

			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findAllLikeByPostID.executeQuery();

			// Für jeden Eintrag im Suchergebnis wird nun ein Customer-Objekt
			// erstellt.
			while (rs.next()) {

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.add(new Like(rs.getInt("likeID"), rs.getTimestamp("creationDate"), rs.getInt("postID"),
						rs.getInt("userID")));
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}

		// Ergebnisvektor zurückgeben
		return result;
	}
	
	
	public Vector<Like> findAllByPostAndPeriod(int id) throws MapperException{
		// Ergebnisvektor vorbereiten

		Connection con = DBConnection.getConnection();
		Vector<Like> result = new Vector<Like>();

		try {
			// Prepared Statment <code/>findAllLikeByPostID<code/> erstellen, um alle Likes eines Posts in der Datenbank zu suchen.
			PreparedStatement findAllLikeByPostID = con.prepareStatement("SELECT * FROM itprojekt.like WHERE postID=?;");
			findAllLikeByPostID.setInt(1, id);

			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findAllLikeByPostID.executeQuery();

			// Für jeden Eintrag im Suchergebnis wird nun ein Customer-Objekt
			// erstellt.
			while (rs.next()) {

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.add(new Like(rs.getInt("likeID"), rs.getTimestamp("creationDate"), rs.getTimestamp("deleteDate"), rs.getInt("postID"),
						rs.getInt("userID")));
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}

		// Ergebnisvektor zurückgeben
		return result;
	}
	
	
	

	public Vector<Like> findAllbyUser(int id) throws MapperException {
		// Ergebnisvektor vorbereiten

		Connection con = DBConnection.getConnection();
		Like l = null;
		Vector<Like> result = new Vector<Like>();

		try {
			// Prepared Statment <code/>findAllLikeByUserID<code/> erstellen, um alle Likes eines Users in der Datenbank zu suchen, die nicht gelöscht wurde.
			PreparedStatement findAllLikeByUserID = con.prepareStatement("SELECT * FROM itprojekt.like WHERE userID=? AND deleteDate IS NULL;");
			findAllLikeByUserID.setInt(1, id);
			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findAllLikeByUserID.executeQuery();

			// Für jeden Eintrag im Suchergebnis wird nun ein Customer-Objekt
			// erstellt.
			while (rs.next()) {
				l = new Like(rs.getInt("likeID"), rs.getTimestamp("creationDate"), rs.getInt("postID"), rs.getInt("userID"));

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.addElement(l);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		// Ergebnisvektor zurückgeben
		return result;
	}

	public Vector<Like> findAllbyUserAndPeriod(int id, Timestamp startDate, Timestamp endDate) throws MapperException {
		// Ergebnisvektor vorbereiten
		Connection con = DBConnection.getConnection();
		Like l = null;
		Vector<Like> result = new Vector<Like>();

		try {
			// Prepared Statment <code/>findAllLikeByUserID<code/> erstellen, um alle Likes eines Users in der Datenbank zu suchen.
			PreparedStatement findAllLikeByUserID = con.prepareStatement(
					"SELECT * FROM itprojekt.like WHERE userID=?;"
//					+ "and creationDate BETWEEN ? and ?;"
							);
			findAllLikeByUserID.setInt(1, id);
//			findAllLikeByUserID.setTimestamp(2, startDate);
//			findAllLikeByUserID.setTimestamp(3, endDate);

			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findAllLikeByUserID.executeQuery();

			// Für jeden Eintrag im Suchergebnis wird nun ein Customer-Objekt
			// erstellt.
			while (rs.next()) {
				l = new Like(rs.getInt("likeID"), rs.getTimestamp("creationDate"), rs.getTimestamp("deleteDate"), rs.getInt("postID"), rs.getInt("userID"));

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.addElement(l);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return result;
	}

	public Like findByID(int id) throws MapperException{
		// DB-Verbindung holen
		Connection con = DBConnection.getConnection();

		try {
			// Leeres SQL-Statement (JDBC) anlegen
			Statement stmt = con.createStatement();
			// Statment <code/>stmt<code/> erstellen, einen Like mit einer bestimmten <code/>likeid<code/> in der Datenbank zu suchen, die nicht gelöscht wurde.
			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = stmt.executeQuery("SELECT * FROM itprojekt.like WHERE likeid=" + id + "and deleteDate is null;");

			/*
			 * Da id Primärschlüssel ist, kann max. nur ein Tupel zurückgegeben werden.
			 * Prüfe, ob ein Ergebnis vorliegt.
			 */
			if (rs.next()) {
				// Ergebnis-Tupel in Objekt umwandeln
				Like l = new Like(rs.getInt("likeID"), rs.getTimestamp("creationDate"), rs.getInt("postID"), rs.getInt("userID"));
				return l;

			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}

		return null;
	}

	public Like insertLike(Like l)throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			/*
			 * Zunächst schauen wir nach, welches der momentan höchste
			 * Primärschlüsselwert ist.
			 */
			// Prepared Statment <code/>stm<code/> erstellen, um einen Like in der Datenbank zu speichen
				PreparedStatement stm = con.prepareStatement("INSERT INTO itprojekt.like (`UserID`, `PostID`) VALUES (?, ?);");
				stm.setInt(1, l.getUserID());
				stm.setInt(2, l.getPostID());
				stm.executeUpdate();
				// Prepared Statment <code/>stm2<code/> erstellen, um den letzten Like aus der Datenbank zu bekommen
				PreparedStatement stm2 = con.prepareStatement("SELECT * FROM itprojekt.like ORDER BY likeid DESC LIMIT 1;");
				ResultSet rs = stm2.executeQuery();
				
				if(rs.next()) {
					return new Like(rs.getInt("likeid"), rs.getTimestamp("creationDate"), rs.getInt("postid"), rs.getInt("userid"));
				}
				
				
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		
		/*
		 * Rückgabe, des evtl. korrigierten Like.
		 * 
		 * HINWEIS: Da in Java nur Referenzen auf Objekte und keine physischen
		 * Objekte übergeben werden, wäre die Anpassung des User-Objekts
		 * auch ohne diese explizite Rückgabe au�erhalb dieser Methode sichtbar.
		 * Die explizite Rückgabe von u ist eher ein Stilmittel, um zu
		 * signalisieren, dass sich das Objekt evtl. im Laufe der Methode
		 * verändert hat.
		 * @author Thies
		 */
			
		return null;
	}

	public void deleteAllByUser(int id)throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>stm<code/> erstellen, alle Likes eines Users als gelöscht zu makieren
			PreparedStatement stm = con.prepareStatement("Update itprojekt.like Set DeleteDate=NOW() where userID = ?;");
			stm.setInt(1, id);
			stm.executeUpdate();
			/*
			 * Der Like des Users wird lokalisiert in der Datenbank und der Like wird
			 * gelöscht
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

	public void deleteAllByPost(int id)throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>stm<code/> erstellen, alle Likes eines Posts als gelöscht zu makieren
			PreparedStatement stm = con.prepareStatement("Update itprojekt.like SET `DeleteDate`=NOW() WHERE `PostID`=?;");
			stm.setInt(1, id);
			stm.executeUpdate();
			/*
			 * Der Like des Users wird lokalisiert in der Datenbank und der Like wird
			 * gelöscht
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

	public void deleteLike(int id) throws MapperException{
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>stm<code/> erstellen, einen Like mit einer bestimmten <code/>likeid<code/> al gelöscht zu markieren
			PreparedStatement stmt = con.prepareStatement("UPDATE itprojekt.like SET DeleteDate=NOW() WHERE likeid=?;");
			stmt.setInt(1, id);
			stmt.executeUpdate();
			/*
			 * Der Like des Users wird lokalisiert in der Datenbank und der Like wird
			 * gelöscht
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}
}
