package de.hdm.itprojekt.server.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.util.Vector;
import java.sql.Timestamp;

import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.bo.Post;

/**
 * Die Klasse PostMapper bildet <code>Post</code> Objekte auf eine relationale
 * Datenbank ab. Ebenfalls ist es möglich aus Datenbank-Tupel Java-Objekte zu
 * erzeugen.
 * 
 * Zur Verwaltung der Objekte implementiert die Mapper-Klasse entsprechende
 * Methoden wie z.B. (insert, delete).
 */

public class PostMapper {

	/**
	 * Die Klasse PostMapper wird nur einmal instantiiert (Singleton-Eigenschaft).
	 * Damit diese Eigenschaft erfüllt werden kann, wird zunächst eine Variable mit
	 * dem Schlüsselwort static und dem Standardwert null erzeugt. Sie speichert die
	 * Instanz dieser Klasse.
	 */

	private static PostMapper postMapper = null;

	/**
	 * Ein geschützter Konstruktor verhindert das erneute erzeugen von weiteren
	 * Instanzen dieser Klasse durch <code>new</code>.
	 */

	protected PostMapper() {

	}

	/**
	 * Methode zum Sicherstellen der Singleton-Eigenschaft. Diese sorgt dafür, dass
	 * nur eine einzige Instanz der PostMapper-Klasse existiert. Aufgerufen wird die
	 * Klasse somit über PostMapper.postMapper() und nicht über den New-Operator.
	 * 
	 * @return Das <code/>postMapper<code/> Objekt.
	 */

	public static PostMapper PostMapper() {
		if (postMapper == null) {
			postMapper = new PostMapper();
		}
		return postMapper;
	}

	public Post findByID(int id)throws MapperException {
		// DB-Verbindung holen
		Connection con = DBConnection.getConnection();
		Post p = null;
		try {
			// Leeres SQL-Statement (JDBC) anlegen                                         and deleteDate = null hinzugefügt
			PreparedStatement findByID = con.prepareStatement("SELECT * FROM itprojekt.post WHERE postid=? and DeleteDate is null;");
			findByID.setInt(1, id);
			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findByID.executeQuery();

			/*
			 * Da id Primärschlüssel ist, kann max. nur ein Tupel zurückgegeben werden.
			 * Prüfe, ob ein Ergebnis vorliegt.
			 */
			p = new Post(rs.getInt("postid"), rs.getTimestamp("creationDate"), rs.getString("text"), rs.getInt("pinboardID"));
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return p;
	}
                                                           // von datentyp date in timestamp verändert
	public Vector<Post> findAllByPinboardIDAndPeriod(int id, Timestamp startDate, Timestamp endDate) throws MapperException{
		// DB-Verbindung holen
		Connection con = DBConnection.getConnection();
		Post p = null;
		Vector<Post> result = new Vector<Post>();
		try {
			PreparedStatement findAllByPinboardIDAndPeriod = con.prepareStatement("SELECT * FROM itprojekt.post WHERE pinboardID=? "
//					+ "and creationDate BETWEEN ? and ?;"
					);
			findAllByPinboardIDAndPeriod.setInt(1, id);
//			findAllByPinboardIDAndPeriod.setTimestamp(2, startDate);  // in Timestamp statt date verändert
//			findAllByPinboardIDAndPeriod.setTimestamp(3, endDate); //in Timestamp verändert statt date
			// Statement ausfüllen und als Query an die DB schicken

			ResultSet rs = findAllByPinboardIDAndPeriod.executeQuery();

			/*
			 * Da id Primärschlüssel ist, kann max. nur ein Tupel zurückgegeben werden.
			 * Prüfe, ob ein Ergebnis vorliegt.
			 */
			while (rs.next()) {
				// Ergebnis-Tupel in Objekt umwandeln
				p = new Post(rs.getInt("postid"), rs.getTimestamp("creationDate"), rs.getTimestamp("deleteDate"), rs.getString("text"), rs.getInt("pinboardID"));
				result.add(p);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return result;
	}

	public Vector<Post> findByPinboardId(int pinbaordID) throws MapperException{
		Connection con = DBConnection.getConnection();
		Vector<Post> result = new Vector<>();
		 
		try {
			                                                                          //and deleteDate = null hinzugefügt
			PreparedStatement stm = con.prepareStatement("SELECT * FROM itprojekt.post WHERE pinboardid=? and DeleteDate is null ORDER BY creationDate DESC;");
			stm.setInt(1, pinbaordID);
			
			ResultSet rs = stm.executeQuery();
			while(rs.next()) {
				result.add(new Post(rs.getInt("postid"), rs.getTimestamp("creationDate"), rs.getString("text"), rs.getInt("pinboardid")));
			}
		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}

		return result;
	}

	public Post insert(Post p) throws MapperException{
		Connection con = DBConnection.getConnection();

		try {
			PreparedStatement insert = con.prepareStatement("INSERT INTO itprojekt.post(text,pinboardID) VALUES (?,?);");
			// Jetzt erst erfolgt die tatsächliche Einfügeoperation
			insert.setString(1, p.getText());
			insert.setInt(2, p.getPinboardID());
			insert.executeUpdate();
			
			PreparedStatement getNewPost = con.prepareStatement("SELECT * FROM itprojekt.post ORDER BY postid DESC LIMIT 1;");
			ResultSet rs = getNewPost.executeQuery();
			if(rs.next()) {
				return new Post(rs.getInt("postID"),rs.getTimestamp("creationDate"),rs.getString("text"),rs.getInt("pinboardID"));
			}
		} 
		catch (SQLException e) {
			throw new MapperException(e);
		}
		return null;
	}

	public Post update(Post p)throws MapperException {
		Connection con = DBConnection.getConnection();
		try {
			PreparedStatement update = con.prepareStatement("UPDATE `itprojekt`.`post` SET `Text`=? WHERE `PostID`=?;");
			update.setString(1, p.getText());
			update.setInt(2, p.getId());

			// PreparedStatement aufrufen und als Query an die DB schicken.
			update.executeUpdate();
			
			PreparedStatement getUpdatedPost = con.prepareStatement("SELECT * FROM itprojekt.post WHERE postID=?;");
			getUpdatedPost.setInt(1, p.getId());
			ResultSet rs = getUpdatedPost.executeQuery();
			
			if(rs.next()) {
				return new Post(rs.getInt("postID"),rs.getTimestamp("creationDate"),rs.getString("text"),rs.getInt("pinboardID"));
			}
			
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return null;
	}

	public void delete(int postid) throws MapperException{
		Connection con = DBConnection.getConnection();

		try {        // in update verändert von delete
			PreparedStatement delete = con.prepareStatement("UPDATE `itprojekt`.`post` SET `DeleteDate`=NOW() WHERE `PostID`=?;");
			delete.setInt(1, postid);
			delete.executeUpdate();
			/*
			 * Der Post des Users wird lokalisiert in der Datenbank und der Post wird
			 * gelöscht
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

//	Methode durch deletePinboard hinfällig oder so umändern, dass auch Kommentare und Likes gelöscht werden
	public void deleteAllByPinboardID(int id)throws MapperException {
		Connection con = DBConnection.getConnection();

		try {                                              // von delete in update geändert
			PreparedStatement deleteAllByUser = con.prepareStatement("Update itprojekt.post SET DeleteDate= NOW() WHERE pinboardID=?;");

			deleteAllByUser.setInt(1, id);
			deleteAllByUser.executeUpdate();
			/*
			 * Alle Posts des Users werden lokalisiert in der Datenbank und anschließend
			 * gelöscht
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

	public Vector<Post> findAllByPeriod(Timestamp startDate, Timestamp endDate) throws MapperException{
		// Ergebnisvektor vorbereiten
		Vector<Post> result = new Vector<Post>();

		Connection con = DBConnection.getConnection();
		try {

			PreparedStatement findAll = con.prepareStatement(
					"SELECT * FROM itprojekt.post "
//					+ "WHERE creationDate BETWEEN ? and ? "
					+ "ORDER BY postid;");
//			findAll.setTimestamp(1, startDate);  //in timestamp verändert
//			findAll.setTimestamp(2, endDate);     // in timestamp verändert
			ResultSet rs = findAll.executeQuery();

			// Für jeden Eintrag im Suchergebnis wird nun ein Post-Objekt
			// erstellt.

			while (rs.next()) {

				Post p = new Post(rs.getInt("postid"), rs.getTimestamp("date"), rs.getString("text"),
						rs.getInt("pinboardID"));

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.addElement(p);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}

		// Ergebnisvektor zurückgeben
		return result;
	}
}
