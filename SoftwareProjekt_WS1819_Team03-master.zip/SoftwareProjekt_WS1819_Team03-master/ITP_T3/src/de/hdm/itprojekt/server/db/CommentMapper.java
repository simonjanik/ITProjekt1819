package de.hdm.itprojekt.server.db;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Date;
import java.sql.Timestamp;
import java.util.Vector;

import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.bo.Comment;

/**
 * Die Klasse CommentMapper bildet <code>Comment</code> Objekte auf eine
 * relationale Datenbank ab. Ebenfalls ist es möglich aus Datenbank-Tupel
 * Java-Objekte zu erzeugen.
 * 
 * Zur Verwaltung der Objekte implementiert die Mapper-Klasse entsprechende
 * Methoden wie z.B. (insert, delete).
 */

public class CommentMapper {

	/**
	 * Die Klasse CommentMapper wird nur einmal instantiiert
	 * (Singleton-Eigenschaft). Damit diese Eigenschaft erfüllt werden kann, wird
	 * zunächst eine Variable mit dem Schlüsselwort static und dem Standardwert null
	 * erzeugt. Sie speichert die Instanz dieser Klasse.
	 */

	private static CommentMapper commentMapper = null;

	/**
	 * Ein geschützter Konstruktor verhindert das erneute erzeugen von weiteren
	 * Instanzen dieser Klasse durch <code>new</code>.
	 */

	protected CommentMapper() {

	}

	/**
	 * Methode zum Sicherstellen der Singleton-Eigenschaft. Diese sorgt dafür, dass
	 * nur eine einzige Instanz der CommentMapper-Klasse existiert. Aufgerufen wird
	 * die Klasse somit über CommentMapper.commentMapper() und nicht über den
	 * New-Operator.
	 * 
	 * @return Das <code/>commentMapper<code/> Objekt.
	 */

	public static CommentMapper CommentMapper() {
		if (commentMapper == null) {
			commentMapper = new CommentMapper();
		}
		return commentMapper;
	}

	public Comment findByID(int id) throws MapperException {
		// Neues Comment Objekt erstellen
		// DB-Verbindung holen
		Comment c = null;
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>findbyID<code/> erstellen, um einen Comment mit einer bestimmten ID in der Datenbank zu suchen der nicht gelöscht wurde.
			PreparedStatement findByID = con
					.prepareStatement("SELECT * FROM itprojekt.comment WHERE commentid=? and deleteDate is null;");
			// Die ID im PreparedStatement setzen
			findByID.setInt(1, id);

			// Statement als Query an die DB schicken
			ResultSet rs = findByID.executeQuery();
			// Neues Comment Objekt instanziieren und füllen mit übergebene Werten der Datenbank
			c = new Comment(rs.getInt("commentid"), rs.getTimestamp("creationDate"), rs.getString("text"),
					rs.getInt("authorID"), rs.getInt("postID"));
		// <code/>SQLExeption<code/> wird übergeben falls fehler auftritt
		} catch (SQLException e) {
			throw new MapperException(e);
		}
		// Comment Objekt <code/>c<code/> wird zurückgegeben
		return c;
	}

	public Comment insert(Comment c) throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>insert<code/> erstellen, um einen Comment in der Datenbank zu speichen
			PreparedStatement insert = con
					.prepareStatement("INSERT INTO itprojekt.comment(text,userID, postID) VALUES (?,?,?);");
			// Jetzt erst erfolgt die tatsächliche Einfügeoperation
			insert.setString(1, c.getText());
			insert.setInt(2, c.getAuthorID());
			insert.setInt(3, c.getPostID());
			insert.executeUpdate();
			
			// Prepared Statment <code/>stm<code/> erstellen, um den gespeicherten Comment direkt auszugeben
			PreparedStatement stm = con
					.prepareStatement("SELECT * FROM itprojekt.comment ORDER BY commentid DESC LIMIT 1;");
			ResultSet rs = stm.executeQuery();
			if (rs.next()) {
				return new Comment(rs.getInt("commentid"), rs.getTimestamp("creationDate"), rs.getString("text"),
						rs.getInt("userid"), rs.getInt("postid"));
			}

		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return null;
	}

	public Comment update(Comment c) throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>update<code/> erstellen, um einen Comment zu ändern
			PreparedStatement update = con.prepareStatement("UPDATE itprojekt.comment SET text=? WHERE commentid=?;");
			update.setString(1, c.getText());
			update.setInt(2, c.getId());
			// PreparedStatement aufrufen und als Query an die DB schicken.
			update.executeUpdate();
			// Prepared Statment <code/>instmsert<code/> erstellen, um den geänderten Comment direkt auszugeben
			PreparedStatement stm = con.prepareStatement("SELECT * FROM itprojekt.comment WHERE commentID=?;");
			stm.setInt(1, c.getId());
			ResultSet rs = stm.executeQuery();
			if (rs.next()) {
				return new Comment(rs.getInt("commentid"), rs.getTimestamp("creationDate"), rs.getString("text"),
						rs.getInt("userid"), rs.getInt("postid"));
			}

		} catch (SQLException e) {
			throw new MapperException(e);
		}
		return null;
	}

	public void delete(int id) throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>delete<code/> erstellen, um einen Comment in der Datenbank als gelöscht zu makieren in dem das DeleteDate auf einen wert !=null gesetzt wird
			PreparedStatement delete = con
					.prepareStatement("Update itprojekt.comment SET `DeleteDate`=NOW() WHERE commentid=?;");
			delete.setInt(1, id);

			// Statement ausfüllen und als Query an die DB schicken
			delete.executeUpdate();

			/*
			 * Der Comment des Users wird lokalisiert in der Datenbank und der Comment wird
			 * gelöscht
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

	public void deleteAllByUser(int id) throws MapperException {
		Connection con = DBConnection.getConnection();

		try {
			// Prepared Statment <code/>deleteAllByUser<code/> erstellen, um alle Comments eines Users in der Datenbank als gelöscht zu makieren in dem das DeleteDate auf einen wert !=null gesetzt wird
			PreparedStatement deleteAllByUser = con
					.prepareStatement("Update itprojekt.comment SET `DeleteDate`=NOW() WHERE userID =?;");
			deleteAllByUser.setInt(1, id);
			// Statement ausfüllen und als Query an die DB schicken
			deleteAllByUser.executeUpdate();

			/*
			 * Alle Comment des Users werden lokalisiert in der Datenbank und werden
			 * gelöscht.
			 */
		} catch (SQLException e) {
			throw new MapperException(e);
		}
	}

	public Vector<Comment> findAllByUserAndDate(int id, Timestamp startDate, Timestamp endDate) throws MapperException {
		// Ergebnisvektor vorbereiten

		Connection con = DBConnection.getConnection();
		Comment c = null;
		Vector<Comment> result = new Vector<Comment>();

		try {
// 			Prepared Statment <code/>findAllCommentsByUserAndDate<code/> erstellen, um alle Comments eines Users auszugeben
			PreparedStatement findAllCommentsByUserAndDate = con
					.prepareStatement("SELECT * FROM itprojekt.comment WHERE userid=? "
//					+ "and creationDate BETWEEN ? and ?;"
					);
			findAllCommentsByUserAndDate.setInt(1, id);
//			findAllCommentsByUserAndDate.setTimestamp(2, startDate);
//			findAllCommentsByUserAndDate.setTimestamp(3, endDate);
			// Statement ausfüllen und als Query an die DB schicken
			ResultSet rs = findAllCommentsByUserAndDate.executeQuery();

			// Für jeden Eintrag im Suchergebnis wird nun ein Comment-Objekt
			// erstellt.
			while (rs.next()) {
				c = new Comment(rs.getInt("commentid"), rs.getTimestamp("creationDate"), rs.getTimestamp("deleteDate"), rs.getString("text"),
						rs.getInt("userID"), rs.getInt("postID"));

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.addElement(c);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}

		// Ergebnisvektor zurückgeben
		return result;
	}

	public Vector<Comment> findAllByPostAndDate(int id, Timestamp startDate, Timestamp endDate) throws MapperException {
		// Ergebnisvektor vorbereiten

		Connection con = DBConnection.getConnection();
		Comment c = null;
		Vector<Comment> result = new Vector<Comment>();

		try {
//			Prepared Statment <code/>findAllCommentsByPostAndDate<code/> erstellen, um alle Comments eines Posts auszugeben
			PreparedStatement findAllCommentsByPostAndDate = con
					.prepareStatement("SELECT * FROM itprojekt.comment WHERE postid=? "
//					+ "and creationDate BETWEEN ? and ?;"
							+ "");
			findAllCommentsByPostAndDate.setInt(1, id);
//			findAllCommentsByPostAndDate.setTimestamp(2, startDate);
//			findAllCommentsByPostAndDate.setTimestamp(3, endDate);

			// PreparedStatement ausführen und als Query an die DB schicken
			ResultSet rs = findAllCommentsByPostAndDate.executeQuery();

			// Für jeden Eintrag im Suchergebnis wird nun ein Comment-Objekt
			// erstellt.
			while (rs.next()) {
				c = new Comment(rs.getInt("commentid"), rs.getTimestamp("creationDate"), rs.getTimestamp("deleteDate"), rs.getString("text"),
						rs.getInt("userID"), rs.getInt("postID"));

				// Hinzufügen des neuen Objekts zum Ergebnisvektor
				result.addElement(c);
			}
		} catch (SQLException e) {
			throw new MapperException(e);
		}

		// Ergebnisvektor zurückgeben
		return result;
	}

	public void deleteAllByPost(int postid) throws MapperException {
		Connection con = DBConnection.getConnection();
		try {
//			Prepared Statment <code/>deleteAllByUser<code/> erstellen, um alle Comments eines Posts in der Datenbank als gelöscht zu makieren in dem das DeleteDate auf einen wert !=null gesetzt wird
			PreparedStatement stm = con
					.prepareStatement("UPDATE `itprojekt`.`comment` SET `DeleteDate`=NOW() WHERE `PostID`=?;");
			stm.setInt(1, postid);
			stm.executeUpdate();

		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}

	}

	public Vector<Comment> findByPost(int postid) throws MapperException {
		Connection con = DBConnection.getConnection();
		Vector<Comment> result = new Vector<>();

		try {
// 			Prepared Statment <code/>stm<code/> erstellen, um alle Comments eines Posts die nicht gelöscht sind, sortiert nach dem creationDate auszugeben
			PreparedStatement stm = con.prepareStatement(
					"Select * From itprojekt.comment WHERE postid=? and deleteDate is null ORDER BY creationDate DESC;");
			stm.setInt(1, postid);
			ResultSet rs = stm.executeQuery();

			while (rs.next()) {
				result.add(new Comment(rs.getInt("commentid"), rs.getTimestamp("creationDate"), rs.getString("text"),
						rs.getInt("userid"), rs.getInt("postid")));
			}

		} catch (Exception e) {
			// TODO: handle exception
			throw new MapperException(e);
		}

		return result;
	}

}
