package de.hdm.itprojekt.server.db;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

import de.hdm.itprojekt.shared.MapperException;

public class DBConnection {

	/*
	 * Die Klasse DBConnection wird nur einmal instanziiert. Wegen der Singleton
	 * Eigenschaft Die Variable ist durch static nur einmal für sämtliche Instanzen
	 * vorhanden.
	 */

	private static Connection con = null;

	// jdbc:mysql://localhost/ITProjekt?user=root&password=password&useUnicode=true&useSSL=false&useJDBCCompliantTimezoneShift=true&useLegacyDatetimeCode=false&serverTimezone=UTC";
	private static String googleURL = "jdbc:google:mysql://itprojektws1819:europe-west3:itprojekt-ws1819/itprojekt?user=root&password=password&autoReconnect=true";

	/*
	 * Stellt die Verbindung zur Datenbank her.
	 * 
	 * @return con
	 * 
	 * Fazit: DBConnection sollte nicht mittels <code>new</code> instantiiert
	 * werden, sondern stets durch Aufruf dieser statischen Methode.
	 */

	public static Connection getConnection() throws MapperException {

		/*
		 * Herstellung einer DB Verbindung, wenn bisher keine Verbindung besteht
		 */
		if (con == null) {
			try {

				/*
				 * Neue Instanz mysl Konnektor (JDBC). Bisher nur localUrl, später durch
				 * googleUrl ersetzt.
				 */

				Class.forName("com.mysql.jdbc.GoogleDriver"); // ladet den JDBC Driver Connector für mysql
				con = DriverManager.getConnection(googleURL);

				/*
				 * Die Verbindung zur Datenbank wird in der Variablen con mit den dazugehoerigen
				 * Informationen gespeichert
				 */

				Statement s = con.createStatement();
				System.out.println("DB Connection!");

				/*
				 * Veranschaulichung ob die Datenbankverbindung zu stande gekommen ist
				 */

			} catch (Exception e) {

				// TODO: handle exception
				throw new MapperException(e); // throw new RuntimeException() nötig?
			}

			/*
			 * Verfolgt beim Debuggen den Fehler bis zum Ursprung
			 */

		}

		return con;
	}

}
