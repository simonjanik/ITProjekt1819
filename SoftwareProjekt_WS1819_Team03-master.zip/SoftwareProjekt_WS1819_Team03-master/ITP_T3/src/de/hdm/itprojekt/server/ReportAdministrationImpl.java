package de.hdm.itprojekt.server;

import java.sql.Timestamp;


import java.util.Date;

//import java.time.Period;

import java.util.Vector;

import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.datepicker.client.CalendarUtil;
//import com.google.gwt.user.datepicker.client.CalendarUtil;
import com.google.gwt.user.server.rpc.RemoteServiceServlet;

import de.hdm.itprojekt.server.db.CommentMapper;
import de.hdm.itprojekt.server.db.LikeMapper;
import de.hdm.itprojekt.server.db.PinboardMapper;
import de.hdm.itprojekt.server.db.PostMapper;
import de.hdm.itprojekt.server.db.SubMapper;
import de.hdm.itprojekt.server.db.UserMapper;
import de.hdm.itprojekt.shared.EditorAdministration;
import de.hdm.itprojekt.shared.LoginAdministration;
import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.ReportAdministration;
import de.hdm.itprojekt.shared.bo.Comment;
import de.hdm.itprojekt.shared.bo.Like;
import de.hdm.itprojekt.shared.bo.Pinboard;
import de.hdm.itprojekt.shared.bo.Post;
import de.hdm.itprojekt.shared.bo.Sub;
import de.hdm.itprojekt.shared.bo.User;
import de.hdm.itprojekt.shared.report.Column;
import de.hdm.itprojekt.shared.report.CompositeParagraph;
import de.hdm.itprojekt.shared.report.CompositeReport;
import de.hdm.itprojekt.shared.report.LikeReport;
import de.hdm.itprojekt.shared.report.Paragraph;
import de.hdm.itprojekt.shared.report.ReportHeader;
import de.hdm.itprojekt.shared.report.Row;
//import de.hdm.itprojekt.shared.report.AllCommentsByPostAndPeriodReport;
//import de.hdm.itprojekt.shared.report.AllLikesByPostAndPeriodReport;
//import de.hdm.itprojekt.shared.report.AllPostsByUserAndPeriodReport;
//import de.hdm.itprojekt.shared.report.AllSubscribingUsersByPinboardAndPeriodReport;
import de.hdm.itprojekt.shared.report.SimpleParagraph;
import de.hdm.itprojekt.shared.report.SimpleReport;
import de.hdm.itprojekt.shared.report.SubReport;
import de.hdm.itprojekt.shared.report.PostReport;
import de.hdm.itprojekt.shared.report.CommentReport;
import de.hdm.itprojekt.shared.report.LikeReport;
import de.hdm.itprojekt.shared.report.Row;
import de.hdm.itprojekt.shared.report.SimpleParagraph;

public class ReportAdministrationImpl extends RemoteServiceServlet implements ReportAdministration {

	private PostMapper postMapper = null;
	private CommentMapper commentMapper = null;
	private LikeMapper likeMapper = null;
	private UserMapper userMapper = null;
	private SubMapper subMapper = null;
	private PinboardMapper pinboardMapper = null;

	/**
	 * 
	 */
	private EditorAdministrationImpl editorAdministration = null;
	private LoginAdministrationImpl loginAdministration = null;

	public ReportAdministrationImpl() throws IllegalArgumentException {

	}

	public void init() throws IllegalArgumentException {
		// ?????
		this.postMapper = PostMapper.PostMapper();
		this.commentMapper = CommentMapper.CommentMapper();
		this.likeMapper = LikeMapper.LikeMapper();
		this.userMapper = UserMapper.UserMapper();
		this.subMapper = SubMapper.SubMapper();
		this.pinboardMapper = PinboardMapper.PinboardMapper();

		EditorAdministrationImpl e = new EditorAdministrationImpl();
		e.init();
		this.editorAdministration = e;

		loginAdministration = LoginAdministrationImpl.getLoginAdministration();

	}

	protected EditorAdministration getEditorAdministration() {
		return this.editorAdministration;
	}

	public CompositeReport getReport(Vector<String> choosenUsersString, Timestamp choosenStartDate,
			Timestamp choosenEndDate, Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			Vector<SimpleReport> choosenReports, User clientUser) throws MapperException, NotLoggedInException {

//		Login des Nutzers verifizieren
		loginAdministration.checkLogin();

//		---------------------------------------------------------------------------------			
		CompositeReport compositeReport = new CompositeReport();

		SimpleReport header = new SimpleReport();

		SimpleParagraph headerPar1 = new SimpleParagraph();
		headerPar1.setValue("Report");


		String tempD2 = (choosenEndDate.getDate()) + "." + (choosenEndDate.getMonth() + 1) + "."
				+ (choosenEndDate.getYear() + 1900);

		SimpleParagraph headerPar2 = new SimpleParagraph();
		headerPar2.setValue(("Vom " +
				(choosenStartDate.getDate()) + "." + (choosenStartDate.getMonth() + 1) + "."
				+ (choosenStartDate.getYear() + 1900) + " bis zum " + tempD2));



		choosenStartDatePl1TS.setTime(choosenStartDate.getTime() + (1000 * 60 * 60 * 24));
		choosenEndDatePl1TS.setTime(choosenEndDate.getTime() + (1000 * 60 * 60 * 24));

		CompositeParagraph headerPar = new CompositeParagraph();
		headerPar.addSimpleParagraph(headerPar1);
		headerPar.addSimpleParagraph(headerPar2);

		compositeReport.setHeaderData(headerPar);

//		---------------------------------------------------------------------------------		
//		Beziehen der User-Objekte
		Vector<User> choosenUsers = new Vector<User>();
		if (choosenUsersString.size() != 0) {
			for (int i = 0; i < choosenUsersString.size(); i++) {
				choosenUsers.add(userMapper.findByNickname(choosenUsersString.elementAt(i)));
			}

//		---------------------------------------------------------------------------------
////	Befüllen des gesamten Reports mit den angeforderten Reports über angeforderte User

			for (int i = 0; i < choosenUsers.size(); i++) {

//			Setzen des Headers der für einen user angeforderten Reports
				SimpleReport userReportHeader = new SimpleReport();

				SimpleParagraph uDSP = new SimpleParagraph();
				uDSP.setValue("Report von " + choosenUsers.elementAt(i).getFirstName() + " "
						+ choosenUsers.elementAt(i).getLastName() + " " + "(" + choosenUsers.elementAt(i).getNickName()
						+ ")");

				CompositeParagraph uDP = new CompositeParagraph();
				uDP.addSimpleParagraph(uDSP);

				userReportHeader.setHeaderData(uDP);


				compositeReport.addsimpleReport(userReportHeader);

				if (choosenReports.size() != 0) {
					for (int u = 0; u < choosenReports.size(); u++) {

						if (choosenReports.elementAt(u).getClass() == SubReport.class) {
							compositeReport.addsimpleReport(this.createSubReport1(choosenUsers.elementAt(i),
									choosenStartDate, choosenEndDate, choosenStartDatePl1TS, choosenEndDatePl1TS));

							compositeReport.addsimpleReport(this.createSubReport2(choosenUsers.elementAt(i),
									choosenStartDate, choosenEndDate, choosenStartDatePl1TS, choosenEndDatePl1TS));
						}

						if (choosenReports.elementAt(u).getClass() == PostReport.class) {
							compositeReport.addsimpleReport(this.createPostReport1(choosenUsers.elementAt(i),
									choosenStartDate, choosenEndDate, choosenStartDatePl1TS, choosenEndDatePl1TS));
						}

						if (choosenReports.elementAt(u).getClass() == CommentReport.class) {
							compositeReport.addsimpleReport(this.createCommentReport1(choosenUsers.elementAt(i),
									choosenStartDate, choosenEndDate, choosenStartDatePl1TS, choosenEndDatePl1TS));

							compositeReport.addsimpleReport(this.createCommentReport2(choosenUsers.elementAt(i),
									choosenStartDate, choosenEndDate, choosenStartDatePl1TS, choosenEndDatePl1TS));
						}

						if (choosenReports.elementAt(u).getClass() == LikeReport.class) {
							compositeReport.addsimpleReport(this.createLikeReport1(choosenUsers.elementAt(i),
									choosenStartDate, choosenEndDate, choosenStartDatePl1TS, choosenEndDatePl1TS));

							compositeReport.addsimpleReport(this.createLikeReport2(choosenUsers.elementAt(i),
									choosenStartDate, choosenEndDate, choosenStartDatePl1TS, choosenEndDatePl1TS));
						}

					}
				}

//			Einfügen einer Trennlinie
				SimpleReport userReportSeperator = new SimpleReport();

				compositeReport.addsimpleReport(userReportSeperator);

			}
		}

		return compositeReport;

	}

	@Override
	public SubReport createSubReport1(User user, Timestamp chosenStartDate, Timestamp chosenEndDate,
			Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException {

		SubReport subReport = new SubReport();

		Row rowZero = new Row();
		rowZero.addColumn(
				new Column("<b><span style=\"font-size:16px; line-height:1.6;\">Report über Abonnenten:</span></b>"));

		subReport.addRow(rowZero);

		// VON AUSGEWÄHLTEM GETÄTIGTE SUBS / ABONNIERTE USER
		Vector<Sub> allSubscribing = subMapper.findAllSubByUserIDAndPeriod(user.getId(), chosenStartDate,
				chosenEndDate);

//			GESAMTMENGE STARTDATUM
		Row firstRow = new Row();
		firstRow.addColumn(new Column("Abonniert zum Startdatum:"));

		// COUNTER FÜR SUBS AN STARTDATUM
		int counter11 = 0;


		// COUNTER ERHÖHEN WENN STARTDATUM = CHOSENSTARTDATUM
		if (allSubscribing.size() != 0) {
			for (int i = 0; i < allSubscribing.size(); i++) {


//				Wenn das BO vor dem StartDate erstellt wurde...
				if (allSubscribing.get(i).getCreationDate().before(choosenStartDatePl1TS)) {

//					Und inzwischen gelöscht wurde, jedoch vor dem Startdatum
					if (allSubscribing.get(i).getDeletionDate() != null) {
						if (allSubscribing.get(i).getDeletionDate().after(choosenStartDatePl1TS)) {
							counter11++;
						}
					}

//					Und nicht gelöscht wurde
					else {
						counter11++;
					}
				}
			}
		}

		if (counter11 > 0) {
			counter11 -= 1;
		}

		firstRow.addColumn(new Column(String.valueOf(counter11)));

		subReport.addRow(firstRow);

//			GESAMTMENGE ENDDATUM
		Row secondRow = new Row();
		secondRow.addColumn(new Column("Abonniert zum Enddatum:"));

		// COUNTER FÜR SUBS AN ENDDATUM
		int counter12 = 0;


		if (allSubscribing.size() != 0) {
			for (int i = 0; i < allSubscribing.size(); i++) {

//				Wenn das BO vor dem EndDate erstellt wurde...
				if (allSubscribing.get(i).getCreationDate().before(choosenEndDatePl1TS)) {

//					Und inzwischen gelöscht wurde, jedoch vor dem Enddatum
					if (allSubscribing.get(i).getDeletionDate() != null) {
						if (allSubscribing.get(i).getDeletionDate().after(choosenEndDatePl1TS)) {
							counter12++;
						}
					}

//					Und nicht gelöscht wurde
					else {
						counter12++;
					}
				}
			}
		}

		if (counter12 > 0) {
			counter12 -= 1;
		}

		secondRow.addColumn(new Column(String.valueOf(counter12)));
		subReport.addRow(secondRow);

//			VERÄNDERUNG IM ZEITRAUM
		Row thirdRow = new Row();
		thirdRow.addColumn(new Column("Veränderung im Zeitraum:"));
		int change = 0;
		change = counter12 - counter11;
		thirdRow.addColumn(new Column(String.valueOf(change)));

		subReport.addRow(thirdRow);

		return subReport;

	}

	public SubReport createSubReport2(User user, Timestamp chosenStartDate, Timestamp chosenEndDate,
			Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException {
		SubReport subReport = new SubReport();

//		VOM AUSGEWÄHLTEM ERHALTENE SUBS / ABONENTEN VOM USER	
		Pinboard pin = pinboardMapper.findbyUserID(user.getId());
		Vector<Sub> allSubsOnMe = subMapper.findAllSubByPinnboardIDAndPeriod(pin.getId(), user.getId(), chosenStartDate,
				chosenEndDate);

//		GESAMTMENGE STARTDATUM
		Row fourthRow = new Row();
		fourthRow.addColumn(new Column("Abonnenten zum Startdatum:"));

		// COUNTER FÜR SUBS AN STARTDATUM
		int counter21 = 0;


		// COUNTER ERHÖHEN WENN STARTDATUM = CHOSENSTARTDATUM
		if (allSubsOnMe.size() != 0) {
			for (int i = 0; i < allSubsOnMe.size(); i++) {
				if (allSubsOnMe.get(i).getCreationDate().before(choosenStartDatePl1TS)) {

					if (allSubsOnMe.get(i).getDeletionDate() != null) {
						if (allSubsOnMe.get(i).getDeletionDate().after(choosenStartDatePl1TS)) {
							counter21++;
						}
					}

//				Und nicht gelöscht wurde
					else {
						counter21++;
					}
				}
			}
		}

		if (counter21 > 0) {
			counter21 -= 1;
		}

		fourthRow.addColumn(new Column(String.valueOf(counter21)));
		subReport.addRow(fourthRow);

//		GESAMTMENGE ENDDATUM
		Row fifthRow = new Row();
		fifthRow.addColumn(new Column("Abonnenten zum Enddatum:"));

		// COUNTER FÜR SUBS AN ENDDATUM
		int counter22 = 0;

//		Timestamp tempEndDate2= chosenStartDate;
//		cU.addDaysToDate(tempEndDate2, 1);

		if (allSubsOnMe.size() != 0) {
			for (int i = 0; i < allSubsOnMe.size(); i++) {

				if (allSubsOnMe.get(i).getCreationDate().before(choosenEndDatePl1TS)) {

					if (allSubsOnMe.get(i).getDeletionDate() != null) {
						if (allSubsOnMe.get(i).getDeletionDate().after(choosenEndDatePl1TS)) {
							counter22++;
						}
					}

//				Und nicht gelöscht wurde
					else {
						counter22++;
					}
				}
			}
		}

		if (counter22 > 0) {
			counter22 -= 1;
		}

		fifthRow.addColumn(new Column(String.valueOf(counter22)));
		subReport.addRow(fifthRow);

//		VERÄNDERUNG IM ZEITRAUM
		Row sixthRow = new Row();
		sixthRow.addColumn(new Column("Veränderung im Zeitraum:"));
		int change2 = 0;
		change2 = counter22 - counter21;
		sixthRow.addColumn(new Column(String.valueOf(change2)));

		subReport.addRow(sixthRow);

		return subReport;
	}

	public CommentReport createCommentReport1(User user, Timestamp choosenStartDate, Timestamp choosenEndDate,
			Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException {
		CommentReport commentReport = new CommentReport();

		Row rowZero = new Row();
		rowZero.addColumn(
				new Column("<b><span style=\"font-size:16px; line-height:1.6;\">Report über Kommentare:</span></b>"));

		commentReport.addRow(rowZero);

		// VON AUSGEWÄHLTEM GESCHRIEBENE KOMMENTARE
		Vector<Comment> allWritten = commentMapper.findAllByUserAndDate(user.getId(), choosenStartDate, choosenEndDate);

//			GESAMTMENGE STARTDATUM
		Row firstRow = new Row();
		firstRow.addColumn(new Column("Geschriebene Kommentare zum Startdatum:"));

		// COUNTER FÜR SUBS AN STARTDATUM
		int counter11 = 0;


		// COUNTER ERHÖHEN WENN STARTDATUM = CHOSENSTARTDATUM
		for (int i = 0; i < allWritten.size(); i++) {

//				Wenn das BO vor dem StartDate erstellt wurde...
			if (allWritten.get(i).getCreationDate().before(choosenStartDatePl1TS)) {

//					Und inzwischen gelöscht wurde, jedoch vor dem Startdatum
				if (allWritten.get(i).getDeletionDate() != null) {
					if (allWritten.get(i).getDeletionDate().after(choosenStartDatePl1TS)) {
						counter11++;
					}
				}

//					Und nicht gelöscht wurde
				else {
					counter11++;
				}
			}
		}

		firstRow.addColumn(new Column(String.valueOf(counter11)));

		commentReport.addRow(firstRow);

//			GESAMTMENGE ENDDATUM
		Row secondRow = new Row();
		secondRow.addColumn(new Column("Geschriebene Kommentare zum Enddatum:"));

		// COUNTER FÜR SUBS AN ENDDATUM
		int counter12 = 0;



		for (int i = 0; i < allWritten.size(); i++) {

//				Wenn das BO vor dem EndDate erstellt wurde...
			if (allWritten.get(i).getCreationDate().before(choosenEndDatePl1TS)) {

//					Und inzwischen gelöscht wurde, jedoch vor dem Enddatum
				if (allWritten.get(i).getDeletionDate() != null) {
					if (allWritten.get(i).getDeletionDate().after(choosenEndDatePl1TS)) {
						counter12++;
					}
				}

//					Und nicht gelöscht wurde
				else {
					counter12++;
				}
			}
		}

		secondRow.addColumn(new Column(String.valueOf(counter12)));
		commentReport.addRow(secondRow);

//			VERÄNDERUNG IM ZEITRAUM
		Row thirdRow = new Row();
		thirdRow.addColumn(new Column("Veränderung im Zeitraum:"));
		int change = counter12 - counter11;
		thirdRow.addColumn(new Column(String.valueOf(change)));

		commentReport.addRow(thirdRow);

		return commentReport;
	}

	public CommentReport createCommentReport2(User user, Timestamp choosenStartDate, Timestamp choosenEndDate,
			Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException {

		CommentReport commentReport = new CommentReport();

//		VOM AUSGEWÄHLTEM ERHALTENE KOMMENTARE	
		Pinboard pin = pinboardMapper.findbyUserID(user.getId());
		Vector<Post> allWrittenPosts = postMapper.findAllByPinboardIDAndPeriod(pin.getId(), choosenStartDate,
				choosenEndDate);
		Vector<Comment> allReceived = new Vector<Comment>();
		for (int i = 0; i < allWrittenPosts.size(); i++) {
			allReceived.addAll(commentMapper.findByPost(allWrittenPosts.elementAt(i).getId()));
		}

//		GESAMTMENGE STARTDATUM
		Row fourthRow = new Row();
		fourthRow.addColumn(new Column("Erhaltene Kommentare zum Startdatum:"));

		// COUNTER FÜR SUBS AN STARTDATUM
		int counter21 = 0;


		// COUNTER ERHÖHEN WENN STARTDATUM = CHOSENSTARTDATUM
		for (int i = 0; i < allReceived.size(); i++) {
			if (allReceived.get(i).getCreationDate().before(choosenStartDatePl1TS)) {

				if (allReceived.get(i).getDeletionDate() != null) {
					if (allReceived.get(i).getDeletionDate().after(choosenStartDatePl1TS)) {
						counter21++;
					}
				}

//				Und nicht gelöscht wurde
				else {
					counter21++;
				}
			}
		}

		fourthRow.addColumn(new Column(String.valueOf(counter21)));
		commentReport.addRow(fourthRow);

//		GESAMTMENGE ENDDATUM
		Row fifthRow = new Row();
		fifthRow.addColumn(new Column("Erhaltene Kommentare zum Enddatum:"));

		// COUNTER FÜR SUBS AN ENDDATUM
		int counter22 = 0;


		for (int i = 0; i < allReceived.size(); i++) {

			if (allReceived.get(i).getCreationDate().before(choosenEndDatePl1TS)) {

				if (allReceived.get(i).getDeletionDate() != null) {
					if (allReceived.get(i).getDeletionDate().after(choosenEndDatePl1TS)) {
						counter22++;
					}
				}

//				Und nicht gelöscht wurde
				else {
					counter22++;
				}
			}
		}

		fifthRow.addColumn(new Column(String.valueOf(counter22)));
		commentReport.addRow(fifthRow);

//		VERÄNDERUNG IM ZEITRAUM
		Row sixthRow = new Row();
		sixthRow.addColumn(new Column("Veränderung im Zeitraum:"));
		int change2 = counter22 - counter21;
		sixthRow.addColumn(new Column(String.valueOf(change2)));

		commentReport.addRow(sixthRow);

		return commentReport;
	}

	public PostReport createPostReport1(User user, Timestamp choosenStartDate, Timestamp choosenEndDate,
			Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException {
		PostReport postReport = new PostReport();

		Row rowZero = new Row();
		rowZero.addColumn(
				new Column("<b><span style=\"font-size:16px; line-height:1.6;\">Report über Beiträge:</span></b>"));

		postReport.addRow(rowZero);

		// VON AUSGEWÄHLTEM GESCHRIEBENE KOMMENTARE
		Pinboard pin = pinboardMapper.findbyUserID(user.getId());
		Vector<Post> allPostsWritten = postMapper.findAllByPinboardIDAndPeriod(pin.getId(), choosenStartDate,
				choosenEndDate);

//			GESAMTMENGE STARTDATUM
		Row firstRow = new Row();
		firstRow.addColumn(new Column("Geschriebene Beiträge zum Startdatum:"));

		// COUNTER FÜR SUBS AN STARTDATUM
		int counter11 = 0;


		// COUNTER ERHÖHEN WENN STARTDATUM = CHOSENSTARTDATUM
		for (int i = 0; i < allPostsWritten.size(); i++) {

//				Wenn das BO vor dem StartDate erstellt wurde...

			if (allPostsWritten.get(i).getCreationDate().before(choosenStartDatePl1TS)) {

//					Und inzwischen gelöscht wurde, jedoch vor dem Startdatum
				if (allPostsWritten.get(i).getDeletionDate() != null) {
					if (allPostsWritten.get(i).getDeletionDate().after(choosenStartDatePl1TS)) {
						counter11++;
					}
				}

//					Und nicht gelöscht wurde
				else {
					counter11++;
				}
			}
		}

		firstRow.addColumn(new Column(String.valueOf(counter11)));

		postReport.addRow(firstRow);

//			GESAMTMENGE ENDDATUM
		Row secondRow = new Row();
		secondRow.addColumn(new Column("Geschriebene Beiträge zum Enddatum:"));

		// COUNTER FÜR SUBS AN ENDDATUM
		int counter12 = 0;


		for (int i = 0; i < allPostsWritten.size(); i++) {

//				Wenn das BO vor dem EndDate erstellt wurde...

			if (allPostsWritten.get(i).getCreationDate().before(choosenEndDatePl1TS)) {

//					Und inzwischen gelöscht wurde, jedoch vor dem Enddatum
				if (allPostsWritten.get(i).getDeletionDate() != null) {
					if (allPostsWritten.get(i).getDeletionDate().after(choosenEndDatePl1TS)) {
						counter12++;
					}
				}

//					Und nicht gelöscht wurde
				else {
					counter12++;
				}
			}
		}

		secondRow.addColumn(new Column(String.valueOf(counter12)));
		postReport.addRow(secondRow);

//			VERÄNDERUNG IM ZEITRAUM
		Row thirdRow = new Row();
		thirdRow.addColumn(new Column("Veränderung im Zeitraum:"));
		int change = counter12 - counter11;
		thirdRow.addColumn(new Column(String.valueOf(change)));

		postReport.addRow(thirdRow);

//			Informationen über Kommentare je Beitrag und Zeitraum
//			Informationen Likes je Beitrag und Zeitraum
		Row fourthRow = new Row();
		fourthRow.addColumn(new Column("<b>Beitrag</b>"));
		fourthRow.addColumn(new Column("<b>Erhaltene Likes</b>"));
		fourthRow.addColumn(new Column("<b>Erhaltene Kommentare </b>"));

		postReport.addRow(fourthRow);

		Pinboard pinbrd = pinboardMapper.findbyUserID(user.getId());
		int pinID = pinbrd.getId();
		Vector<Post> allPosts = postMapper.findAllByPinboardIDAndPeriod(pinID, choosenStartDate, choosenEndDate);

		for (int i = 0; i < allPosts.size(); i++) {

			if (allPosts.get(i).getCreationDate().after(choosenStartDate)
					&& allPosts.get(i).getCreationDate().before(choosenEndDatePl1TS)) {

				Row tempRow = new Row();
				tempRow.addColumn(new Column(allPosts.get(i).getText()));

				Vector<Like> allLikes = likeMapper.findAllByPost(allPosts.get(i).getId());
				Integer likes = allLikes.size();
				Vector<Comment> allComments = commentMapper.findByPost(allPosts.get(i).getId());
				Integer comments = allComments.size();

				tempRow.addColumn(new Column(likes.toString()));
				tempRow.addColumn(new Column(comments.toString()));

				postReport.addRow(tempRow);

			}

		}

		return postReport;
	}

	public LikeReport createLikeReport1(User user, Timestamp choosenStartDate, Timestamp choosenEndDate,
			Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException {
		LikeReport likeReport = new LikeReport();

		Row rowZero = new Row();
		rowZero.addColumn(
				new Column("<b><span style=\"font-size:16px; line-height:1.6;\">Report über Likes:</span></b>"));

		likeReport.addRow(rowZero);

		// VON AUSGEWÄHLTEM GESCHRIEBENE KOMMENTARE
		Vector<Like> allLikesGiven = likeMapper.findAllbyUserAndPeriod(user.getId(), choosenStartDate, choosenEndDate);

//			GESAMTMENGE STARTDATUM
		Row firstRow = new Row();
		firstRow.addColumn(new Column("Vergebene Likes zum Startdatum:"));

		// COUNTER FÜR SUBS AN STARTDATUM
		int counter11 = 0;


		// COUNTER ERHÖHEN WENN STARTDATUM = CHOSENSTARTDATUM
		for (int i = 0; i < allLikesGiven.size(); i++) {

//				Wenn das BO vor dem StartDate erstellt wurde...
//				Zu dem Timestamp werden 2 Tage hinzugefügt
//				Der erste Tag, da die Anweisung nur die Methode before, also nicht kleiner gleich ermöglicht
//				Der zweite, da 

			if (allLikesGiven.get(i).getCreationDate().before(choosenStartDatePl1TS)) {

//					Und inzwischen gelöscht wurde, jedoch vor dem Startdatum
				if (allLikesGiven.get(i).getDeletionDate() != null) {
					if (allLikesGiven.get(i).getDeletionDate().after(choosenStartDatePl1TS)) {
						counter11++;
					}
				}

//					Und nicht gelöscht wurde
				else {
					counter11++;
				}
			}
		}

		firstRow.addColumn(new Column(String.valueOf(counter11)));

		likeReport.addRow(firstRow);

//			GESAMTMENGE ENDDATUM
		Row secondRow = new Row();
		secondRow.addColumn(new Column("Vergebene Likes zum Enddatum:"));

		// COUNTER FÜR SUBS AN ENDDATUM
		int counter12 = 0;


		for (int i = 0; i < allLikesGiven.size(); i++) {

//				Wenn das BO vor dem EndDate erstellt wurde...
			if (allLikesGiven.get(i).getCreationDate().before(choosenEndDatePl1TS)) {

//					Und inzwischen gelöscht wurde, jedoch vor dem Enddatum
				if (allLikesGiven.get(i).getDeletionDate() != null) {
					if (allLikesGiven.get(i).getDeletionDate().after(choosenEndDatePl1TS)) {
						counter12++;
					}
				}

//					Und nicht gelöscht wurde
				else {
					counter12++;
				}
			}
		}

		secondRow.addColumn(new Column(String.valueOf(counter12)));
		likeReport.addRow(secondRow);

//			VERÄNDERUNG IM ZEITRAUM
		Row thirdRow = new Row();
		thirdRow.addColumn(new Column("Veränderung im Zeitraum:"));
		int change = counter12 - counter11;
		thirdRow.addColumn(new Column(String.valueOf(change)));

		likeReport.addRow(thirdRow);

		return likeReport;
	}

	public LikeReport createLikeReport2(User user, Timestamp choosenStartDate, Timestamp choosenEndDate,
			Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException {
		LikeReport likeReport = new LikeReport();

//		VOM AUSGEWÄHLTEM ERHALTENE LIKES	
		Pinboard pin = pinboardMapper.findbyUserID(user.getId());
		Vector<Post> allPostsWritten = postMapper.findAllByPinboardIDAndPeriod(pin.getId(), choosenStartDate,
				choosenEndDate);
		Vector<Like> allLikesReceived = new Vector<Like>();
		for (int i = 0; i < allPostsWritten.size(); i++) {
			allLikesReceived.addAll(likeMapper.findAllByPostAndPeriod(allPostsWritten.elementAt(i).getId()));
		}

//		GESAMTMENGE STARTDATUM
		Row fourthRow = new Row();
		fourthRow.addColumn(new Column("Erhaltene Likes zum Startdatum:"));

		// COUNTER FÜR SUBS AN STARTDATUM
		int counter21 = 0;


		// COUNTER ERHÖHEN WENN STARTDATUM = CHOSENSTARTDATUM
		for (int i = 0; i < allLikesReceived.size(); i++) {

			if (allLikesReceived.get(i).getCreationDate().before(choosenStartDatePl1TS)) {

				if (allLikesReceived.get(i).getDeletionDate() != null) {
					if (allLikesReceived.get(i).getDeletionDate().after(choosenStartDatePl1TS)) {
						counter21++;
					}
				}

//				Und nicht gelöscht wurde
				if (allLikesReceived.get(i).getDeletionDate() == null) {
					counter21++;
				}
			}
		}

		fourthRow.addColumn(new Column(String.valueOf(counter21)));
		likeReport.addRow(fourthRow);

//		GESAMTMENGE ENDDATUM
		Row fifthRow = new Row();
		fifthRow.addColumn(new Column("Erhaltene Likes zum Enddatum:"));

		// COUNTER FÜR SUBS AN ENDDATUM
		int counter22 = 0;

		for (int i = 0; i < allLikesReceived.size(); i++) {

			if (allLikesReceived.get(i).getCreationDate().before(choosenEndDatePl1TS)) {

				if (allLikesReceived.get(i).getDeletionDate() != null) {
					if (allLikesReceived.get(i).getDeletionDate().after(choosenEndDatePl1TS)) {
						counter22++;
					}
				}

//				Und nicht gelöscht wurde
				if (allLikesReceived.get(i).getDeletionDate() == null) {
					counter22++;
				}
			}
		}

		fifthRow.addColumn(new Column(String.valueOf(counter22)));
		likeReport.addRow(fifthRow);

//		VERÄNDERUNG IM ZEITRAUM
		Row sixthRow = new Row();
		sixthRow.addColumn(new Column("Veränderung im Zeitraum:"));
		int change2 = counter22 - counter21;
		sixthRow.addColumn(new Column(String.valueOf(change2)));

		likeReport.addRow(sixthRow);

		return likeReport;
	}

}
