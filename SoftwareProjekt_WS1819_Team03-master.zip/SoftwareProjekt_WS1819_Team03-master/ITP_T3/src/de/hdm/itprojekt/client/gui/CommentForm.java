package de.hdm.itprojekt.client.gui;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.bo.Comment;
import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author SimonJanik 
 * Form zum Anzeigen von einzelnen Kommentaren
 */

public class CommentForm extends VerticalPanel {

	User user = null;
	Comment comment = null;
	PostForm postForm;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();


	Label commentHeader;
	TextArea commentText;
	HorizontalPanel header;
	InteractionCommentForm interactionForm;
	CommentEditForm commentEditor;
	private InteractionPostFormAll interactionPostFromAll;

	/**
	 * Default-Konstruktor
	 */

	public CommentForm() {

	}
	
	/**
	 * Konstruktor
	 * @param c ist der dazugehörige Kommentar, der angzeigt werden soll
	 * @param u ist der dem Kommentar zugehörige User
	 * @param pf ist die dem Kommentar zugehörige PostForm (bzw. Post)
	 * @param interac ist die dem Kommentar zugehörige InteractionForm
	 */

	public CommentForm(Comment c, User u,PostForm pf, InteractionPostFormAll interac) {
		this.comment = c;
		this.postForm = pf;
		this.user = u;
		this.interactionPostFromAll = interac;
		
	}
	
	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */

	public void onLoad() {
		super.onLoad();
		
		this.clear();
		header = new HorizontalPanel();
		VerticalPanel headerTitel = new VerticalPanel();
		Label commentDate = new Label(this.comment.getCreationDate().toGMTString().substring(0, this.comment.getCreationDate().toGMTString().length()-3));
		commentDate.setStyleName("CommentDate");
		commentHeader = new Label();
		commentHeader.setText(this.comment.getAuthorNickName() + " hat folgenden Kommentar geschrieben");
		headerTitel.add(commentDate);
		headerTitel.add(commentHeader);
		interactionForm = new InteractionCommentForm(this.comment, this,this.postForm,interactionPostFromAll);
		header.add(headerTitel);
		
		
		/**
		 * Wenn der Kommentar dem angemeldeten Nutzer gehört, soll dieser die Möglichkeit bekommen seinen 
		 * Kommenar bearbeiten zu können. Dem <code> header </code> der CommentForm wird dann 
		 * die <code> interactionForm </code> hinzugefügt.
		 */
		if(this.user.getId() == this.comment.getAuthorID()) {
			header.add(interactionForm);
		}
		
		commentText = new TextArea();
		// Der aktuelle Text des Kommentars wird dem Textfeld hinzugefügt.
		commentText.setText(this.comment.getText());
		resizeTextArea();
		
		this.add(header);
		this.resizeTextArea();
		this.add(commentText);
		
		/**
		 * Alle CSS-Bezeichner für den Inhalt des Panels. Die Konfiguration der
		 * Bezeichner können in war>ITP_T3.css geändert werden.
		 */
		this.addStyleName("CommentForm");
		header.addStyleName("CommentHeader");
		interactionForm.addStyleName("CommentInteraction");

		/**
		 * Der Kommentar (in der angezeigten TextBox) soll ausschließlich nur gelesen werden dürfen und nicht änderbar sein.
		 * Änderungen werden nur über Edit-Button der <code> interactionForm </code> akzeptiert.
		 */
		commentText.setEnabled(false);
	}

	/*
	 * AB HIER: Alle Methoden der Klasse
	 */

	// Zum Schließen der CommentForm
	public void closeCommentForm() {
		this.remove(commentHeader);
		this.remove(commentText);
		this.remove(interactionForm);
		this.removeFromParent();
	}

	/**
	 * Zum Hinzufügen eines Kommentars in den angezeigten <code> commentText </code>
	 * @param c ist der Kommentar, der der CommentForm hinzugefügt wird.
	 */
	public void addCommentToForm(Comment c) {
		this.comment = c;
		commentText.setText(c.getText());
	}

	/**
	 * Zum Hinzufügen eines Kommentars in den angezeigten <code> commentText </code>
	 * @param c ist der Kommentar, der der CommentForm hinzugefügt wird.
	 * @param u ist der Autor des Kommentars
	 */
	public void addCommentToForm(Comment c, User u) {
		this.comment = c;
		this.user = u;
		commentHeader.setText(u.getNickName() + " hat folgenden Kommentar geschrieben:");
		commentText.setText(c.getText());
	}

	/**
	 * Zum Setzen des Infotext. Zur Laufzeit wird dieser mit dem Autorennamen und dem Zusatz 
	 * " hat folgenden Kommentar geschrieben" festgelegt.
	 * @param s ist der InfoText, der über dem Kommentar angezeigt wird.
	 */
	public void setInfoText(String s) {
		commentHeader.setText(s);
	}
	
	/**
	 * Getter-Methode des Kommentars
	 * @return gibt den Kommentar zurück, der in der CommentForm angezeigt wird.
	 */
	public Comment getItsComment() {
		return this.comment;
	}
	
	/**
	 * Zur Anpassung der TextArea auf die Länge des Kommentars.
	 */
	public void resizeTextArea() {
		int linebreaks = countLineBreaksInText();
		
		if (linebreaks == 3 || commentText.getText().length() > 90) {
			commentText.setVisibleLines(3);
		}
		if (linebreaks == 4 || commentText.getText().length() > 180) {
			commentText.setVisibleLines(4);
		}
		if (linebreaks == 5 || commentText.getText().length() > 270) {
			commentText.setVisibleLines(5);
		}
		if (linebreaks == 6 ||commentText.getText().length() > 360) {
			commentText.setVisibleLines(6);
		}
		if (linebreaks == 7 || commentText.getText().length() > 450) {
			commentText.setVisibleLines(7);
		}
		if (linebreaks == 8 || commentText.getText().length() > 540) {
			commentText.setVisibleLines(8);
		}

	}
	
	public int countLineBreaksInText(){
		int lastIndex = 0;
		int count = 0;
		final String searchText = commentText.getText();
		final String searchWord = "\n";

			while(lastIndex != -1){

			    lastIndex = searchText.indexOf(searchWord,lastIndex);

			    if(lastIndex != -1){
			        count ++;
			        lastIndex += searchWord.length();
			    }
		}
		return count;
	}
}
