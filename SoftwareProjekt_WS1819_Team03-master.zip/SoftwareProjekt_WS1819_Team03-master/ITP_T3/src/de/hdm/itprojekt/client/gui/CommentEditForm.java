package de.hdm.itprojekt.client.gui;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.Comment;

/**
 * 
 * @author SimonJanik 
 * CommentEditForm enthält alle grafischen Elemente und
 * Events die zum Ändern eines Kommentars benötigt werden. Diese Form
 * öffnet sich als DialogBox. Die Klasse enthält Methoden zum Öffnen und
 * Schließen der Form.
 */

public class CommentEditForm extends DialogBox {


	Comment comment = null;
	CommentForm commentForm = null;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();

	Button closeButton = new Button("X");
	Label changeLabel = new Label("Kommentar bearbeiten:");
	TextArea changeBox = new TextArea();
	Button saveButton = new Button("Änderungen speichern");
	VerticalPanel content = new VerticalPanel();
	final Label info = new Label("Bitte Textfeld befüllen!");
	final Label textToLong = new Label("Bitte kürze deinen Kommentar. Dieser darf nur eine Länge von 300 Zeichen haben!");
	private CommentEditVerfifyCallback verifyCallback;
	private SaveCommentChangesClickHandler saveCommentsClick;
	private CloseCommentEditFormClickHandler closeCommentClick;
	private CommentKeyPressHandler commentKeyPress;

	/**
	 * Konstruktor der CommentEditForm
	 * @param c ist der dazugehörige Kommentar
	 * @param comF ist die dem Kommentar zugehörige CommentForm
	 */
	public CommentEditForm(Comment c, CommentForm comF) {
		this.comment = c;
		this.commentForm = comF;
		verifyCallback = new CommentEditVerfifyCallback();
		saveCommentsClick = new SaveCommentChangesClickHandler();
		closeCommentClick = new CloseCommentEditFormClickHandler();
		commentKeyPress = new CommentKeyPressHandler();
		

	}
	
	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Widget, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Widget hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */

	public void onLoad() {
		super.onLoad();
		content.add(closeButton);
		content.add(changeLabel);
		content.add(changeBox);
		content.add(saveButton);
		saveButton.addClickHandler(saveCommentsClick);
		closeButton.addClickHandler(closeCommentClick);
		changeBox.addKeyPressHandler(commentKeyPress);
		this.add(content);

		/**
		 * Alle CSS-Bezeichner für den Inhalt des Panels. Die Konfiguration der
		 * Bezeichner können in war>ITP_T3.css geändert werden.
		 */
		changeBox.addStyleName("TextEditor");

	}

	/*
	 * Ab hier folgen alle CLICKHANDLER und CALLBACKS dieser Klasse!
	 */

	/**
	 * SaveCommentChangesClickHandler: Wird beim Click auf <code> saveButton </code> ausgelöst.
	 * Zunächst wird in der <code> onClick(ClickEvent event) </code>-Methode geprüft, ob der Nutzer
	 * ausschließlich Leerzeichen in die <code> changeBox </code> eingegeben hat.
	 */
	class SaveCommentChangesClickHandler implements ClickHandler {

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			if(changeBox.getText().length()>300) {
				content.add(textToLong);
			}else {
			editorAdministration.verifyField(new String[] { changeBox.getText() }, verifyCallback);
			}
			}
	}
	
	/**
	 * CommentKeyPressHandler: Wird beim Drücken von <code> KeyCodes.KEY_ESCAPE </code> oder 
	 * <code> KeyCodes.KEY_ENTER </code> ausgelöst.
	 * Bei <code> KeyCodes.KEY_ESCAPE </code> wird die CommentEditForm geschlossen.
	 * Bei <code> KeyCodes.KEY_ENTER </code> wird zunächst geprüft, ob der Nutzer
	 * ausschließlich Leerzeichen in die <code> changeBox </code> eingegeben hat.
	 */

	class CommentKeyPressHandler implements KeyPressHandler {

		@Override
		public void onKeyPress(KeyPressEvent event) {
			// TODO Auto-generated method stub
			if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ESCAPE) {
				closeCommentEditForm();
			}
			if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ENTER) {
				if(changeBox.getText().length()>300) {
					content.add(textToLong);
				}else {
				editorAdministration.verifyField(new String[] { changeBox.getText() }, verifyCallback);
				}
				}
		}

	}
	
	/**
	 * CallBack auf den <code> CommentEditVerfifyCallback </code>:
	 * Bei erfolgreichem Rückruf (onSucess) wird der geänderte Kommentar als String
	 * der CommentForm gesetzt. Danach wird die CommentEditForm geschlossen.
	 */
	class UpdateCommentCallBack implements AsyncCallback<Comment> {

		private Comment comment = null;
		private CommentForm commentForm;

		private UpdateCommentCallBack(Comment c, CommentForm commentForm) {
			this.comment = c;
			this.commentForm = commentForm;

		}

		//Bei einem Fehler wird die Anwendung nochmals neu geladen.
		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			 if (caught instanceof NotLoggedInException) {
			      Window.Location.reload();
			    }

		}

		@Override
		public void onSuccess(Comment result) {
			// TODO Auto-generated method stub
			this.commentForm.commentText.setText(result.getText());
			closeCommentEditForm();

		}

	}

	/**
	 * CloseCommentEditFormClickHandler: Wird beim Click auf <code> closeButton </code> ausgeführt.
	 * Die CommentEditForm wird geschlossen.
	 */

	class CloseCommentEditFormClickHandler implements ClickHandler {

		@Override
		public void onClick(ClickEvent event) {
			closeCommentEditForm();

		}

	}
	
	/**
	 * CommentEditVerfifyCallback:
	 * Nach erfolgreicher Verifikation des geänderten Kommentars(<code> onSuccess(String[] result) </code>) wird dieser
	 * der eigentlichen <code> updateComment </code>-Methode übergeben.
	 */

	class CommentEditVerfifyCallback implements AsyncCallback<String[]> {

		//Bei einem Fehler wird die Anwendung nochmals neu geladen.
		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());
		}

		@Override
		public void onSuccess(String[] result) {
			// TODO Auto-generated method stub

			if (result != null) {
				comment.setText(result[0]);
				editorAdministration.updateComment(comment, new UpdateCommentCallBack(comment, commentForm));
			} else {
				changeBox.getElement().setPropertyString("placeholder", "Bitte einen gültigen Text eingeben!");
			}

		}

	}

	/*
	 * Methoden zum Öffnen und Schließen der CommentEditForm.
	 */
	public void closeCommentEditForm() {
		this.hide();
		this.clear();
		this.removeFromParent();
		this.setAnimationEnabled(false);
		this.setGlassEnabled(false);

	}

	public void openCommentEditForm() {
		this.setGlassEnabled(true);
		this.setAnimationEnabled(true);
		this.center();
		this.show();
		this.changeBox.setText(this.commentForm.commentText.getText());
		changeBox.setFocus(true);
		if (this.info.isAttached() == true) {
			this.content.remove(this.info);
		}
		if(this.textToLong.isAttached() == true) {
			this.content.remove(this.textToLong);
		}

	}
	
	/**
	 * getter-Methode, um den Text aus der <code> changeBox </code> zu erhalten.
	 * @return ist der String-Text aus der <code> changeBox </code>.
	 */
	public String getPostText() {
		return changeBox.getText();
	}

	/**
	 * setter-Methode, um den Text der <code> changeBox </code> zu setzen.
	 * @param ist der String-Text, der in die <code> changeBox </code> gesetzt werdeen soll.
	 */
	public void setPostText(String text) {
		changeBox.setText(text);
	}

}
