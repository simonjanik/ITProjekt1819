package de.hdm.itprojekt.client.gui;

import java.sql.Date;


import java.sql.Timestamp;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.bo.*;


/**
 * @author FelixBieswanger
 * PostFormShort dient der verkürzten Anzeige eines Posts im NewsFeed.
 * Dies beinhaltet den Namen des Autors, eine Kurzform des <code>post</code>-Textes
 * und einer Zeitanzeige.
 */

public class PostFormShort extends VerticalPanel {

	private Post post;
	private User user;
	private SubForm subForm;
	private Label date;

	/**
	 * Default-Konstruktor
	 */
	public PostFormShort() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Konstruktor der PostFormShort
	 * @param p ist Post, der angezeigt werden soll
	 * @param u ist der Autor des Posts
	 * @param subf gibt die Möglichkeit, über Click auf den Nicknamen, deren Pinnwand anzeigen zu lassen.
	 */
	public PostFormShort(Post p, User u, SubForm subf) {
		this.post = p;
		this.user = u;
		this.subForm = subf;
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Dem Label werden dessen Funktion entsprechend ein ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();
		
		//Panel & Widgets
		HorizontalPanel headText = new HorizontalPanel();
		Label authorLabel = new Label(post.getAuthorNickName()+" ");
		Label head = new Label("schrieb");
		Label textLabel = new Label('"'+convertPostText(post.getText())+'"');
		/*
		 * Angezeigte Zeit: Zeitlicher Abstand zwischen aktuellem Datum und Erstellungsdatum des Posts
		 * Der Nutzer kann dadurch nachvollziehen wie lange ein geschriebener Post zeitlich zurückliegt. 
		 */
		date = new Label(compareToCurrentTime(post.getCreationDate()));

		/*
		 * Dieser Timer wird jede Sekunde aktualisiert: So wird sichergestellt, dass der 
		 * zeitliche Abstand zum Erstellungsdatum des Posts immer aktuell bleibt.
		 */
		Timer refresh = new Timer() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				if (date.getText() != compareToCurrentTime(post.getCreationDate())) {
					date.setText(compareToCurrentTime(post.getCreationDate()));
				}

			}
		};
		refresh.scheduleRepeating(999);
		authorLabel.addClickHandler(new HeadClickHandler(post));

		//Hinzufügen der grafischen Elemente zu diesem Panel
		headText.add(authorLabel);
		headText.add(head);
		headText.add(textLabel);
		this.add(headText);
		this.add(date);

		//CSS-Klassenselektoren
		this.setStyleName("NewsFeedPost");
		authorLabel.setStyleName("NewsFeedAuthorLabel");
		head.setStyleName("NewsFeedHead");
		textLabel.setStyleName("NewsFeedText");
		headText.setStyleName("NewsFeedHeadText");
		date.setStyleName("NewsFeedDate");

	}
	
	/**
	 * <code>HeadClickHandler</code> des <code>authorLabel</code>: Ermöglicht es dem Nutzer
	 * die Pinnwand desjeweiligen Autors anzeigen zu lassen.
	 */
	class HeadClickHandler implements ClickHandler {

		private Post post;

		private HeadClickHandler(Post p) {
			// TODO Auto-generated constructor stub
			this.post = p;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			subForm.setSelectedPinboard(this.post.getAuthorNickName());
		}

	}

	/**
	 * Vergleicht einen Zeitstempel mit der aktuellen Zeit und gibt ein String zurück. 
	 * (Zur grafischen Anzeige in der <code>PostFormShort</code>).
	 * @param postTime ist der Zeitstempel, der mit der aktuellen Zeit verglichen werden soll.
	 * @return ist die dargestellt Differnz zwischen Zeitstempel und aktueller Zeit in Form eines Strings
	 */
	public String compareToCurrentTime(Timestamp postTime) {

		//Aktuelles Datum
		Timestamp currentTime = new Timestamp(System.currentTimeMillis());
		//Differenz zwischen aktuellem Datum und Erstellungsdtum des Posts
		Long result = (currentTime.getTime() - postTime.getTime()) / (1000) + 3599;
		
		// Sekunden
		//Wenn die Differenz kleiner als 60 Sekunden ist, soll "gerade" ausgegeben werden
		if (result < 60) {
			return "gerade";
		}
		result /= 60;
		
		// Minuten
		/*
		 * Wenn die Differenz kleiner als 60 Sekunden und gleich 1 Minute ist, 
		 * soll "vor " + result + " Minute" ausgegeben werden.
		 */
		if (result < 60) {
			if (result == 1) {
				return "vor " + result + " Minute";
			}
			return "vor " + result + " Minuten";
		}

		result /= 60;
		
		// Stunden
		/*
		 * Wenn die Differenz kleiner als 24 Stunden ist und genau 1 Stunde beträgt, 
		 * soll "vor " + result + " Stunde" ausgegeben werden, sonst "vor " + result + " Stunden".
		 */
		if (result < 24) {
			if (result == 1) {
				return "vor " + result + " Stunde";
			}
			return "vor " + result + " Stunden";
		}

		result /= 24;
		
		// Tage
		/*
		 * Wenn die Differenz kleiner als 24 Stunden ist und genau 1 Stunde beträgt, 
		 * soll "vor " + result + " Stunde" ausgegeben werden, sonst "vor " + result + " Stunden".
		 */
		if (result == 1) {
			return "vor " + result + " Tag";
		}
		return "vor " + result + " Tagen";

	}

	//Zur verkürzten Darstellung eines Posts (max. 20 Zeichen)
	private String convertPostText(String text) {

		if (text.length() > 20) {
			return text.substring(0, 20) + "...";
		} else {
			return text;
		}

	}
}
