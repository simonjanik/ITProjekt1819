package de.hdm.itprojekt.client.gui;

import java.util.Date;
import java.util.Vector;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.PushButton;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.bo.Like;
import de.hdm.itprojekt.shared.bo.Post;
import de.hdm.itprojekt.shared.bo.User;

import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;

/**
 * 
 * @author SimonJanik
 * InteractionPostFormOwn beinhaltet alle grafischen Elemente, um den eigenen Post zu editieren oder zu löschen.
 * Diese Form ist Teil der <code> PostForm </code> und wird in der oberen rechten Ecke eines Posts angezeigt,
 * wenn dieser dem User selber gehört.
 */

public class InteractionPostFormOwn extends HorizontalPanel {

	User user = null;
	Post post = null;
	PostForm postForm = null;
	PinboardForm pinboardForm;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	Image deleteIcon = new Image("baseline_delete_outline_white_48dp.png");
	PushButton deleteButton = new PushButton(deleteIcon);
	Image editIcon = new Image("baseline_edit_white_48dp.png");
	PushButton editButton = new PushButton(editIcon);

	/**
	 * Konstruktor der InteractionPostFormOwn
	 * @param p ist der zugehörige Post, der bearbeitet werden soll
	 * @param pf ist die zugehörige PostForm, zudem dieses Panel gehören soll
	 * @param pinf ist die Pinboard auf dem der Post angezeigt wird
	 */
	public InteractionPostFormOwn(Post p, PostForm pf, PinboardForm pinf) {
		this.post = p;
		this.postForm = pf;
		this.pinboardForm = pinf;
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();

		/**
		 * Aber hier folgen die CSS-Klassenbezeichner für den Inhalt des Panels. Die
		 * Konfiguration der Bezeichner können in war>ITP_T3.css geändert werden.
		 * 
		 */
		this.addStyleName("InteractionPostFormOwn");
		editButton.addStyleName("ownEditPostButton");
		deleteButton.addStyleName("ownDeletePostButton");

		// Aufnahme der Buttons in dieses Panel
		this.add(editButton);
		this.add(deleteButton);

		//Buttons werden ClickHandler hinzugefügt
		deleteButton.addClickHandler(new DeletePostClickHandler(this.post, this.postForm));
		editButton.addClickHandler(new EditPostClickHandler(this.post, this.postForm));

	}
	
	/**
	 * DeletePostClickHandler: Wird beim Click auf den <code> deleteButton </code> ausgeführt.
	 * Die <code> PostDeleteForm </code> wird erzeugt und geöffnet.
	 */
	class DeletePostClickHandler implements ClickHandler {
		private Post post = null;
		private PostForm postForm = null;

		DeletePostClickHandler(Post p, PostForm pf) {
			this.post = p;
			this.postForm = pf;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			PostDeleteForm postDeleteForm = new PostDeleteForm(this.post, this.postForm, pinboardForm);
			postDeleteForm.openPostDeleteForm();

		}

	}
	
	/**
	 * EditPostClickHandler: Wird beim Click auf den <code> editButton </code> ausgeführt.
	 * Die <code> PostEditForm </code> wird erzeugt und geöffnet.
	 */
	class EditPostClickHandler implements ClickHandler {
		private Post post = null;
		private PostForm postForm = null;

		EditPostClickHandler(Post p, PostForm pf) {
			this.post = p;
			this.postForm = pf;

		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			PostEditForm postEditForm = new PostEditForm(this.post, this.postForm);
			postEditForm.openPostEditForm();
		}

	}
	
	

}
