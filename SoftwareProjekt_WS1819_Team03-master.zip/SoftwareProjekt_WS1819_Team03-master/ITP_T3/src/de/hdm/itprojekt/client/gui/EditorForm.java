package de.hdm.itprojekt.client.gui;

//import java.util.Date;
import java.sql.Date;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author SimonJanik
 * EditorForm vereint alle grafischen Elemente dieses Packages, zur kompletten Anzeige
 * des Social-Media-Pinnwandsystems
 */

public class EditorForm extends VerticalPanel{
	
	/* 
	 * currentUser speichert den aktuellen Nutzer
	 */
	protected User currentUser = null;
	
	/**
	 * <code>header</code>: Oberer Teil des Fensters. Erstreckt sich über die ganze Länge der Anwendung. Enhält die Formen <code>searchUserForm</code>
	 * <code>main</code>: Zentraler Bestandteil. Umschließt alle anderen Panels, außer <code>header</code>
	 * <code>center</code>: Mitte der Anwendung. Enhält die <code>PinForm</code>
	 * <code>west</code>: Rechte Seite der Anwendung. Enhält die Formen <code>profilform</code> und <code>subForm</code>
	 * <code>newsFeed</code>: Linke Seite der Anwendung. Ist der <code>NewsFeed</code>.
	 */

	HorizontalPanel header = new HorizontalPanel();
	HorizontalPanel main = new HorizontalPanel();
	
	VerticalPanel center = new VerticalPanel();
	VerticalPanel west = new VerticalPanel();
	
	/**
	 * 
	 * @param currentUser 
	 * Der aktuelle Nutzer wird der EditorForm übergeben. So können alle anderen Formen diesen bei Bedarf verwenden.
	 * 
	 */
	
	public EditorForm(User currentUser) {
		this.currentUser = currentUser;
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 */
	public void onLoad() {
		super.onLoad();
		
		/*
		 * CSS-StyleName-Vergabe, um Panels direkt anzusprechen.
		 */
		
		this.addStyleName("EditorForm");
		header.addStyleName("Header");
		main.addStyleName("Main");
		west.addStyleName("West");
		
		
		/*
		 * Instanzierung aller nötigen Formen, die in der EditorForm angezeigt werden sollen. 
		 */
		
		Image logo = new Image("Offical_Logo.png");
		SearchUserForm searchUserForm = new SearchUserForm(currentUser);
		SubForm subForm = new SubForm(currentUser);
		PinboardForm pinForm = new PinboardForm(currentUser);
		ProfilForm profilform = new ProfilForm(currentUser, this);
		searchUserForm.setSubForm(subForm);
		subForm.setPinboardForm(pinForm);
		
		profilform.addStyleName("ProfilInEditorForm");
		
		/**
		 *  Jede Form wird demjeweiligen Panel hinzugefügt.
		 */
	
		
		west.add(subForm);
		west.add(profilform);
		center.add(pinForm);
		
		main.add(west);
		main.add(center);
		
		//Hinzufügen des NewsFeeds
		NewsFeed newsFeed = new NewsFeed(currentUser);
		newsFeed.setSubForm(subForm);
		newsFeed.setStyleName("Newsfeed");
		main.add(newsFeed);
		
		
		header.add(logo);
		header.add(searchUserForm);
		
		//Button, dessen ClickEvent zum Report-Generator führt.
		Button toReport = new Button("Report", new ClickHandler() {
			@Override
			public void onClick(ClickEvent event) {
				// TODO Auto-generated method stub
				Window.Location.replace("/Report.html");
			}
		});
		header.add(toReport);
		
		//Die zwei Hauptpanels werden der EditorForm hinzugefügt.
		this.add(header);
		this.add(main);
		
		
		
		
	}

}
