package de.hdm.itprojekt.client.gui;

import java.awt.Dialog;
import java.util.Vector;

import com.google.gwt.aria.client.TextboxRole;
import com.google.gwt.dev.shell.CloseButton;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.client.ui.Widget;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author SimonJanik
 * @author FelixBieswanger
 * @author LeonieHeiduk 
 * ProfilForm: Enthält alle Elemente zur Darstellung unter Interaktion mit einem Profil:
 * Das Profil enthählt eine Überschrift, den Nicknamen, den Vornamen und den Nachnamen des Nutzers.
 * Über Buttons lässt sich das Profil bearbeiten (<code>editButton</code>) und löschen (<code>deleteProfilBttn</code>).
 *
 */

public class ProfilForm extends VerticalPanel {

	/**
	 * <code>parentForm</code>: Die EditorForm beinhaltet die Profilform. Diese muss 
	 * bis "Profil Löschen" durchgegeben werden, um sie letzendlich vom RootPanel zu löschen.
	 */
	Widget parentForm = getParent();
	User user = null;
	HorizontalPanel firstNamePanel = null;
	Label userFirstName = null;
	HorizontalPanel lastNamePanel = null;
	Label userLastName = null;
	HorizontalPanel nickNamePanel = null;
	Label userNickName = null;

	Button editButton = null;
	private Label info;

	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	private FindUserCallBack finduserCallback;
	private VerifyFieldCallback verifyFieldCallBack;

	/**
	 * Default-Konstruktor
	 */
	public ProfilForm() {

	}

	/**
	 * Konstruktor der ProfilForm
	 * @param u ist der Nutzer, dem das Profil gehört
	 * @param parent ist die EditorForm, in die die ProfilForm eingefügt wird.
	 */
	public ProfilForm(User u, Widget parent) {

		this.user = u;
		this.parentForm = parent;

		finduserCallback = new FindUserCallBack();
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();
		buildProfil();
		info = new Label("Bitte fülle jedes Feld aus!");
		

		/*
		 * CSS-Klassenselektoren
		 */
		info.addStyleName("infoProfilLabel");
		this.addStyleName("Profil");

		//Sobald des Profil geladen wurde, wird der User einmalig angefordert
		editorAdministration.findUserByID(user.getId(), finduserCallback);
		
		/*
		 * Alle 5 Sekunden wird diese Anfrage wieder gestellt, damit das Profil auf
		 * dem aktuellsten Stand bleibt.
		 */
		Timer refreshProfil = new Timer() {

			@Override
			public void run() {
				// TODO Auto-generated method stub

				editorAdministration.findUserByID(user.getId(), finduserCallback);

			}
		};

		refreshProfil.scheduleRepeating(5000);

	}

	/*
	 * 
	 * ClickHandler
	 * 
	 */

	/**
	 * <code>EditButtonClickHandler</code>: Wird beim Click auf <code> editButton </code> ausgelöst.
	 *  In der <code> onClick(ClickEvent event) </code>-Methode:
	 * - Alle Nutzer-spezifischen Namen-Labels werden durch Textfelder ersetzt, sodass der Nutzer neue Eingabe 
	 *   für seinen Nickname, Vorname und Nachname tätigen kann.
	 * - Der <code>editButton</code> wird entfernt
	 * - <code>deleteProfilBttn</code> wird hinzugefügt; zum Löschen des Profils
	 * - <code>saveChangesButton</code> wird hinzugefügt; zur Speicherung der Profiländerungen
	 * - ClickHandler werden den Buttons und KeyPressHandler den Textfelder hinzugefügt. 
	 * 
	 */
	class EditButtonClickHandler implements ClickHandler {

		ProfilForm profilForm = null;

		Widget parentForm = null;

		private EditButtonClickHandler(ProfilForm pf, Widget parent) {
			// TODO Auto-generated constructor stub
			this.profilForm = pf;
			this.parentForm = parent;

		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub

			//TextBoxen werden hinzugefügt; Labels werden entfernt
			firstNamePanel.remove(userFirstName);
			TextBox txtFirstName = new TextBox();
			txtFirstName.setText(user.getFirstName());
			firstNamePanel.add(txtFirstName);

			lastNamePanel.remove(userLastName);
			TextBox txtLastName = new TextBox();
			txtLastName.setText(user.getLastName());
			lastNamePanel.add(txtLastName);

			nickNamePanel.remove(userNickName);
			TextBox txtNickName = new TextBox();
			txtNickName.setText(user.getNickName());
			nickNamePanel.add(txtNickName);
			
			//EditButton wird entfernt
			profilForm.remove(editButton);
			
			//DeleteButton wird hinzugefügt; ClickHandler wird hinzugefügt
			Button deleteProfilBttn = new Button("Account löschen", new DeleteProfilClickHandler(user, parentForm));
			deleteProfilBttn.addStyleName("DeleteProfilButton");
			profilForm.add(deleteProfilBttn);
			
			//SaveButton wird hinzugefügt; ClickHandler wird hinzugefügt
			Button saveChangesButton = new Button("Änderungen sichern",
					new SaveChangesClickHandler(txtFirstName, txtLastName, txtNickName, profilForm));
			profilForm.add(saveChangesButton);

			//KeyPressHandlern werden den Textfeldern hinzugefügt
			txtFirstName.setFocus(true);
			txtFirstName.addKeyPressHandler(
					new EnterSaveChangesPressHandler(txtFirstName, txtLastName, txtNickName, profilForm));
			txtLastName.addKeyPressHandler(
					new EnterSaveChangesPressHandler(txtFirstName, txtLastName, txtNickName, profilForm));
			txtNickName.addKeyPressHandler(
					new EnterSaveChangesPressHandler(txtFirstName, txtLastName, txtNickName, profilForm));
		}

	}

	/**
	 * @author SimonJanik
	 * Funktion ist äquivalent zum <code>SaveChangesClickHandler</code>
	 */
	class EnterSaveChangesPressHandler implements KeyPressHandler {

		private TextBox txtFirstName = null;
		private TextBox txtLastName = null;
		private TextBox txtNickName = null;
		private ProfilForm profilForm = null;

		private EnterSaveChangesPressHandler(TextBox first, TextBox last, TextBox nick, ProfilForm pf) {
			// TODO Auto-generated constructor stub
			this.txtFirstName = first;
			this.txtLastName = last;
			this.txtNickName = nick;
			this.profilForm = pf;
		}

		@Override
		public void onKeyPress(KeyPressEvent event) {
			// TODO Auto-generated method stub
			if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ENTER)
				if(this.txtNickName.getText().length()>15) {
					Window.alert("Dein Nickname darf nicht länger als 15 Zeichen sein!");
					return;
				}

				else {	editorAdministration.findAllUserNickNames(new FindAllUserCallback(this.profilForm, this.txtFirstName,
						this.txtLastName, this.txtNickName));
				}
		}

	}

	// VON LEONIE

	/**
	 * Um das Profil endgültig zu löschen wird zum einen der User benötigt, welcher
	 * durch sämtliche Widgets durchgereicht wird und zum anderen wird das
	 * ParentWidget benötigt (die EditorForm). Diese muss auch durchgereicht werden,
	 * bis der Nutzer erfolgreich gelöscht ist (in onSuccess).
	 * 
	 * @author Leonie Heiduk
	 *
	 */
	class DeleteProfilClickHandler implements ClickHandler {

		User user;
		Widget parentForm;

		public DeleteProfilClickHandler(User u, Widget parent) {
			this.user = u;
			this.parentForm = parent;

		}

		@Override
		public void onClick(ClickEvent event) {

			DialogBox diabox = new DialogBox();
			VerticalPanel vPanel = new VerticalPanel();
			HorizontalPanel hButtonPanel = new HorizontalPanel();
			Button yesBttn = new Button("Ja", new YesDeleteClickHandler(user, diabox, parentForm));
			Button noBttn = new Button("Nein", new NoDeleteClickHandler(diabox));
			Label deleteMsg = new HTML(
					"<h1> Account Löschen </h1> <p> Bist du sicher, dass du dein Account löschen möchtest? </p> <br>"
					+ "<p>Dieser Schritt ist endgültig. Dein gelöschter Account kann danach nicht mehr wiederhergestellt werden.</p> <br>"
					+ "<p>Wenn du dein Account löschst, werden zusätzlich alle deine Beiträge, Kommentare und Likes gelöscht.</p>"
					);

			vPanel.add(deleteMsg);
			hButtonPanel.add(yesBttn);
			hButtonPanel.add(noBttn);
			vPanel.add(hButtonPanel);

			diabox.setGlassEnabled(true);
			diabox.setAnimationEnabled(true);
			diabox.center();
			diabox.show();

			diabox.add(vPanel);

		}
	}

	/**
	 * Wenn der DeleteNoClickHandler abgefeuert wird, wird die DialogBox, die eben
	 * noch angezeigt wurde, verschwinden. Ansonsten passiert nichts.
	 * 
	 * @author Leonie Heiduk
	 *
	 */
	class NoDeleteClickHandler implements ClickHandler {

		private DialogBox diabox;

		public NoDeleteClickHandler(DialogBox d) {
			this.diabox = d;
		}

		@Override
		public void onClick(ClickEvent event) {

			diabox.hide();
			diabox.clear();
			diabox.removeFromParent();
			diabox.setAnimationEnabled(false);
			diabox.setGlassEnabled(false);

		}

	}

	/**
	 * Hier wird der User in der DB gelöscht, die Dialogbox wird gelöscht und dann
	 * muss auf das Callback Objekt gewartet werden.
	 * 
	 * @author Leonie Heiduk
	 *
	 */
	class YesDeleteClickHandler implements ClickHandler {

		User user;
		private DialogBox diabox;
		Widget parentForm;

		public YesDeleteClickHandler(User u, DialogBox d, Widget parent) {
			this.user = u;
			this.diabox = d;
			this.parentForm = parent;
		}

		@Override
		public void onClick(ClickEvent event) {

			// user in DB löschen
			editorAdministration.deleteUser(user.getId(), new DeleteUserCallBack(parentForm, this.user));

			// DIABOX
			diabox.hide();
			diabox.clear();
			diabox.removeFromParent();
			diabox.setAnimationEnabled(false);
			diabox.setGlassEnabled(false);

		}
	}

	/**
	 * Dies ist die Klasse, in der sozusagen das Pinboard endgültig verschwindet.
	 * Die EditorForm (Parent) wird gelöscht und stattdessen wird ein Gif für 3
	 * Sekunden angezeigt. Ist der Timer zu Ende, wird eine neue RegisterForm
	 * instanziiert und diese wird ins RootPanel gesetzt.
	 * 
	 * @author Leonie Heiduk
	 *
	 */
	class DeleteUserCallBack implements AsyncCallback<Void> {

		private Widget parentForm;
		private User user;

		public DeleteUserCallBack(Widget parent, User u) {
			this.parentForm = parent;
			this.user = u;
		}

		@Override
		public void onFailure(Throwable caught) {

			if (caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}

		}

		@Override
		public void onSuccess(Void result) {

			Image img = new Image("Michaelscottfacepalm1.gif");
			img.setWidth("50%");

			Window.alert("Alles Cool! Dein Profil wurde erfolgreich gelöscht");

			parentForm.removeFromParent();

			RootPanel.get("app").add(img);

			class GifTimer extends Timer {

				Image img;

				public GifTimer(Image img) {
					this.img = img;
				}

				@Override
				public void run() {
					img.removeFromParent();
					Window.Location.replace("/");

				}

			}

			GifTimer funTimer = new GifTimer(img);
			funTimer.schedule(3000);

		}

	}

	
	/**
	 * 
	 * @author SimonJanik
	 * Wird beim Click auf <code>saveChangesButton</code> ausgelöst. Solange der Nickname
	 * nicht länger als 15 Zeichen ist werden die Nicknamen angefordert.
	 */
	class SaveChangesClickHandler implements ClickHandler {

		private TextBox txtFirstName = null;
		private TextBox txtLastName = null;
		private TextBox txtNickName = null;
		private ProfilForm profilForm = null;

		private SaveChangesClickHandler(TextBox first, TextBox last, TextBox nick, ProfilForm pf) {
			// TODO Auto-generated constructor stub

			this.txtFirstName = first;
			this.txtLastName = last;
			this.txtNickName = nick;
			this.profilForm = pf;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			if(this.txtNickName.getText().length()>15) {
				Window.alert("Dein Nickname darf nicht länger als 15 Zeichen sein!");
				return;
				
			}
			else{ editorAdministration.findAllUserNickNames(
					new FindAllUserCallback(this.profilForm, this.txtFirstName, this.txtLastName, this.txtNickName));
			}
		}

	}

	/**
	 * 
	 * @author SimonJanik, FelixBieswanger
	 *  Schließt bei onClick die <code>errBox</code>
	 */
	class CloseErrBoxClickHandler implements ClickHandler {

		DialogBox errBox = null;

		private CloseErrBoxClickHandler(DialogBox db) {
			// TODO Auto-generated constructor stub

			this.errBox = db;

		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub

			errBox.hide();
			errBox.clear();
			errBox.removeFromParent();
			errBox.setAnimationEnabled(false);
			errBox.setGlassEnabled(false);

		}

	}

	/*
	 * 
	 * Callbacks
	 * 
	 */

	class UpdateUserCallBack implements AsyncCallback<User> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if (caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
		}

		@Override
		public void onSuccess(User result) {
			// TODO Auto-generated method stub

			if (result != null) {
				user = result;
				buildProfil();

			}

		}

	}

	/**
	 * @author FelixBieswanger
	 * Hilfsmethode zum Aufbau des kompletten Profils.
	 * Wird in der onLoad-Methode verwendet.
	 * 
	 */
	private void buildProfil() {

		this.clear();
		Label head = new Label("Dein Profil");
		head.addStyleName("InfoText");
		this.add(head);

		firstNamePanel = new HorizontalPanel();
		Label firstNameBesc = new Label("Vorname: ");
		userFirstName = new Label(user.getFirstName());
		firstNamePanel.add(firstNameBesc);
		firstNamePanel.add(userFirstName);

		lastNamePanel = new HorizontalPanel();
		Label lastNameBesc = new Label("Nachname: ");
		userLastName = new Label(user.getLastName());
		lastNamePanel.add(lastNameBesc);
		lastNamePanel.add(userLastName);

		nickNamePanel = new HorizontalPanel();
		Label nickNameBesc = new Label("Nickname: ");
		userNickName = new Label(user.getNickName());
		nickNamePanel.add(nickNameBesc);
		nickNamePanel.add(userNickName);

		editButton = new Button("Profil bearbeiten", new EditButtonClickHandler(this, parentForm));

		this.add(firstNamePanel);
		this.add(lastNamePanel);
		this.add(nickNamePanel);
		this.add(editButton);

	}

	/**
	 * 
	 * @author SimonJanik, FelixBieswanger
	 * Änderungen werden bei onSucess() nur ins Profil geschrieben, wenn der Nutzer wirklich neue
	 * Änderungen des Nicknamen, Vornamen, Nachnamen vorgenommen hat.
	 */
	class FindUserCallBack implements AsyncCallback<User> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSuccess(User result) {
			// TODO Auto-generated method stub

			if (user.getFirstName() != result.getFirstName() || user.getLastName() != result.getLastName()
					|| user.getNickName() != result.getNickName()) {
				user = result;
				buildProfil();
			}

		}

	}

	/**
	 * 
	 * @author SimonJanik, FelixBieswanger
	 * CallBack, um Leerzeichen-Eingabe des Nutzer zu vermeiden.
	 *
	 */
	class VerifyFieldCallback implements AsyncCallback<String[]> {

		ProfilForm profilForm;
		TextBox txtFirstName;
		TextBox txtLastName;
		TextBox txtNickName;

		private VerifyFieldCallback(ProfilForm pf, TextBox t1, TextBox t2, TextBox t3) {
			// TODO Auto-generated constructor stub
			this.profilForm = pf;
			this.txtFirstName = t1;
			this.txtLastName = t2;
			this.txtNickName = t3;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSuccess(String[] result) {
			// TODO Auto-generated method stub

			if (result != null) {
				user.setFirstName(result[0]);
				user.setLastName(result[1]);
				user.setNickName(result[2]);

				editorAdministration.updateUser(user, new UpdateUserCallBack());
			} else {
				profilForm.add(info);

				if (txtFirstName.getText().isEmpty()) {
					txtFirstName.setFocus(true);
				}
				if (txtLastName.getText().isEmpty()) {
					txtLastName.setFocus(true);
				}
				if (txtNickName.getText().isEmpty()) {
					txtNickName.setFocus(true);
				}

			}

		}

	}
	/**
	 * 
	 * @author SimonJanik, FelixBieswanger
	 * CallBack, der als <code>result</code> alle Nicknamen enthält.
	 * Wird benötigt, um zu prüfen, ob der Nickname, den der Nutzer eingeben
	 * will schon vergeben ist.
	 *
	 */
	class FindAllUserCallback implements AsyncCallback<Vector<String>> {

		ProfilForm profilForm;
		TextBox txtFirstName;
		TextBox txtLastName;
		TextBox txtNickName;

		private FindAllUserCallback(ProfilForm pf, TextBox t1, TextBox t2, TextBox t3) {
			// TODO Auto-generated constructor stub
			this.profilForm = pf;
			this.txtFirstName = t1;
			this.txtLastName = t2;
			this.txtNickName = t3;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());
		}

		@Override
		public void onSuccess(Vector<String> result) {
			// TODO Auto-generated method stub

			if (user.getNickName() != this.txtNickName.getText()) {
				for (int i = 0; i < result.size(); i++) {
					if (this.txtNickName.getText() == result.get(i)) {
						Window.alert("Nickname schon vergeben");
						return;
					}
				}
			}

			String newFirst = txtFirstName.getText();
			String newLast = txtLastName.getText();
			String newNick = txtNickName.getText();

			editorAdministration.verifyField(new String[] { newFirst, newLast, newNick },
					new VerifyFieldCallback(this.profilForm, this.txtFirstName, this.txtLastName, this.txtNickName));

		}

	}
}
