package de.hdm.itprojekt.client.gui;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.PushButton;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.bo.Comment;

/**
 * 
 * @author SimonJanik
 * Diese Klasse enhält alle Elemente für die Darstellung und Interaktion mit 
 * dem eigenen Kommentar eines Nutzers.
 * 
 * 
 */

public class InteractionCommentForm extends HorizontalPanel {
	
	Comment comment = null;
	CommentForm commentForm = null;
	PostForm postForm = null;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
		
	Image deleteIcon = new Image("baseline_delete_outline_white_48dp.png");
	PushButton deleteButton = new PushButton(deleteIcon);
	Image editIcon = new Image("baseline_edit_white_48dp.png");
	PushButton editButton = new PushButton(editIcon);
	CommentEditForm commentEditForm = null;
	CommentDeleteForm commentDeleteForm = null;
	InteractionPostFormAll interactionPostformALL;
	
	/**
	 * Konstruktor der InteractionCommentForm
	 * @param c ist der dazugehörige Kommentar (der editiert oder gelöscht werden soll).
	 * @param comF ist die dazugehörige CommentForm, an der die InteractionCommentForm angehängt ist.
	 * @param pf ist die PostForm, an der der Kommentar angehängt ist.
	 * @param interac ist die InteractionPostForm, die dem Post angehängt ist. 
	 */
	public InteractionCommentForm(Comment c, CommentForm comF, PostForm pf,InteractionPostFormAll interac) {
		this.comment = c;
		this.commentForm = comF;
		this.postForm = pf;
		this.interactionPostformALL = interac;
	}
	
	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		
		this.addStyleName("InteractionCommentForm");
		deleteButton.addClickHandler(new DeleteCommentClickHandler(this.comment, this.commentForm, this.postForm));
		editButton.addClickHandler(new EditCommentClickHandler(this.comment, this.commentForm));
		this.add(editButton);
		this.add(deleteButton);	
	}
	
	/**
	 * DeleteCommentClickHandler: Verleiht dem <code> deleteButton </code> seine Funktion. 
	 * Dessen <code> onClick(ClickEvent event)</code>-Methode öffnet die <code> commentDeleteForm </code> 
	 */
	class DeleteCommentClickHandler implements ClickHandler{
		private Comment comment = null;
		private CommentForm commentForm = null;
		private PostForm postForm = null;
		private DeleteCommentClickHandler(Comment c, CommentForm cf, PostForm pf) {
			this.comment = c;
			this.commentForm = cf;
			this.postForm = pf;
			
		}
		
		@Override
		public void onClick(ClickEvent event) {

			if(commentDeleteForm == null) {
				commentDeleteForm = new CommentDeleteForm(this.comment, this.commentForm, this.postForm, interactionPostformALL);
				commentDeleteForm.openCommentDeleteForm();
			} else {
				commentDeleteForm.openCommentDeleteForm();;
				
			}
			
			
		}
		
	}
	
	/**
	 * EditCommentClickHandler: Verleiht dem <code> editButton </code> seine Funktion. 
	 * Dessen <code> onClick(ClickEvent event)</code>-Methode öffnet die <code> commentEditForm </code> 
	 */
	
	class EditCommentClickHandler implements ClickHandler{
		private Comment comment = null;
		private CommentForm commentForm = null;
	
		
		private EditCommentClickHandler(Comment c, CommentForm cf) {
			this.comment = c;
			this.commentForm = cf;

		}


		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			if(commentEditForm == null) {
				commentEditForm = new CommentEditForm(comment, commentForm);
				commentEditForm.openCommentEditForm();
			} else {
				commentEditForm.openCommentEditForm();
			}
			
		
		
		}
		
	}

}
