package de.hdm.itprojekt.client.gui.report;

import com.google.gwt.user.client.ui.Button;

import com.google.gwt.user.client.ui.DockPanel;
import java.util.Date;
import java.util.Vector;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.safehtml.shared.SafeHtmlBuilder;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.LoginAdministrationAsync;
import de.hdm.itprojekt.shared.ReportAdministrationAsync;
import de.hdm.itprojekt.shared.bo.User;
import de.hdm.itprojekt.shared.report.Report;

/**
 * ReportForm erweitert VerticalPanel und beinhaltet alle weiteren grafischen GWT-Elemente, 
 * die für den gesamten Report benötigt werden.
 * D
 * @author Leonie Heiduk, Simon Janik, David Rundel
 *
 */

public class ReportForm extends VerticalPanel{
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	
	User clientBoUser= null;
	
	public ReportForm() {
 		
 	}
 	
 	public ReportForm(User u) {
 		this.clientBoUser= u;
 	}
 	
 	Image logo = new Image("Offical_Logo.png");
 	Label name = new Label("Report-Generator");
	
	HorizontalPanel headerPanel = new HorizontalPanel();
	HorizontalPanel mainPanel = new HorizontalPanel();
	VerticalPanel filterPanel = new VerticalPanel();
 	ScrollPanel scrollPanel= new ScrollPanel();
 	
 	HTML reportHTML = new HTML("<b>Hier erscheint der angeforderte Report.</b>");

	

	
	public void onLoad() {
		super.onLoad();
		
		editorAdministration.findUserByID(clientBoUser.getId(), new FindUserCallback());
		
		this.addStyleName("ReportForm");
 		headerPanel.addStyleName("ReportHeader");
 		mainPanel.addStyleName("Main");
 		
 		filterPanel.addStyleName("NavigatorPanel");
 		scrollPanel.addStyleName("ScrollPanel");
 		
		
		headerPanel.add(logo);
		headerPanel.add(name);
		
		Button toEditor = new Button("Editor", new ClickHandler() {
			
			@Override
			public void onClick(ClickEvent event) {
				Window.Location.replace("/Editor.html");
			}
		});
		headerPanel.add(toEditor);
		
		scrollPanel.add(reportHTML);
 		ReportFilterForm reportFilterForm= new ReportFilterForm(clientBoUser, this);
 		filterPanel.add(reportFilterForm);
 		mainPanel.add(filterPanel);
 		mainPanel.add(scrollPanel);
 		mainPanel.setWidth("100%");
 		mainPanel.setCellWidth(filterPanel, "15%");
 		mainPanel.setHorizontalAlignment(ALIGN_CENTER);


		
		this.add(headerPanel);
		this.add(mainPanel);
	}
	
	public void setReport(HTML rHTML) {
		if(rHTML != null) {
 		this.reportHTML= rHTML;
 		scrollPanel.clear();
 		scrollPanel.add(reportHTML);
		}
 	}
	
	class FindUserCallback implements AsyncCallback<User>{

		public void onFailure(Throwable caught) {
			
		}

		public void onSuccess(User result) {
			if (result != null && result.getId()== clientBoUser.getId()) {
				clientBoUser= result;
			}
			
		}
		
	}
	
	

}


