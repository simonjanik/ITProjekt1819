package de.hdm.itprojekt.client.gui;

import java.util.Date;
import java.util.Vector;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.DisclosurePanel;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.shared.bo.Post;
import de.hdm.itprojekt.shared.bo.User;
import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.client.gui.WritePostForm.ReziseTextAreaKeyDownHandler;
import de.hdm.itprojekt.client.gui.WritePostForm.ReziseTextAreaKeyPressHandler;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.LoginAdministrationAsync;
import de.hdm.itprojekt.shared.bo.BusinessObject;
import de.hdm.itprojekt.shared.bo.Comment;

/**
 * 
 * @author SimonJanik PostForm: Beinhaltet alle grafischen Elemente zur
 *         Darstellung eines Beitrags (Post).
 */

public class PostForm extends VerticalPanel {

	User user = null;
	Post post = null;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	Vector<Comment> currentComments;
	
	Label postHeader;
	TextArea postText;
	PinboardForm pinboardForm;
	HorizontalPanel header = new HorizontalPanel();
	InteractionPostFormOwn interactionFormOwn;
	InteractionPostFormAll interactionFormAll;

	/**
	 * Ein Post beinhaltet ggf. Kommentare. Diese werden hier abgelegt, sobald sie einem
	 * Post hinzugefügt werden.
	 */
	VerticalPanel commentsPanel;

	private FindAllCommentsCallback commentsCallback;

	/**
	 * Konstruktor der PostForm
	 * @param p ist der darzustellende Post
	 * @param u ist der Author des Posts
	 * @param pinForm ist die Pinnwand, an der der Post angzeigt werden soll.
	 */
	public PostForm(Post p, User u, PinboardForm pinForm) {
		this.post = p;
		this.user = u;
		this.pinboardForm = pinForm;

		currentComments = new Vector<>();

		commentsCallback = new FindAllCommentsCallback(this);
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 */
	public void onLoad() {

		//Enthält alle Kommentare des Posts
		commentsPanel = new VerticalPanel();

		/**
		 * Der Post wird in <code>postText</code> dargestellt. Standardmäßig kann der Text
		 * jedoch vom Nutzer bearbeitet werden (TextArea). Diese Funktion wird durch 
		 * <code>postText.setEnabled(false);</code> deaktiviert. Eine Bearbeitung erfolgt
		 * ausschließlich über die <code>interactionFormOwn</code>.
		 */
		postText = new TextArea();
		postText.setEnabled(false);
		postText.setText(this.post.getText());
		resizeTextArea();

		//Oberster Bereich der PostForm. Beinhaltet das Datum und Buttons zum 'Bearbeiten' und 'Löschen' eines Posts
		header = new HorizontalPanel();
		String dateString =post.getCreationDate().toGMTString();
		postHeader = new Label("Beitrag vom " + dateString.substring(0, dateString.length()-3));
		postHeader.setStyleName("PostHeadLabel");

		//Zur Bearbeitung oder Löschen des eigenen Posts
		interactionFormOwn = new InteractionPostFormOwn(this.post, this, this.pinboardForm);
		//Zum Liken oder Kommentieren eines Posts
		interactionFormAll = new InteractionPostFormAll(this.post, this, this.user);

	
		/*
 		* Sucht einmalig die PinboardID des Users. Dies ist notwendig, um im Verlauf zu überprüfen,
 		* ob dem User die Pinnwand gehört oder nicht.
 		* Gehört die Pinnwand dem User, bekommt dieser die Möglichkeit seine Posts zu bearbeiten
 		* oder zu löschen. Gehört die Pinnwand dem User nicht, hat er diese Möglichkeit nicht.
 		*/
		editorAdministration.findUserByPinboardID(this.post.getPinboardID(), new CheckOwnCallback(this));

		/**
		 * Aber hier folgen die CSS-Bezeichner für den Inhalt des Panels. Die
		 * Konfiguration der Bezeichner können in war>ITP_T3.css geändert werden.
		 */
		this.addStyleName("PostForm");
		header.addStyleName("PostHeader");
		interactionFormOwn.addStyleName("OwnInteraction");
		commentsPanel.addStyleName("CommentsOfPost");

	}

	// Methode zum Entfernen eines Post von seiner Pinnwand
	public void closePostForm() {
		this.removeFromParent();
	}

	/**
	 * Callback der Methode <code>findCommentsByPost(post.getId(), commentsCallback)</code>
	 * Bei erfolgreichem Rückruf (onSucess) werden alle Kommentare des Posts aus der Datenbank 
	 * zurückgegeben. Diese werden mit den vorhandenen Kommentaren verglichen. Sind beide 
	 * verschieden, werden alle Kommentare aus dem <code>commentsPanel</code>
	 * entfernt und durch den aktuellsten Stand <code>result</code>ersetzt.
	 */
	class FindAllCommentsCallback implements AsyncCallback<Vector<Comment>> {

		private PostForm postform;

		private FindAllCommentsCallback(PostForm postF) {
			// TODO Auto-generated constructor stub
			this.postform = postF;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());
		}

		@Override
		public void onSuccess(Vector<Comment> result) {
			// TODO Auto-generated method stub
			if (vergleich(currentComments, result) == false) {
				commentsPanel.clear();

				if (result.size() > 0) {
					interactionFormAll.showComments();
					for (int i = 0; i < result.size(); i++) {

						commentsPanel.add(new CommentForm(result.get(i), user, this.postform,interactionFormAll));

					}
				} else {
					interactionFormAll.hideComments();
				}
				currentComments = result;

			} else {
				// else aktueller stand
			}

		}

	}

	/**
	 * Callback der Methode <code>findUserByPinboardID(this.post.getPinboardID(), new CheckOwnCallback(this))</code>
	 * Bei erfolgreichem Rückruf (onSucess) werden 
	 * - der <code>PostForm</code> alle zugehörigen grafischen Elemente hinzugefügt. 
	 * - Es wird geprüft, ob die aktuelle User-ID mit der Pinnboard-ID übereinstimmt. Ist dies der Fall,
	 *   gehört die Pinnwand dem User (da batenbankseitig Pinnboard-ID = User-ID). Dadurch bekommt dieser 
	 *   zusätzlich die Möglichkeit seinen eigenen Post zu bearbeiten oder zu löschen.
	 * - Anschließend werden dem Post alle zugehörigen Kommentare angehängt. Alle 5 Sekunden werden
	 *   die Kommentare aktualisiert.
	 */
	class CheckOwnCallback implements AsyncCallback<User> {

		PostForm postForm;

		public CheckOwnCallback(PostForm pf) {
			// TODO Auto-generated constructor stub
			this.postForm = pf;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());

		}

		@Override
		public void onSuccess(User pinboardOwner) {
			// TODO Auto-generated method stub

			header.add(postHeader);
			postForm.add(header);
			postForm.add(postText);
			postForm.resizeTextArea();
			postForm.add(interactionFormAll);

			if (pinboardOwner.getId() == user.getId()) {
				header.add(interactionFormOwn);

			}
			editorAdministration.findCommentsByPost(post.getId(), commentsCallback);
			Timer refreshComments = new Timer() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					editorAdministration.findCommentsByPost(post.getId(), commentsCallback);
				}
			};
			refreshComments.scheduleRepeating(5000);

		}

	}

	/**
	 * Zum Hinzufügen eines Kommentars zu seinem Post
	 * @param c ist der Kommentar, der dem Post hinzugefügt werden soll.
	 * Jeder neue Kommentar wird immer an erste Stelle im <code>commentsPanel</code> eingefügt.
	 */
	public void addCommentToPost(Comment c) {
		if (this.currentComments.size() == 0) {
			this.interactionFormAll.showComments();
		}
		this.currentComments.add(c);
		this.showComments();
		this.interactionFormAll.commentsLabelAdjust(this.currentComments.size());
		
		commentsPanel.insert(new CommentForm(c, this.user, this,interactionFormAll),0);

	}

	/**
	 * Zum Entfernen eines Kommentars von seinem Post
	 * @param c ist der Kommentar, der von seinem Post entfernt werden soll.
	 * Wenn anschließend keine Kommentare mehr vorhanden sind, wird das <code>commentsPanel</code>
	 * vom Post entfernt werden.
	 */
	public void deleteCommentFromPost(Comment c) {

		this.currentComments.remove(c);

		if (currentComments.size() == 0) {
			this.interactionFormAll.hideComments();
			this.commentsPanel.removeFromParent();
		}

	}

	/**
	 * Vergleichsmethode, um zwei Kommentar-Vectoren miteinander zu vergleichen.
	 * @param current ist der aktuelle Kommentar-Vector
	 * @param result ist in dieser Klasse der Kommentar-Vector, der bei dem CallBack von der Datenbank zurückgegeben wird.
	 * @return (siehe weiter)
	 * Methode gibt false zurück, wenn...
	 *  	- beide Vectoren nicht gleichgroß sind
	 * Methode gibt true zurück, wenn...
	 *  	- die ID der Kommentare gleich ist UND
	 *  	- der Text der Kommentare gleich ist
	 */
	public Boolean vergleich(Vector<Comment> current, Vector<Comment> result) {

		if (current.size() != result.size()) {
			return false;
		}

		for (int i = 0; i < result.size(); i++) {
			boolean found = false;
			for (int j = 0; j < result.size(); j++) {

				if (result.get(i).getId() == current.get(j).getId()
						&& result.get(i).getText() == current.get(j).getText()) {
					found = true;
				}

			}

			if (found == false) {
				return false;
			}
		}

		return true;
	}

	/*
	 * resizeTextArea passt die Höhe (bzw. Lines) des postText an (Bis zu einer
	 * Line-Menge von 9; Dies entspricht 490 Zeichen - die Hälfte der möglichen
	 * Datenbank- Textlänge 1000). Dies geschieht anhand von if-Abfragen der vom
	 * Nutzer eingegebenen Zeichenlänge. Die Min-Line-Menge der TextArea beträgt 2.
	 * Ab einer Max-Line-Menge von 9 ist es dem User möglich, mittels Scrollen seine
	 * Eingaben zu sehen.
	 */

	public void resizeTextArea() {
		int linebreaks = countLineBreaksInText();
		
		if (linebreaks == 3 || postText.getText().length() > 90) {
			postText.setVisibleLines(3);
		}
		if (linebreaks == 4 || postText.getText().length() > 180) {
			postText.setVisibleLines(4);
		}
		if (linebreaks == 5 || postText.getText().length() > 270) {
			postText.setVisibleLines(5);
		}
		if (linebreaks == 6 ||postText.getText().length() > 360) {
			postText.setVisibleLines(6);
		}
		if (linebreaks == 7 || postText.getText().length() > 450) {
			postText.setVisibleLines(7);
		}
		if (linebreaks == 8 || postText.getText().length() > 540) {
			postText.setVisibleLines(8);
		}

	}
	
	public int countLineBreaksInText(){
		int lastIndex = 0;
		int count = 0;
		final String searchText = postText.getText();
		final String searchWord = "\n";

			while(lastIndex != -1){

			    lastIndex = searchText.indexOf(searchWord,lastIndex);

			    if(lastIndex != -1){
			        count ++;
			        lastIndex += searchWord.length();
			    }
		}
		return count;
	
	}


	//Zum Entfernen aller Kommentare eines Posts
	public void hideComments() {
		this.commentsPanel.removeFromParent();
	}

	//Zum Hinzufügen aller Kommentare zu einem Post
	public void showComments() {
		this.add(commentsPanel);

	}

}
