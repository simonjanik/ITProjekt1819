package de.hdm.itprojekt.client.gui;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.Comment;

/**
 * 
 * @author SimonJanik
 * DialogBox, die angezeigt wird, wenn der Nutzer einen Kommentar löschen möchte.
 * Die Klasse enthält entsprechende ClickHandler & Methoden zum Bestätigen oder Abbrechen der Aktion.
 */

public class CommentDeleteForm extends DialogBox {
	
	Comment comment = null;
	CommentForm commentForm = null;
	PostForm postForm;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();

	Label askText = new Label("Möchtest du deinen Kommentar wirklich löschen?");
	Button positiveButton = new Button("Ja");
	Button negativeButton = new Button("Nein");
	HorizontalPanel horizont = new HorizontalPanel();
	VerticalPanel vertical = new VerticalPanel();
	InteractionPostFormAll interactionPostAll;
	
	/**
	 * Konstruktor der Klasse
	 * @param c ist der zu bearbeitende Kommentar
	 * @param comF ist die CommentForm des dazugehörigen Comments
	 * @param pf ist die PostForm, an der entsprechende Comment angehängt wird
	 * @param interac ist die daszugehörige InteractionForm der entsprechenden CommentForm
	 */
	
	public CommentDeleteForm(Comment c, CommentForm comF, PostForm pf, InteractionPostFormAll interac) {
		this.comment = c;
		this.commentForm = comF;
		this.postForm = pf;
		this.interactionPostAll = interac;
	}
	
	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Widget, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Widget hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	
	public void onLoad() {
	super.onLoad();	
		vertical.add(askText);
		horizont.add(positiveButton);
		horizont.add(negativeButton);
		negativeButton.addClickHandler(new DenialDeleteCommentClickHandler());
		positiveButton.addClickHandler(new ConfirmDeleteCommentClickHandler());
		vertical.add(horizont);
		this.add(vertical);
		
	}
	
	/*
	 * Ab hier folgen alle CLICKHANDLER und CALLBACKS dieser Klasse!
	 */
	

	
	/**
	 * ConfirmDeleteCommentClickHandler: Wird beim Click auf <code> positiveButton </code> ausgelöst.
	 * Der User bestätigt damit, dass der Kommentar gelöscht werden soll.
	 */
	class ConfirmDeleteCommentClickHandler implements ClickHandler{
		
	
		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			editorAdministration.deleteComment(comment.getId(), new DeleteCallBack());
		}
			
	}
	
	/**
	 * DenialDeleteCommentClickHandler: Wird beim Click auf <code> negativeButton </code> ausgelöst.
	 * Der User bestätigt damit, dass der Kommentar nicht gelöscht werden soll.
	 */
	class DenialDeleteCommentClickHandler implements ClickHandler{
		@Override
		public void onClick(ClickEvent event) {
		
			closeCommentDeleteForm();
		}
		
	}
	
	/**
	 * CallBack des Clickhandlers <code> ConfirmDeleteCommentClickHandler </code>
	 * Bei erfolgreichem Rückruf (onSucess) wird der Kommentar-Counter der InteractionPostAll-Form um 1
	 * gemindert. Danach wird die dazugehörige <code> commentForm </code> geschlossen, der Kommentar
	 * von der dazugehörigen PostForm entfernt und die CommentDeleteForm geschlossen.
	 */
	class DeleteCallBack implements AsyncCallback<Void>{
		
		
		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if(caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
	
		}

		@Override
		public void onSuccess(Void result) {
			// TODO Auto-generated method stub
			int amountComments = Integer.parseInt(interactionPostAll.amountComments.getText());
			interactionPostAll.amountComments.setText(Integer.toString(--amountComments));
			interactionPostAll.commentsLabelAdjust(--amountComments);
			commentForm.closeCommentForm();
			postForm.deleteCommentFromPost(comment);
			closeCommentDeleteForm();
			
		}
		
	}
	
	/*
	 * Methoden zum Öffnen und Schließen der CommentDeleteForm.
	 */
	public void closeCommentDeleteForm() {
		this.hide();
		this.clear();
		this.removeFromParent();
		this.setAnimationEnabled(false);
		this.setGlassEnabled(false);

	}
	
	public void openCommentDeleteForm() {
		this.setGlassEnabled(true);
		this.setAnimationEnabled(true);
		this.center();
		this.show();
	}
	
	
	

}
