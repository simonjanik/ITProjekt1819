package de.hdm.itprojekt.client.gui;

import com.google.gwt.cell.client.AbstractCell;


import com.google.gwt.safehtml.shared.SafeHtmlBuilder;

import de.hdm.itprojekt.shared.bo.Sub;
import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author FelixBieswanger:
 * Diese AbstractCell dient als Container für Abonnements (Subs).
 * Sie wird zur Darstellung von einzelnen Abos innerhalb der <code>SubForm</code> benötigt.
 *
 */
public class SubCell extends AbstractCell<Sub> {

	int pinIDCurrentUser;
	
	/**
	 * Konstruktor der SubCell
	 * @param u ist das darzustellende Nutzer-Objekt
	 */
	
	public SubCell(int pinIDCurrentUser ) {
		// TODO Auto-generated constructor stub
		this.pinIDCurrentUser = pinIDCurrentUser;
	}

	//Anzeigen der SubCell
	@Override
	public void render(Context context, Sub sub, SafeHtmlBuilder sb) {
		// TODO Auto-generated method stub

		//Wenn kein Sub vorhanden ist, dann soll nichts geschehen.
		if (sub == null) {
			return;
		}
		/*
		 * Wenn der eigene Nutzername dem abonnierten Nutzer entspricht, 
		 * soll 'Eigene Pinnwand' anstelle des Nicknamens angzeigt werden.
		 * Wenn dies nicht der Fall ist (= nicht der eigene Nutzer), soll dessen
		 * Nickname angezeigt werden.
		 */
		if(this.pinIDCurrentUser== sub.getPinboardID()) {
			sb.appendHtmlConstant("<h4 class='subcell' style='padding-left:5px;'>Eigene Pinnwand</h4>");

		}else {
			sb.appendHtmlConstant("<h4 class='subcell' style='padding-left:5px;'>");
			sb.appendEscaped(sub.getSubscribedUserNickName());
			sb.appendHtmlConstant("</h4>");
			
		}
		
	}

}
