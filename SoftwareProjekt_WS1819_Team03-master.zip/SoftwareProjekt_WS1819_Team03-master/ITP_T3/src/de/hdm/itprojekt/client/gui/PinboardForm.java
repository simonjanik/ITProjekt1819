package de.hdm.itprojekt.client.gui;

import java.util.Vector;

import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.DecoratorPanel;
import com.google.gwt.user.client.ui.FlexTable;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ScrollPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.bo.Post;
import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author SimonJanik 
 * Diese Klasse enhält alle Elemente für die Darstellung und Interaktion der Pinboard.
 */

public class PinboardForm extends VerticalPanel {

	private int currentPinboardID;
	private EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	private Label pinboardHead;
	private VerticalPanel postPanel;
	private ScrollPanel scroller = new ScrollPanel();
	private User user;
	private Vector<Post> currentPosts;
	private FindAllPostsCallback findallCallback;
	private WritePostForm writePostForm;

	
	/**
	 * Default-Konstruktor
	 */
	public PinboardForm() {

	}

	
	/**
	 * Konstruktor
	 * @param u ist der User der entsprechenden Pinnwand.
	 */
	public PinboardForm(User u) {
		// TODO Auto-generated constructor stub
		this.user = u;
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();

	
		//Pinboard / Scrollpanel-Elemente
		this.addStyleName("Pinboard");
		postPanel = new VerticalPanel();
		scroller.add(postPanel);
		scroller.setAlwaysShowScrollBars(true);
		scroller.addStyleName("Scroller");
		scroller.setSize("560px", "450px");

		//WritePostForm, zum Schreiben eines Posts auf der eigenen Pinnwand des Nutzers
		writePostForm = new WritePostForm(user, this);
		writePostForm.setVisible(false);

		//Überschrift jeder Pinnwand
		pinboardHead = new Label();
		pinboardHead.addStyleName("PinnwandHead");

		//Hinzufügen der Hauptelemente zu diesem Panel
		this.add(writePostForm);
		this.add(pinboardHead);
		this.add(scroller);

		//Vector, der die aktuellen Posts beinhaltet
		currentPosts = new Vector<>();

		findallCallback = new FindAllPostsCallback(this);

	}
	/**
	 * getter-Methode für die aktuelle Pinnwand
	 * @return <code> currentPinboardID </code> ist die aktuelle Pinnwand-ID
	 */
	public int getCurrentPinboard() {
		return currentPinboardID;
	}

	/**
	 * setter-Methode für die aktuelle Pinnwand
	 * @param pinboardId ist die Zielpinnwand, die gesetzt werden soll
	 */
	public void setCurrentPinboard(int pinboardId) {
		currentPinboardID = pinboardId;
		this.showCurrent();

	}

	/**
	 * showCurrent(): Abhängig von der <code> currentPinboardID </code>, die mittels der Methode 
	 * <code> setCurrentPinboard(int pinboardId)</code> gesetzt werden kann, wird die entsprechende User zurückgegeben.
	 * Da die UserID der PinnboardID entspricht, kann ein User-Objekt des entsprechenden Users angefordert werden.
	 * 
	 */
	private void showCurrent() {

		editorAdministration.findUserByPinboardID(currentPinboardID, new AsyncCallback<User>() {

			/**
			 * Gibt bei <code>onSuccess(User result)</code> eine User-Objekt zurück.
			 * Eigene User-Pinnwand:
			 * - Wenn die aktuelle User-ID der <code>result</code>-User-ID entspricht, kann die
			 * eigene Pinnwand des Users angezeigt werden.
			 * - Wenn die aktuelle User-ID der <code>result</code>-User-ID nicht entspricht, wird die
			 * Pinnwand des entsprechenden Users angzeigt.
			 */
			@Override
			public void onSuccess(User result) {
				// TODO Auto-generated method stub
				if (result.getId() == user.getId()) {
					writePostForm.setVisible(true);
					pinboardHead.setText("Deine Pinnwand:");
				} else {
					writePostForm.setVisible(false);
					pinboardHead.setText("Pinnwand von " + result.getNickName() + ":");
				}
				
				/*
				 * Alle Beiträge der aktuell angezeigten Pinnwand werden angefragt
				 */
				editorAdministration.findPostsByPinboard(currentPinboardID, findallCallback);

				// Alle 5 Sekunden wird die Anfrage erneuert.
				Timer refreshPosts = new Timer() {

					@Override
					public void run() {
						// TODO Auto-generated method stub
						editorAdministration.findPostsByPinboard(currentPinboardID, findallCallback);
					}
				};
				refreshPosts.scheduleRepeating(5000);

			}

			@Override
			public void onFailure(Throwable caught) {
				// TODO Auto-generated method stub

			}
		});

	}
	
	/**
	 * CallBack der Methode <code> findPostsByPinboard(currentPinboardID, findallCallback) </code>
	 * Bei erfolgreichem Rückruf (onSucess) wird der Inhalt der aktuellen <code> currentPosts </code>
	 * mit dem Ergebnis aus der Datenbank <code> result </code> verglichen.
	 * Wenn der Vergleich ergibt, dass diese ungleich sind, wird das <code> postPanel </code> geleert und
	 * mit den aktuellsten Posts <code> result </code> befüllt. So wird sichergestellt, dass immer die aktuellsten
	 * Posts angezeigt werden.
	 */
	class FindAllPostsCallback implements AsyncCallback<Vector<Post>> {

		private PinboardForm pinboardForm;

		private FindAllPostsCallback(PinboardForm pf) {
			// TODO Auto-generated constructor stub
			this.pinboardForm = pf;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());

		}

		@Override
		public void onSuccess(Vector<Post> result) {
			// TODO Auto-generated method stub

			if (vergleich(currentPosts, result) == false) {

				postPanel.clear();

				for (int i = 0; i < result.size(); i++) {
					postPanel.add(new PostForm(result.get(i), user, this.pinboardForm));
				}

				currentPosts = result;
			}
			// else neuster Stand

		}

	}
	
	/**
	 * Vergleichsmethode, um zwei Post-Vectoren miteinander zu vergleichen.
	 * @param current ist der aktuelle Post-Vector
	 * @param result ist in dieser Klasse der Post-Vector, der bei dem CallBack von der Datenbank zurückgegeben wird.
	 * @return (siehe weiter)
	 * Methode gibt false zurück, wenn...
	 *  	- beide Vectoren nicht gleichgroß sind
	 * Methode gibt true zurück, wenn...
	 *  	- die ID der Posts gleich ist UND
	 *  	- der Text der Posts gleich ist
	 */
	public Boolean vergleich(Vector<Post> current, Vector<Post> result) {

		if (current.size() != result.size()) {
			return false;
		}

		for (int i = 0; i < result.size(); i++) {
			boolean found = false;
			for (int j = 0; j < result.size(); j++) {

				if (result.get(i).getId() == current.get(j).getId()
						&& result.get(i).getText() == current.get(j).getText()) {
					found = true;
				}

			}

			if (found == false) {
				return false;
			}
		}

		return true;
	}

	/**
	 * Zum Hinzufügen eines neuen Post in das Pinboard
	 * @param p ist der neue Post, der hinzugefügt werden soll.
	 */
	public void addPostToPinboard(Post p) {
		this.currentPosts.add(p);
		this.postPanel.insert(new PostForm(p, this.user, this), 0);

	}
	/**
	 * Zum Löschen eines Posts aus dem Pinboard
	 * @param p ist der Post, der gelöscht werden soll.
	 */
	public void removePostFromPinboard(Post p) {
		this.currentPosts.remove(p);
	}

	/**
	 * Getter-Methode, um ein User-Objekt der Pinnwand zu bekommen
	 * @return User-Objekt, dem die Pinnwand zugeordnet ist
	 */
	public User getUser() {
		return this.user;
	}

	// Zum Entfernen der aktuellen Posts aus dem Pinboard
	public void clearCurrentPinboard() {
		currentPosts.clear();
		postPanel.clear();
	}
}
