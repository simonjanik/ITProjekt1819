package de.hdm.itprojekt.client.gui;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.client.gui.CommentEditForm.CloseCommentEditFormClickHandler;
import de.hdm.itprojekt.client.gui.CommentEditForm.CommentKeyPressHandler;
import de.hdm.itprojekt.client.gui.CommentEditForm.SaveCommentChangesClickHandler;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.Comment;
import de.hdm.itprojekt.shared.bo.Post;

/**
 * 
 * @author SimonJanik 
 * PostEditForm enhält alle grafischen Elemente und Events
 * die zum Ändern eines Beitrags (Post) benötigt werden. Diese Form
 * öffnet sich als DialogBox. Die Klassen enhält darüberhinaus Methoden
 * zum Öffnen und Schließen der Form.
 */

public class PostEditForm extends DialogBox {

	Post post = null;
	PostForm postForm = null;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();

	Button closeButton = new Button("X");
	Label changeLabel = new Label("Beitrag bearbeiten");
	TextArea changeBox = new TextArea();
	Button saveButton = new Button("Änderungen speichern");
	VerticalPanel content = new VerticalPanel();
	final Label info = new Label("Bitte Textfeld befüllen!");
	final Label textToLong = new Label("Bitte kürze deinen Beitrag. Dieser darf nur eine Länge von 300 Zeichen haben!");

	private VerfiyFieldCallback verfiyCallback;

	
	/**
	 * Konstruktor der PostEditForm
	 * @param p ist der zuändernde Post
	 * @param pf ist die zum Post zugehörige PostForm
	 */
	public PostEditForm(Post p, PostForm pf) {
		this.post = p;
		this.postForm = pf;
		verfiyCallback = new VerfiyFieldCallback();
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Widget, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Widget hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();
		content.add(closeButton);
		content.add(changeLabel);
		content.add(changeBox);
		content.add(saveButton);
		saveButton.addClickHandler(new SavePostChangesClickHandler(this.post, this.postForm, this));
		closeButton.addClickHandler(new ClosePostEditFormClickHandler());
		changeBox.addKeyPressHandler(new PostKeyPressHandler(this.post, this.postForm, this));
		this.add(content);

		//CSS-Klassenselektor
		changeBox.addStyleName("TextEditor");

	}

	/**
	 * <code>PostKeyPressHandler</code>: Wird beim Drücken auf <code> KeyCodes.KEY_ESCAPE </code> und 
	 * <code> KeyCodes.KEY_ENTER </code> ausgelöst.
	 * Der User bestätigt damit seine Änderungen (ENTER) bzw. schließt diese DialogBox (ESC).
	 */
	class PostKeyPressHandler implements KeyPressHandler {
		private Post post = null;
		private PostForm postForm = null;
		private PostEditForm postEditForm = null;

		private PostKeyPressHandler(Post p, PostForm pf, PostEditForm pef) {
			this.post = p;
			this.postForm = pf;
			this.postEditForm = pef;
		}

		@Override
		public void onKeyPress(KeyPressEvent event) {
			// TODO Auto-generated method stub
			if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ESCAPE) {
				closePostEditForm();
			}
			if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ENTER) {
				if(changeBox.getText().length()>800) {
					content.add(textToLong);
				}else {
				editorAdministration.verifyField(new String[] { changeBox.getText() }, verfiyCallback);
				}
			}
		}

	}

	/**
	 * <code>SavePostChangesClickHandler</code>: Wird beim Click auf <code>saveButton</code> ausgelöst.
	 * Der User bestätigt damit seine Änderungen am Post. 
	 * Zunächst wird in der <code> onClick(ClickEvent event) </code>-Methode geprüft, ob der Nutzer
	 * ausschließlich Leerzeichen in die <code> changeBox </code> eingegeben hat.
	 */
	class SavePostChangesClickHandler implements ClickHandler {
		private Post post = null;
		private PostForm postForm = null;
		private PostEditForm postEditForm = null;

		private SavePostChangesClickHandler(Post p, PostForm pf, PostEditForm pef) {
			this.post = p;
			this.postForm = pf;
			this.postEditForm = pef;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			if(changeBox.getText().length()>800) {
				content.add(textToLong);
			}else {
			editorAdministration.verifyField(new String[] { changeBox.getText() }, verfiyCallback);
			}
		}

	}

	/**
	 * <code>UpdatePostCallBack</code> der Impl-Methode <code>updatePost(post, new UpdatePostCallBack()</code>.
	 * Bei erfolgreichem Rückruf (onSucess) wird der der Post-Text grafisch in den <code>postText</code> geschrieben.
	 */
	class UpdatePostCallBack implements AsyncCallback<Post> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if(caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
		}

		@Override
		public void onSuccess(Post result) {
			// TODO Auto-generated method stub
			postForm.postText.setText(result.getText());
			closePostEditForm();
		}

	}

	/**
	 * <code>ClosePostEditFormClickHandler</code>: Wird beim Click auf <code>closeButton</code> ausgelöst.
	 * Der User bestätigt damit das Schließen der <code>PostEditForm</code>
	 */
	class ClosePostEditFormClickHandler implements ClickHandler {

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			closePostEditForm();
		}

	}

	//Zum Schließen dieser Form
	public void closePostEditForm() {
		this.hide();
		this.clear();
		this.removeFromParent();
		this.setAnimationEnabled(false);
		this.setGlassEnabled(false);
	}

	//Zum Öffnen dieser Form
	public void openPostEditForm() {
		this.setGlassEnabled(true);
		this.setAnimationEnabled(true);
		this.center();
		this.show();
		this.changeBox.setText(this.postForm.postText.getText());
		changeBox.setFocus(true);

		if (this.info.isAttached() == true) {
			this.content.remove(this.info);
		}
		if (this.textToLong.isAttached() == true) {
			this.content.remove(this.textToLong);
		}
	}

	/**
	 * <code>VerfiyFieldCallback</code> 
	 * Setzt bei onSuccess() den verifizierten Post grafisch ein und führt die <code>Impll-Methode
	 * updatePost(post, new UpdatePostCallBack())</code> aus, wenn das Rückgabeergebnis ungleich null ist.
	 * Wenn das Ergebnis null ist (=<code>changeBox</code> ist leer), wird der Nutzer aufgefordert
	 * einen gültigen Text einzugeben.
	 */
	class VerfiyFieldCallback implements AsyncCallback<String[]> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
		}

		@Override
		public void onSuccess(String[] result) {
			
			if(result != null) {
				post.setText(result[0]);
				editorAdministration.updatePost(post, new UpdatePostCallBack());
			}else {
				changeBox.getElement().setPropertyString("placeholder", "Bitte einen gültigen Text eingeben!");
			}
			
		}

	}

}
