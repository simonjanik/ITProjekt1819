package de.hdm.itprojekt.client.gui;

import java.util.Vector;

import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.event.logical.shared.SelectionHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.*;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.Sub;
import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author FelixBieswanger, SimonJanik:
 * Diese Form dient der Suche und dem Abonnieren von Pinnwänden anderer Nutzer.
 * Nutzer des System lassen sich über ihren 'Nicknamen' finden. Diese können in die
 * <code>SearchUserForm</code> eingegeben werden und damit gefunden und abonniert werden.
 *
 */
public class SearchUserForm extends HorizontalPanel {

	//Nimmt die Nicknamen auf und unterteilt diese nach anfänglicher Anfrageeingabe
	MultiWordSuggestOracle oracle = null;
	//Alle Nutzernamen
	Vector<String> userNicknames = null;
	Timer refreshNames = null;
	SuggestBox suggestBox = null;
	PushButton searchButton = null;
	Image buttonImage = null;
	SubForm subForm = null;
	User user;

	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	FindAllUserNickNamesCallback findAllUserNickNamesCallback;

	/**
	 * Default-Konstruktor
	 */
	public SearchUserForm() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Konstruktor der SearchUserForm
	 * @param u ist der angemeldete Nutzer
	 */
	public SearchUserForm(User u) {
		this.user = u;
		subForm = new SubForm();
		findAllUserNickNamesCallback = new FindAllUserNickNamesCallback();
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();
		oracle = new MultiWordSuggestOracle();
		suggestBox = new SuggestBox(oracle);
		suggestBox.addKeyDownHandler(new SuggestBoxKeyDownHandler(suggestBox));
		buttonImage = new Image("baseline_person_add_white_48dp.png");
		searchButton = new PushButton(buttonImage, new AddClickhandler(suggestBox));
		this.add(suggestBox);
		this.add(searchButton);

		userNicknames = new Vector<String>();

		this.addStyleName("SearchUser");

		suggestBox.getElement().setPropertyString("placeholder", "Suche deine Freunde...");

		/*
		 * Fordert bei Erstausführung einmalig allen Nicknamen der Datenbank an.
		 */
		editorAdministration.findAllUserNickNames(findAllUserNickNamesCallback);
		/*
		 * Anfrage wird alle 5 Sekunden erneuert. So können dem angemeldeten Nutzer immer alle
		 * aktuellen anderen Nutzer(-Nicknamen) angezeigt werden.
		 */
		refreshNames = new Timer() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				editorAdministration.findAllUserNickNames(findAllUserNickNamesCallback);
			}
		};
		refreshNames.scheduleRepeating(5000);

	}

	/*
	 * 
	 * CLICKHANDLER
	 * 
	 * 
	 */
	
	/**
	 * 
	 * @author SimonJanik, FelixBieswanger:
	 * <code>onClick(ClickEvent event)</code>:
	 * Fügt ein neues Abo in die AboListe des Nutzers hinzu, wenn dieser noch nicht abonniert
	 * ist und dem System bekannt ist.
	 */
	class AddClickhandler implements ClickHandler {

		SuggestBox suggestBox = null;

		public AddClickhandler(SuggestBox suggestBox) {
			// TODO Auto-generated constructor stub
			this.suggestBox = suggestBox;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub

			send(suggestBox);

		}

	}

	/**
	 * 
	 * @author SimonJanik, FelixBieswanger:
	 * <code>onClick(ClickEvent event)</code>:
	 * Führt zum Schließen des <code>popUp</code>:
	 */
	class ClosePopUpClickHandler implements ClickHandler {

		DialogBox popUp = null;

		private ClosePopUpClickHandler(DialogBox pop) {
			// TODO Auto-generated constructor stub
			this.popUp = pop;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub

			popUp.hide();
			popUp.clear();
			popUp.removeFromParent();
			popUp.setAnimationEnabled(false);
			popUp.setGlassEnabled(false);

		}
	}

	/*
	 * 
	 * KEYDOWNHANDLER
	 * 
	 */

	/**
	 * 
	 * @author SimonJanik, FelixBieswanger:
	 * <code>onKeyDown(KeyDownEvent event)</code>:
	 * Fügt ein neues Abo in die AboListe des Nutzers hinzu, wenn dieser noch nicht abonniert
	 * ist und dem System bekannt ist. Der Nutzer muss dafür ENTER drücken.
	 */
	class SuggestBoxKeyDownHandler implements KeyDownHandler {

		SuggestBox suggestBox = null;

		private SuggestBoxKeyDownHandler(SuggestBox sug) {
			// TODO Auto-generated constructor stub

			this.suggestBox = sug;
		}

		@Override
		public void onKeyDown(KeyDownEvent event) {
			// TODO Auto-generated method stub

			if (event.getNativeKeyCode() == KeyCodes.KEY_ENTER) {
				send(suggestBox);
			}

		}

	}

	/*
	 * 
	 * CALLBACKS
	 * 
	 */

	/**
	 * 
	 * @author FelixBieswanger, SimonJanik:
	 * <code>onSuccess(Sub result)</code>:
	 * Leert die <code>suggestBox</code> wieder und fügt der <code>subForm</code> (AboListe des Nutzers)
	 * das Abo hinzu.
	 *
	 */
	class AddSubCallBack implements AsyncCallback<Sub> {

		SuggestBox suggestBox = null;

		private AddSubCallBack(SuggestBox sug) {
			// TODO Auto-generated constructor stub
			this.suggestBox = sug;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if (caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
		}

		@Override
		public void onSuccess(Sub result) {
			// TODO Auto-generated method stub

			// Sub wurde hinzugefügt!
			suggestBox.setText("");
			subForm.addSub(result);

		}

	}

	/**
	 * 
	 * @author FelixBieswanger, SimonJanik:
	 * <code>onSuccess(Vector result)</code>:
	 * Schreibt die Nicknamen der aktuellen Nutzer, die in der Datenbank vorhanden sind in
	 * das <code>oracle</code>.
	 *
	 */
	class FindAllUserNickNamesCallback implements AsyncCallback<Vector<String>> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub

			// Error Handling!
		}

		@Override
		public void onSuccess(Vector<String> result) {
			// TODO Auto-generated method stub

			userNicknames = result;
			oracle.clear();
			for (int i = 0; i < userNicknames.size(); i++) {
				oracle.add(userNicknames.get(i));
			}
		}

	}

	/**
	 * Hilfsmethode, um den eingegebenen Nutzer zu abonnieren
	 * @author FelixBieswanger
	 * @param suggestBox gibt den eingegebenen Nicknamen
	 */
	private void send(SuggestBox suggestBox) {

		String sugBoxtxt = suggestBox.getText();
		//Prüfung, ob der eingegebene Nickname in der Datenbank vorhanden ist (5sek. aktuell)
		if (userNicknames.contains(sugBoxtxt)) {
			//Prüfung, ob der eingegeben Nickname in der aktuelle AboListe vorhanden ist
			if (!(this.subForm.getSubscribedNickNames().contains(sugBoxtxt))) {
				//Wenn Prüfung erfolgreich, dann wird der Nutzer abonniert
				editorAdministration.addSub(new Sub(user.getId(), sugBoxtxt), new AddSubCallBack(suggestBox));
			} else {
				// User schon abboniert
				this.subForm.setSelectedPinboard(sugBoxtxt);
				this.suggestBox.setText("");
			}

		} else {

			/*
			 *  Wenn der User nicht im System registriert ist, bekommt der Nutzer eine Meldung
			 */
			DialogBox popUp = new DialogBox();
			popUp.setGlassEnabled(true);
			popUp.setAnimationEnabled(true);
			popUp.center();
			popUp.show();

			VerticalPanel popUpPanel = new VerticalPanel();
			Label errText = new Label("Der Nutzer ist im System nicht bekannt!");
			Button closeButton = new Button("X", new ClosePopUpClickHandler(popUp));
			popUpPanel.add(errText);
			popUpPanel.add(closeButton);
			popUp.add(popUpPanel);

		}

	}

	/**
	 * Methode zum Setzen der SubForm
	 * @param subform ist die zu setzende SubForm
	 */
	public void setSubForm(SubForm subform) {
		this.subForm = subform;
	}

	/**
	 * Methode zum Ändern des Platzhaltertextes der <code>suggestBox</code> und dem
	 * Text des <code>searchButton</code>
	 * @param second setzt den Platzhaltertext der <code>suggestBox</code>
	 * @param third setzt den Text des <code>searchButton</code>
	 */
	public void changeContentOfForm(String second, String third) {
		suggestBox.getElement().setPropertyString("placeholder", second);
		searchButton.setText(third);

	}

}
