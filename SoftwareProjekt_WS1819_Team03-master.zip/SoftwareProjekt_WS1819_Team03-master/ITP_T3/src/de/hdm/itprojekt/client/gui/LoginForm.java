package de.hdm.itprojekt.client.gui;

import com.google.gwt.user.client.ui.*;

public class LoginForm extends VerticalPanel {

	private Anchor signInLink;
	
	public LoginForm() {
		
	}
	
	public LoginForm(String s) {
		signInLink = new Anchor();
		signInLink.setHref(s);
	
	}
	
	
	public void onLoad() {
		super.onLoad();
		
		VerticalPanel loginPanel = new VerticalPanel();
		loginPanel.setStyleName("LoginPanel");
		
		Image pinStarLogo = new Image("/Offical_Logo.png");
		pinStarLogo.setStyleName("LoginPinLogo");
		
		Label text = new Label("Bitte melden Sie sich an, um Pinnstar zu nutzen!");
		text.setStyleName("LoginText");
		
		Image singInwithGoogle = new Image("/googleSignIN.png");
		singInwithGoogle.setStylePrimaryName("signinwithgoogle");
		signInLink.getElement().appendChild(singInwithGoogle.getElement());
		
		
		loginPanel.add(pinStarLogo);
		loginPanel.add(text);
		loginPanel.add(signInLink);
	
		
		this.add(loginPanel);
		
		
	}
}
