package de.hdm.itprojekt.client.gui;

import java.util.Date;
import com.google.gwt.dom.client.Style.Overflow;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyDownEvent;
import com.google.gwt.event.dom.client.KeyDownHandler;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;
import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.Pinboard;
import de.hdm.itprojekt.shared.bo.Post;
import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author Simon Janik 
 * Diese Form dient dem Nutzer dazu einen Beitrag (Post) zu verfassen und seiner Pinnwand
 * hinzuzufügen. Sie beinhaltet dementsprechend alle Elemente und Funktionen 
 * zum Schreiben von Beiträgen.
 *
 */

public class WritePostForm extends VerticalPanel {

	private Label header = new Label("Beitrag schreiben");
	private TextArea postTextArea = new TextArea();
	private Button postPostButton = new Button("Beitrag posten");
	private PinboardForm pinForm;
	private User user;
	private FieldVerfiyCallback fieldVerifyCallback;
	private FindPinboardID findPinboardIDCallback;
	private AddPostCallBack addPostCallback;

	/**
	 * Instanz des asynchronen Interface f�r editorAdministration erstellen.
	 */
	private EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();

	/**
	 * Default-Konstruktor
	 */
	public WritePostForm() {
		// No-Argument
	}

	/**
	 * Konstruktor der WritePostForm
	 * @param u ist der Autor
	 * @param pf ist die Pinnwand des Autors
	 */
	public WritePostForm(User u, PinboardForm pf) {
		this.user = u;
		this.pinForm = pf;
		fieldVerifyCallback = new FieldVerfiyCallback();
		addPostCallback = new AddPostCallBack();
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();
		/**
		 * CSS-Bezeichner
		 */
		this.addStyleName("WritePost");
		postTextArea.getElement().setPropertyString("placeholder",
				"Was machst du gerade, " + user.getFirstName() + "?");

		/**
		 * Grafische Elemente der WritePostForm hinzufügen.
		 */
		this.add(header);
		this.add(postTextArea);
		this.add(postPostButton);

		// ClickHandler-Vergabe
		postPostButton.addClickHandler(new AddNewPostClickHandler(this.pinForm, this));

		// KeyPressHandler-Vergab: Resizing der postTextArea
		postTextArea.setVisibleLines(2);
		postTextArea.addKeyPressHandler(new ReziseTextAreaKeyPressHandler());
		postTextArea.addKeyDownHandler(new ReziseTextAreaKeyDownHandler());
	}

	/**
	 * 
	 * @author SimonJanik:
	 * Bei Entreten von <code>onClick(ClickEvent event)</code>:
	 * Eingegebener Beitrag wird zunächst geprüft.
	 */
	class AddNewPostClickHandler implements ClickHandler {
		WritePostForm writeForm = null;
		PinboardForm pinboardForm = null;

		private AddNewPostClickHandler(PinboardForm pinboardForm, WritePostForm writeForm) {
			this.writeForm = writeForm;
			this.pinboardForm = pinboardForm;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			if(postTextArea.getText().length()>800) {
				Window.alert("Bitte kürze deinen Beitrag. Dieser darf nur eine Länge von 800 Zeichen haben!");
			}else {
			editorAdministration.verifyField(new String[] { postTextArea.getText() }, fieldVerifyCallback);
			}
		}

	}

	/**
	 * 
	 * @author SimonJanik:
	 * Nach erfolgreicher Speicherung des Posts auf der Datenbank.
	 * Zurückgegebner Beitrag wird der Pinnwand hinzugefügt.
	 */
	class AddPostCallBack implements AsyncCallback<Post> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if(caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
		}

		@Override
		public void onSuccess(Post result) {
			// TODO Auto-generated method stub
			postTextArea.setText("");
			pinForm.addPostToPinboard(result);

		}

	}

	/*
	 * KeyDownHandler und KeyPressHandler, um bei einer Eingabe zu überprüfen,
	 * ob sich das Textfeld dieser Form vergrößern soll.
	 */
	class ReziseTextAreaKeyDownHandler implements KeyDownHandler {

		@Override
		public void onKeyDown(KeyDownEvent event) {
			// TODO Auto-generated method stub
			//Prüfung nach Anzahl der Zeichen
			if (event.getNativeKeyCode() == KeyCodes.KEY_BACKSPACE||
					//Falls ein Windows-User Text mittels Strg+V einfügt
					(event.getNativeKeyCode() == KeyCodes.KEY_CTRL && event.getNativeKeyCode() == KeyCodes.KEY_V)||
					//Falls ein Mac-User Text mittels CMD+V einfügt
					//KeyCode für Chrome
					(event.getNativeKeyCode() == 91 && event.getNativeKeyCode() == KeyCodes.KEY_V)||
					//KeyCode für Firefox
					(event.getNativeKeyCode() == 224 && event.getNativeKeyCode() == KeyCodes.KEY_V)||
					event.getNativeKeyCode() == KeyCodes.KEY_SPACE)
					{
					
					maybeResizeTextArea();
					}
				
			//Prüfung nach Textumbruch
			     	int lines = 2;
		            final String s = postTextArea.getText();
		            for (int i = 0; i != -1; i = s.indexOf("\n", i + 1)) {
		                lines++;
		            }
            if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ENTER) { 
		                lines++;
		            }
		            if(lines>5) {
		            	
		            	postTextArea.setVisibleLines(5);
		            } else {
		            	postTextArea.setVisibleLines(lines);
		            }
			
		}

	}

	class ReziseTextAreaKeyPressHandler implements KeyPressHandler {

		@Override
		public void onKeyPress(KeyPressEvent event) {
			// TODO Auto-generated method stub
			//Prüfung nach Textumbruch
	     		int lines = 2;
	     		final String s = postTextArea.getText();
	     		for (int i = 0; i != -1; i = s.indexOf("\n", i + 1)) {
                lines++;
	     		}
            if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ENTER) { 
                lines++;
            	}
            	if(lines>5) {
            	
            	postTextArea.setVisibleLines(5);
            	maybeResizeTextArea();
            	} else {
            	postTextArea.setVisibleLines(lines);
            	maybeResizeTextArea();
            }
			
		}

	}

	/**
	 * 
	 * @author FelixBieswanger:
	 *  Nach erfolgreicher Prüfung auf Leerzeichen (<code>onSuccess</code>) 
	 *  wird der Post der Pinnwand hinzugefügt
	 *
	 */
	class FindPinboardID implements AsyncCallback<Integer> {

		String verifyedString;

		private FindPinboardID(String s) {
			// TODO Auto-generated constructor stub
			this.verifyedString = s;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());
		}

		@Override
		public void onSuccess(Integer result) {
			// TODO Auto-generated method stub
			Post newPost = new Post(verifyedString, result);
			
			editorAdministration.addPostToPinboard(newPost, addPostCallback);

		}

	}

	/**
	 * @author SimonJanik:
	 * Passt die Höhe (bzw. Lines) der postTextArea an (Bis zu
	 * einer Line-Menge von 5). Dies geschieht anhand von if-Abfragen der vom Nutzer
	 * eingegebenen Zeichenlänge. Die Min-Line-Menge der TextArea beträgt 2. Ab
	 * einer Max-Line-Menge von 5 ist es dem User möglich, mittels Scrollen seine
	 * Eingaben zu sehen.
	 */
	public void maybeResizeTextArea() {

		if (postTextArea.getText().length() > 90) {
			postTextArea.setVisibleLines(3);
		}
		if (postTextArea.getText().length() > 180) {
			postTextArea.setVisibleLines(4);
		}
		if (postTextArea.getText().length() > 270) {
			postTextArea.setVisibleLines(5);
		}

		if (postTextArea.getText().length() < 270) {
			postTextArea.setVisibleLines(4);
		}

		if (postTextArea.getText().length() < 180) {
			postTextArea.setVisibleLines(3);
		}

		if (postTextArea.getText().length() < 90) {
			postTextArea.setVisibleLines(2);
		}
	}


	class FieldVerfiyCallback implements AsyncCallback<String[]> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());
		}

		@Override
		public void onSuccess(String[] result) {
			// TODO Auto-generated method stub

			if (result == null) {
				postTextArea.getElement().setPropertyString("placeholder", "Bitte Textfeld befüllen!");
				postTextArea.setFocus(true);
			} else {
				postTextArea.getElement().setPropertyString("placeholder",
						"Was machst du gerade, " + user.getFirstName() + "?");
				editorAdministration.findPinboardIDByUserID(user.getId(), new FindPinboardID(result[0]));
			}

		}

	}

}
