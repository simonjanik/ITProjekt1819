package de.hdm.itprojekt.client;

import com.google.gwt.core.shared.GWT;

import com.google.gwt.user.client.rpc.AsyncCallback;

import de.hdm.itprojekt.shared.CommonSettings;
import de.hdm.itprojekt.shared.EditorAdministration;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.LoginAdministration;
import de.hdm.itprojekt.shared.LoginAdministrationAsync;
import de.hdm.itprojekt.shared.ReportAdministration;
import de.hdm.itprojekt.shared.ReportAdministrationAsync;

public class ClientSideSettings extends CommonSettings {

	private static EditorAdministrationAsync editorAdministration = null;
	private static ReportAdministrationAsync reportAdministration = null;
	private static LoginAdministrationAsync loginAdministration = null;

	
	public static EditorAdministrationAsync getEditorAdministration() {

		if (editorAdministration == null) {
			editorAdministration = GWT.create(EditorAdministration.class);
			editorAdministration.init(new ClientSideSettings().new InitCallback());
		}

		return editorAdministration;
	}
	


	public static ReportAdministrationAsync getReportAdministration() {
		if (reportAdministration == null) { 
			  reportAdministration= GWT.create(ReportAdministration.class); 
			  reportAdministration.init(new ClientSideSettings().new InitCallback()); 
			  }
			
		return reportAdministration; 
		}


	public static LoginAdministrationAsync getLoginAdministration() {


		if (loginAdministration == null) {
			loginAdministration = GWT.create(LoginAdministration.class);
			loginAdministration.init(new ClientSideSettings().new InitCallback());
		}

		return loginAdministration;
	}

	


	class InitCallback implements AsyncCallback<Void> {


		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSuccess(Void result) {
			// TODO Auto-generated method stub

			// Nothing happens!
		}

	}





}
