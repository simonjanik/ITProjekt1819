package de.hdm.itprojekt.client.gui;

import java.util.Date;
import java.util.UUID;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.dom.client.KeyCodes;
import com.google.gwt.event.dom.client.KeyPressEvent;
import com.google.gwt.event.dom.client.KeyPressHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.TextArea;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.client.gui.CommentEditForm.UpdateCommentCallBack;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.Comment;
import de.hdm.itprojekt.shared.bo.Post;
import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author Simon Janik:
 * Diese Form dient dem Nutzer dazu einen neuen Kommentar zu schreiben.
 * Sie beinhaltet dementsprechend alle Elemente und Funktion 
 * zum Schreiben von Kommentaren (Comments).
 */
public class WriteCommentForm extends DialogBox {

	User author = null;
	Post post = null;
	Comment comment = null;
	PostForm postForm = null;
	InteractionPostFormAll interactionPostForm = null;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();

	Button closeButton = new Button("X");
	Label changeLabel = new Label("Schreibe einen Kommentar:");
	TextArea createBox = new TextArea();
	Button saveButton = new Button("Kommentar abschicken");
	VerticalPanel content = new VerticalPanel();
	final Label info = new Label("Bitte Textfeld befüllen!");
	final Label textToLong = new Label("Bitte kürze deinen Kommentar. Dieser darf nur eine Länge von 300 Zeichen haben!");

	/**
	 * Konstruktor der WriteCommentForm
	 * @param p der Post zu dem der Kommentar verfasst werden soll
	 * @param pf die PostForm zu dazugehörigen Post
	 * @param ipf die InteractionPostFormAll des Post, über den diese Form aufgerufen wird
	 * @param u der Nutzer, der den Kommentar schreibt.
	 */
	public WriteCommentForm(Post p, PostForm pf, InteractionPostFormAll ipf, User u) {
		this.post = p;
		this.postForm = pf;
		this.interactionPostForm = ipf;
		this.author = u;
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();
		content.add(closeButton);
		content.add(changeLabel);
		content.add(createBox);
		content.add(saveButton);
		this.add(content);

		createBox.addStyleName("TextEditor");
		createBox.getElement().setPropertyString("placeholder", "Kommentieren ...");

		//ClickHandler
		saveButton.addClickHandler(new AddCommentClickHandler(this.post, this.postForm, this.interactionPostForm));
		closeButton.addClickHandler(new CloseWriteCommentFormClickHandler());
		createBox.addKeyPressHandler(
				new WriteCommentKeyPressHandler(this.post, this.postForm, this.interactionPostForm));
	}

	/*
	 * Ab hier folgen alle ClickHandler.
	 */

	/**
	 * 
	 * @author SimonJanik:
	 * <code>onKeyPress(KeyPressEvent event)</code>:
	 * Bei Eingabe von ESC wird diese Form geschlossen.
	 * Bei EIngabe von ENTER wird der eingegeben Kommentar zuerst überprüft.
	 */
	class WriteCommentKeyPressHandler implements KeyPressHandler {
		private Post post = null;
		private PostForm postForm = null;
		private InteractionPostFormAll interactionPostForm = null;

		private WriteCommentKeyPressHandler(Post p, PostForm pf, InteractionPostFormAll ipf) {
			this.post = p;
			this.postForm = pf;
			this.interactionPostForm = ipf;
		}

		@Override
		public void onKeyPress(KeyPressEvent event) {
			// TODO Auto-generated method stub
			if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ESCAPE) {
				closeWriteCommentForm();
			}
			if (event.getNativeEvent().getKeyCode() == KeyCodes.KEY_ENTER) {
				if(createBox.getText().length()>300){
					content.add(textToLong);
				} else {
				editorAdministration.verifyField(new String[] {createBox.getText()}, new FieldVerfiyer(postForm));
				}
			}
		}

	}

	/**
	 * 
	 * @author SimonJanik:
	 * <code>onClick(ClickEvent event)</code>:
	 * Schließt diese Form. ClickHandler von <code>closeButton</code>
	 * 
	 */
	class CloseWriteCommentFormClickHandler implements ClickHandler {

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			closeWriteCommentForm();
		}

	}

	// Fügt dem Post einen Kommentar hinzu.
	/**
	 * 
	 * @author SimonJanik:
	 * Äquvivalent zu <code> WriteCommentKeyPressHandler </code>.
	 * Bei Entreten von <code>onClick(ClickEvent event)</code>:
	 * Eingegebener Kommentar wird zunächst geprüft.
	 */
	class AddCommentClickHandler implements ClickHandler {
		private Post post = null;
		private PostForm postForm = null;
		private InteractionPostFormAll interactionPostForm = null;

		AddCommentClickHandler(Post p, PostForm pf, InteractionPostFormAll ipf) {
			this.post = p;
			this.postForm = pf;
			this.interactionPostForm = ipf;

		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			
			if(createBox.getText().length()>300){
				content.add(textToLong);
			} else {
			editorAdministration.verifyField(new String[] {createBox.getText()}, new FieldVerfiyer(postForm));
			}
		}

	}

	/**
	 * 
	 * @author SimonJanik:
	 * Nach erfolgreicher Übertragung des Kommentars zur Datenbank (<code>onSuccess(Comment result)</code>) 
	 * wird diese Form geschlossen und der Kommentar dem Post hinzugefügt.
	 * Die Anzahl der Kommentare wird um einen Zähler erhöht.
	 */
	class AddCommentCallBack implements AsyncCallback<Comment> {

		private PostForm postForm = null;

		public AddCommentCallBack(PostForm pf) {
			// TODO Auto-generated constructor stub
			this.postForm = pf;
		}

		@Override
		public void onFailure(Throwable error) {
			
		if(error instanceof NotLoggedInException) {
			Window.Location.reload();
		}

		}

		@Override
		public void onSuccess(Comment result) {
			// TODO Auto-generated method stub

			closeWriteCommentForm();
			postForm.addCommentToPost(result);

			int temp =Integer.parseInt(interactionPostForm.amountComments.getText());
			interactionPostForm.amountComments.setText(Integer.toString(++temp));
			
		}

	}

	// Methode zum Schließen der WriteCommentForm
	public void closeWriteCommentForm() {
		this.hide();
		this.clear();
		this.removeFromParent();
		this.setAnimationEnabled(false);
		this.setGlassEnabled(false);

	}

	/*
	 * Methode zum Öffnen der WriteCommentForm. Falls der Infotext immer noch
	 * angezeigt wird, soll dieser wieder entfernt werden.
	 */
	public void openWriteCommentForm() {
		this.setGlassEnabled(true);
		this.setAnimationEnabled(true);
		this.center();
		this.show();
		createBox.setFocus(true);

		if (this.info.isAttached() == true) {
			this.content.remove(this.info);
		}
		if (this.textToLong.isAttached() == true) {
			this.content.remove(this.info);
		}

	}

	/**
	 * 
	 * @author SimonJanik:
	 * Nach erfolgreicher Prüfung des Kommentars (<code>onSuccess</code>) auf überflüssige Leerzeichen-Eingabe wird der
	 * Kommentar der Datenbank übergeben.
	 */
	class FieldVerfiyer implements AsyncCallback<String[]> {

		PostForm postForm;

		private FieldVerfiyer(PostForm pf) {
			// TODO Auto-generated constructor stub
			this.postForm = pf;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());

		}

		@Override
		public void onSuccess(String[] result) {
			// TODO Auto-generated method stub

			if (result == null) {
				content.add(info);
			} else {

				Comment newComment = new Comment(result[0], author.getId(), post.getId());
				editorAdministration.addComment(newComment, new AddCommentCallBack(this.postForm));

			}

		}

	}

}
