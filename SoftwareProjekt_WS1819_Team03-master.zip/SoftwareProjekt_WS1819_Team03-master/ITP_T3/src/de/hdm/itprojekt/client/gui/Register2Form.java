package de.hdm.itprojekt.client.gui;

import com.google.gwt.event.dom.client.ClickEvent;

import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.client.gui.report.ReportForm;
import de.hdm.itprojekt.shared.LoginAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.User;

/**
 * 
 * @author SimonJanik
 * @author FelixBieswanger
 * @author DavidRundel Diese Form dient der Erst-Anmeldung des Nutzers, wenn
 *         dieser noch nicht im System registriert ist.
 *
 */
public class Register2Form extends VerticalPanel {

	private User clientBoUser = null;
	private LoginAdministrationAsync loginService;

	/**
	 * Default-Konstruktor
	 */
	public Register2Form() {
	}

	/**
	 * Konstruktor der Register2Form
	 * 
	 * @param clientBoUser ist der Nutzer, der sich im System registrieren möchte.
	 */
	public Register2Form(User clientBoUser) {
		this.clientBoUser = clientBoUser;
		this.loginService = ClientSideSettings.getLoginAdministration();
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt
	 * wurde. Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel
	 * hinzugefügt. Den Buttons werden deren Funktion entsprechend ClickHandler
	 * zugewiesen.
	 */
	public void onLoad() {
		super.onLoad();

		Image logo = new Image("./Offical_Logo.png");
		HorizontalPanel header = new HorizontalPanel();
		header.add(logo);

		VerticalPanel formular = new VerticalPanel();
		Label l0 = new Label("Bitte gib folgende Daten an...");

		// Vorname
		Label l1 = new Label("Vorname:");
		TextBox t1 = new TextBox();
		t1.getElement().setPropertyString("placeholder", "Vorname");

		// Nachname
		Label l2 = new Label("Nachname:");
		TextBox t2 = new TextBox();
		t2.getElement().setPropertyString("placeholder", "Nachname");

		// Nickname
		Label l3 = new Label("Nickname:");
		TextBox t3 = new TextBox();
		t3.getElement().setPropertyString("placeholder", "Nickname");

		this.addStyleName("RegisterForm");
		formular.addStyleName("Formular");

		// Button mit ClickHandler
		Button b4 = new Button("Registrieren", new RegisterClickHandler(t1, t2, t3));

		// Hinzufügen der Widgets zu den Panels
		this.add(header);
		formular.add(t1);
		formular.add(t2);
		formular.add(t3);
		this.add(formular);
		this.add(b4);
		// Cursor-Focus auf die TextBox des Vornamen
		t1.setFocus(true);

	}

	/**
	 * 
	 * @author SimonJanik, FelixBieswanger Nach Auslösen der
	 *         <code>onClick(ClickEvent event)</code>-Methode wird der Nutzer mit
	 *         seinem angegebene Vornamen, Nachnamen und Nicknamen registriert. Wenn
	 *         der eingegebene Nickname jedoch länger als 15 Zeichen ist, wird der
	 *         Nutzer aufgefordert einen Nicknamen unter 15 Zeichen Länge zu wählen.
	 */
	class RegisterClickHandler implements ClickHandler {

		private TextBox t1;
		private TextBox t2;
		private TextBox t3;

		private RegisterClickHandler(TextBox t1, TextBox t2, TextBox t3) {
			// TODO Auto-generated constructor stub
			this.t1 = t1;
			this.t2 = t2;
			this.t3 = t3;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			if (t3.getText().length() > 15) {
				Window.alert("Dein Nickname darf nicht länger als 15 Zeichen sein!");
				return;
			}

			if (t1.getText() == "" || t2.getText() == "" || t3.getText() == "") {
				Window.alert("Bitte füllen Sie alle Felder aus!");
				return;
			}
			clientBoUser.setFirstName(t1.getText());
			clientBoUser.setLastName(t2.getText());
			clientBoUser.setNickName(t3.getText());

			loginService.registerUser(clientBoUser, new RegisterUser());
		}

	}

	/**
	 * 
	 * @author SimonJanik, FelixBieswanger Sobald der Nutzer erfolgreich in der
	 *         Datenbank registriert wurde (<code>onSucess)</code>, wird ein
	 *         Nutzerobjekt dem Pinnwandsystem übergeben und dem Nutzer seine
	 *         Pinnwand angezeigt.
	 *
	 */
	class RegisterUser implements AsyncCallback<User> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if (caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
		}

		@Override
		public void onSuccess(User result) {
			// TODO Auto-generated method stub

			if (Window.Location.getPath() == "/Report.html") {
				RootPanel.get("app").clear();
				RootPanel.get("app").add(new ReportForm(result));
			} else {
				RootPanel.get("app").clear();
				RootPanel.get("app").add(new EditorForm(result));
			}

		}

	}
}