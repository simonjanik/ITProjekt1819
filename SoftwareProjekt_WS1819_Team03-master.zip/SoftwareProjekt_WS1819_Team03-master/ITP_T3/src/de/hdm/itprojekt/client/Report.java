package de.hdm.itprojekt.client;

import com.google.gwt.core.client.EntryPoint;

import com.google.gwt.core.client.GWT;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Anchor;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.RootPanel;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.gui.EditorForm;
import de.hdm.itprojekt.client.gui.LoginForm;
import de.hdm.itprojekt.client.gui.Register2Form;
import de.hdm.itprojekt.client.gui.report.ReportForm;
import de.hdm.itprojekt.shared.LoginAdministrationAsync;
import de.hdm.itprojekt.shared.bo.User;

public class Report implements EntryPoint {

	private LoginAdministrationAsync loginService = ClientSideSettings.getLoginAdministration();
	private User userSaveData;

	public void onModuleLoad() {
		RootPanel.get("app").clear();
		loginService.login(Window.Location.getHref(), new LoginCallback());
	}

	public class LoginCallback implements AsyncCallback<User> {
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert("Login");
			Window.alert(caught.getMessage());

		}

		public void onSuccess(User userBO) {
			if (userBO != null) {
				userSaveData = userBO;

				if (userBO.getIsLoggedIn() == false) {
					loadLogin(userBO);
					return;
				} else {
					loginService.checkUserKnown(userBO, new UserKnownCallback());
				}

			}
		}
	}

	public class UserKnownCallback implements AsyncCallback<User> {

		@Override
		public void onFailure(Throwable caught) {
			Window.alert("UserKnown");
			Window.alert(caught.getMessage());
		}

		@Override
		public void onSuccess(User serverBoUserForCheck) {
			if (serverBoUserForCheck != null) {
				loadReport(serverBoUserForCheck);
			} else {
				loadRegister2Form(userSaveData);
			}

		}
	}

	public void loadReport(User clientBoUser) {
		RootPanel.get("app").add(new ReportForm(clientBoUser));
	}

	public void loadLogin(User userBO) {
		// Assemble login panel.
		RootPanel.get("app").add(new LoginForm(userBO.getLoginURL()));

	}

	public void loadRegister2Form(User clientBoUser) {
		if (clientBoUser != null) {
			RootPanel.get("app").add(new Register2Form(clientBoUser));
		}
	}

}
