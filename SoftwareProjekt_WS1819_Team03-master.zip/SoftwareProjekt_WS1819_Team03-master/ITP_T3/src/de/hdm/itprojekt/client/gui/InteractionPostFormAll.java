package de.hdm.itprojekt.client.gui;

import java.util.Vector;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.safehtml.shared.SafeHtml;
import com.google.gwt.user.client.Command;

import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Image;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.MenuBar;
import com.google.gwt.user.client.ui.MenuItem;
import com.google.gwt.user.client.ui.PushButton;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.MapperException;
import de.hdm.itprojekt.shared.NotLoggedInException;

import de.hdm.itprojekt.shared.bo.*;

public class InteractionPostFormAll extends HorizontalPanel {

	Post post;
	PostForm postForm;
	User user;
	private EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	private FindAllLikesCallBack findLikesCallback;
	private FindAllCommentsCallBack findCommentsCallback;
	private Boolean multipleLikeTrigger = false;
	Timer refreshLikes;
	Like currentLike = null;

	public InteractionPostFormAll(Post p, PostForm pf, User u) {
		this.post = p;
		this.postForm = pf;
		this.user = u;
		findLikesCallback = new FindAllLikesCallBack();
		findCommentsCallback = new FindAllCommentsCallBack();

	}

	public InteractionPostFormAll() {
		// TODO Auto-generated constructor stub
	}

	// Like-Elemente

	Vector<Like> allLikes = new Vector<Like>();

	Vector<Like> currentLikes;
	Vector<MenuItem> currentMenuItems;
	MenuBar likeMenu;
	MenuItem likeBarHead;
	MenuBar likesBar;
	Label amountLikes;
	Image likeButtonPictureNormal = new Image("baseline_thumb_up_white_48dp.png");
	Image likeButtonPictureLiked = new Image("baseline_thumb_up_green_48dp.png");
	PushButton likeButton = new PushButton(likeButtonPictureNormal);
	HorizontalPanel likeSection = new HorizontalPanel();

	// Kommentar-Elemente
	Button commentButton = new Button("Kommentieren");
	Label commentPostLabel;
	Label amountComments;
	Boolean commentTrigger = false;
	HorizontalPanel commentSection = new HorizontalPanel();
	HorizontalPanel midSection = new HorizontalPanel();

	public void onLoad() {
		super.onLoad();

		this.addStyleName("InteractionPostFormAll");
		midSection.addStyleName("InteractionButtons");

		currentMenuItems = new Vector<>();
		currentLikes = new Vector<>();
		commentPostLabel = new Label("Kommentare");
		commentPostLabel.addClickHandler(new ShowKommentareClick());

		likeMenu = new MenuBar(false);
		likeMenu.addStyleName("LikeMenu");
		likeMenu.setAnimationEnabled(true);
		likeMenu.setAutoOpen(true);
		likesBar = new MenuBar(true);
		likesBar.moveSelectionDown();
		likeBarHead = new MenuItem("Likes", true, likesBar);
		likeMenu.addItem(likeBarHead);

		this.addStyleName("InteractionLine");
		// normalPostPanel.addStyleName("InteractionPostPanel");

		likeButtonPictureLiked.addStyleName("icon");
		likeButtonPictureNormal.addStyleName("icon");
		likeButton.addStyleName("likeButton");
		commentPostLabel.addStyleName("PostLabels");

		amountLikes = new Label("0");
		amountLikes.addStyleName("AmountLikes");
		amountComments = new Label("0");

		likeSection.add(amountLikes);
		likeSection.add(likeMenu);

		midSection.add(likeButton);
		midSection.add(commentButton);

		commentSection.add(amountComments);
		commentSection.add(commentPostLabel);
		commentSection.addStyleName("CommentLabels");

		this.add(likeSection);
		this.add(midSection);

		likeButton.addClickHandler(new LikePostClickHandler(post, postForm, this));
		commentButton.addClickHandler(new CommentPostClickHandler(post, postForm, this));

		editorAdministration.findAllLikesByPost(post.getId(), findLikesCallback);
		editorAdministration.findCommentsByPost(post.getId(), findCommentsCallback);
		refreshLikes = new Timer() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				editorAdministration.findAllLikesByPost(post.getId(), findLikesCallback);
				editorAdministration.findCommentsByPost(post.getId(), findCommentsCallback);
			}
		};

		refreshLikes.scheduleRepeating(5000);
	}

	class LikePostClickHandler implements ClickHandler {
		private Post post = null;
		private PostForm postForm = null;
		private InteractionPostFormAll interactionPostForm = null;

		private LikePostClickHandler(Post p, PostForm pf, InteractionPostFormAll ipf) {
			this.post = p;
			this.postForm = pf;
			this.interactionPostForm = ipf;
		}

		@Override
		public void onClick(ClickEvent event) {
//			try {
			if (multipleLikeTrigger == false) {
				if (currentLike == null) {
					Like l = new Like(this.post.getId(), user.getId());
					editorAdministration.addLike(l, new AddLikeCallBack());
					multipleLikeTrigger = true;
				} else {
					editorAdministration.deleteLike(currentLike.getId(), new DeleteLikeCallBack());
					multipleLikeTrigger = true;
				}
			}

//			}

//		David: Hätte das eigentlich bei AddLickeCallback onFailure erwartet,
//		Wird Exception in Callback zurückgegeben? Muss ja eigentlich wegen RPC, wenn Methode die 
//		Exception throwt erst serverseitig aufgerufen wird.
//		catch (NotLoggedInException exception) {
//		    Window.alert(exception.getMessage() + " - Fehler in OnClick.");
//		    if (exception instanceof NotLoggedInException) {
////		      loadLogin;
//		    }	
//		}

		}
	}

	class CommentPostClickHandler implements ClickHandler {
		private Post post = null;
		private PostForm postForm = null;
		private InteractionPostFormAll interactionPostForm = null;

		CommentPostClickHandler(Post p, PostForm pf, InteractionPostFormAll ipf) {
			this.post = p;
			this.postForm = pf;
			this.interactionPostForm = ipf;
		}

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			WriteCommentForm writeCommentForm = new WriteCommentForm(this.post, this.postForm, this.interactionPostForm,
					user);
			writeCommentForm.openWriteCommentForm();

		}

	}

	class AddLikeCallBack implements AsyncCallback<Like> {

		@Override
		public void onFailure(Throwable exception) {

			if (exception instanceof NotLoggedInException) {
				Window.Location.reload();
			}

		}

		@Override
		public void onSuccess(Like result) {
			// TODO Auto-generated method stub

			currentLike = result;
			currentLikes.add(currentLike);
			likesLabelAdjust(currentLikes.size());
			currentMenuItems.add(likesBar.addItem(result.getLikerNickName(), new Command() {

				@Override
				public void execute() {
					// TODO Auto-generated method stub
				}
			}));

			amountLikes.setText(Integer.toString(currentLikes.size()));
			likeButton.getUpFace().setImage(likeButtonPictureLiked);
			multipleLikeTrigger = false;

		}

	}

	class DeleteLikeCallBack implements AsyncCallback<Void> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub

			if (caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
		}

		@Override
		public void onSuccess(Void result) {
			// TODO Auto-generated method stub
			currentLikes.remove(currentLike);
			likesLabelAdjust(currentLikes.size());
			amountLikes.setText(Integer.toString(currentLikes.size()));
			MenuItem menuI = findMenuItem(currentLike.getLikerNickName());
			currentMenuItems.remove(menuI);
			likesBar.removeItem(menuI);

			currentLike = null;
			likeButton.getUpFace().setImage(likeButtonPictureNormal);
			multipleLikeTrigger = false;

		}

	}

	class FindAllLikesCallBack implements AsyncCallback<Vector<Like>> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSuccess(Vector<Like> result) {
			// TODO Auto-generated method stub

			if (currentLikes.size() != result.size()) {
				currentLikes = result;

				amountLikes.setText(Integer.toString(result.size()));
				likesLabelAdjust(result.size());

				likesBar.clearItems();

				likeButton.getUpFace().setImage(likeButtonPictureNormal);
				for (int i = 0; i < result.size(); i++) {

					if (user.getId() == result.get(i).getUserID()) {
						likeButton.getUpFace().setImage(likeButtonPictureLiked);
						currentLike = result.get(i);
					}

					likesBar.addItem(result.get(i).getLikerNickName(), new Command() {

						@Override
						public void execute() {
							// TODO Auto-generated method stub
						}
					});

				}
			}

		}

	}

	class FindAllCommentsCallBack implements AsyncCallback<Vector<Comment>> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSuccess(Vector<Comment> result) {
			// TODO Auto-generated method stub
			if (result.size() != Integer.parseInt(amountComments.getText())) {
				amountComments.setText(Integer.toString(result.size()));
				commentsLabelAdjust(result.size());
			}

		}

	}

	class ShowKommentareClick implements ClickHandler {

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub

			if (commentTrigger == false) {
				postForm.showComments();
				commentTrigger = true;
			} else {
				postForm.hideComments();
				commentTrigger = false;
			}

		}

	}

	public void showComments() {
		this.add(commentSection);
	}

	public void hideComments() {
		this.remove(commentSection);
	}

	private MenuItem findMenuItem(String nick) {

		for (int i = 0; i < currentMenuItems.size(); i++) {
			if (currentMenuItems.get(i).getText() == nick) {
				return currentMenuItems.get(i);
			}

		}

		return null;
	}

	public void commentsLabelAdjust(int size) {

		if (size == 1) {
			commentPostLabel.setText("Kommentar");
		} else {
			commentPostLabel.setText("Kommentare");
		}
	}

	private void likesLabelAdjust(int size) {
		if (currentLikes.size() == 1) {
			likeBarHead.setText("Like");
		} else {
			likeBarHead.setText("Likes");
		}
	}

}
