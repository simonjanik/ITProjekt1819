package de.hdm.itprojekt.client.gui;

import java.security.PublicKey;
import java.util.Collections;
import java.util.List;
import java.util.Vector;

import org.apache.tools.ant.types.CommandlineJava.SysProperties;
import org.eclipse.jdt.internal.compiler.parser.diagnose.DiagnoseParser;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.cellview.client.CellList;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.view.client.ListDataProvider;
import com.google.gwt.view.client.ProvidesKey;
import com.google.gwt.view.client.SelectionChangeEvent;
import com.google.gwt.view.client.SelectionModel;
import com.google.gwt.view.client.SingleSelectionModel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.*;

/**
 * 
 * @author FelixBieswanger
 * Diese Form enthält alle Elemente und Funktionen, um neue Abonnements in einer Listenform
 * zu speichern und einzelne Abonnements zu deabonnieren.
 */
public class SubForm extends VerticalPanel {

	private User user = null;
	private EditorAdministrationAsync editorAdministraion = ClientSideSettings.getEditorAdministration();

	private Sub selectedSub = null;
	private CellList<Sub> cellList;
	private SelectionModel<Sub> selectionModel;
	private ListDataProvider<Sub> cellListDataProvider;
	private PinboardForm pinboardForm;
	private Vector<Sub> currentsubs;
	private FindSubsByUserCallback findSubsCallback;
	private Button removeSub;
	private int pinboarIDCurrentUser;

	/**
	 * Default-Konstruktor
	 */
	public SubForm() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * Konstruktor der SubForm
	 * @param u ist der Nutzer, dem die SubForm gehört
	 */
	public SubForm(User u) {
		this.user = u;
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();
		editorAdministraion.findPinboardIDByUserID(this.user.getId(), new FindPinboardIDCallback(this));
	}

	/*
	 * 
	 * CallBacks
	 * 
	 * 
	 */
	class FindSubsByUserCallback implements AsyncCallback<Vector<Sub>> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());
		}

		@Override
		public void onSuccess(Vector<Sub> result) {
			// TODO Auto-generated method stub

			// Anzahl der Subs hat sich durch Hinzufügen oder Löschen einer Pinnwand
			// verändert
			if (checkIfNew(result)) {
				// Aktuelle anzahl als currentSubs setzen
				currentsubs = result;

				// Daten der CellList zurücksetzen
				cellListDataProvider.getList().clear();

				// Anlegen der Variable indexOwnSub da "Own Pinboard" setz als erstes aufgeführt
				// werden soll
				int indexOwnSub = 0;

				// Hinzufügen der neuen Daten/Subs zur Celllist
				for (int i = 0; i < result.size(); i++) {

					// Wenn Sub gefunden ist, welcehs ein selbst subscribed index in indexOwn
					// festhalten
					if (result.get(i).getSubscribedUserNickName() == user.getNickName()) {
						indexOwnSub = i;
					}
					cellListDataProvider.getList().add(result.get(i));
				}

				// Eigenes Sub an Anfang der Liste (index 0) tauschen
				Collections.swap(cellListDataProvider.getList(), indexOwnSub, 0);

				if (selectedSub != null) {
					for (int i = 0; i < cellListDataProvider.getList().size(); i++) {
						if (cellListDataProvider.getList().get(i).getId() == selectedSub.getId()) {
							return;
						}
					}
				}

				selectionModel.setSelected(cellListDataProvider.getList().get(0), true);

			}			

		}

	}

	class SelectionHandler implements SelectionChangeEvent.Handler {

		/**
		 * Wird aufgerufen, wenn eine Cell in der Celllist selektiert wird (Durch Click
		 * auf Cell oder durch aufruf selectionmodel.setselected
		 **/
		@Override
		public void onSelectionChange(SelectionChangeEvent event) {
			// TODO Auto-generated method stub

			/**
			 * 
			 * Das jeweilige selectierte Sub wird in der varibale selectedSub festgehalten
			 * 
			 **/
			selectedSub = ((SingleSelectionModel<Sub>) selectionModel).getSelectedObject();

			/**
			 * 
			 * Die PinboardForm bekommmt nun die anweisen, die selektierte Pinnwand für den
			 * Nutzer anzuzeigen
			 * 
			 **/
			pinboardForm.setCurrentPinboard(selectedSub.getPinboardID());
			
			
			if(pinboarIDCurrentUser == selectedSub.getPinboardID()) {
				removeSub.setText("Pinnwand löschen");
			}else {
				removeSub.setText("Deabbonieren");
			}

		}

	}

	class RemoveSubClickHandler implements ClickHandler {

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub

			if (user.getNickName() == selectedSub.getSubscribedUserNickName()) {

				DialogBox deleteOwnDiaBox = new DialogBox();
				VerticalPanel delelteOwnPanel = new VerticalPanel();
				Label deleteMessage = new Label(
						"Bist du sicher, dass du deine Pinnwand und damit alle deine Beiträge löschen willst?");
				HorizontalPanel delelteOwnButtonPanel = new HorizontalPanel();

				Button deleteYesButton = new Button("Ja", new DeleteYesButton(deleteOwnDiaBox));
				Button deleteNoButton = new Button("Nein", new DeleteNoButton(deleteOwnDiaBox));

				deleteOwnDiaBox.setGlassEnabled(true);
				deleteOwnDiaBox.setAnimationEnabled(true);
				deleteOwnDiaBox.center();
				deleteOwnDiaBox.show();

				delelteOwnPanel.add(deleteMessage);
				delelteOwnButtonPanel.add(deleteNoButton);
				delelteOwnButtonPanel.add(deleteYesButton);
				delelteOwnPanel.add(delelteOwnButtonPanel);
				deleteOwnDiaBox.add(delelteOwnPanel);

			} else {
				editorAdministraion.deleteSub(selectedSub.getId(), new DeleteSubCallBack());
			}

		}

	}

	class DeleteNoButton implements ClickHandler {

		private DialogBox dialogBox;

		public DeleteNoButton(DialogBox db) {
			// TODO Auto-generated constructor stub
			this.dialogBox = db;
		}

		/**
		 * 
		 * Wird aufgerufen wenn Nutzer nicht seine Pinnwand entleeren möchte und in der
		 * DialogBox den Button "No" Clickt
		 * 
		 **/

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub

			/** Entfernt die DialogBox **/
			dialogBox.removeFromParent();
		}

	}

	class DeleteYesButton implements ClickHandler {

		private DialogBox dialogBox;

		private DeleteYesButton(DialogBox dia) {
			// TODO Auto-generated constructor stub
			this.dialogBox = dia;
		}

		/**
		 * Wird aufgerufen wenn Nutzer seine Pinnwand entleeren möchte und in der
		 * DialogBox den Button "Yes" clickt
		 **/

		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub

			/** Ruft die editoradministration auf die Pinnwand zu löschen(entleeren) **/
			editorAdministraion.deletePinboard(selectedSub.getPinboardID(), new DeletePinboardCallback(this.dialogBox));
		}

	}

	class DeleteSubCallBack implements AsyncCallback<Void> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if(caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
		}

		@Override
		public void onSuccess(Void result) {
			// TODO Auto-generated method stub

			cellListDataProvider.getList().remove(cellListDataProvider.getList().indexOf(selectedSub));
			selectedSub = null;
			selectionModel.setSelected(cellListDataProvider.getList().get(0), true);
		}

	}

	public void addSub(Sub sub) {

		currentsubs.add(sub);
		cellListDataProvider.getList().add(sub);
		selectionModel.setSelected(sub, true);

	}

	public void setPinboardForm(PinboardForm pinForm) {
		this.pinboardForm = pinForm;
	}

	public Vector<String> getSubscribedNickNames() {
		Vector<String> result = new Vector<>();

		for (int i = 0; i < this.cellListDataProvider.getList().size(); i++) {
			result.add(this.cellListDataProvider.getList().get(i).getSubscribedUserNickName());

		}

		return result;

	}

	public void setSelectedPinboard(String nick) {

		List<Sub> subList = this.cellListDataProvider.getList();
		int pinID;
		for (int i = 0; i < subList.size(); i++) {

			if (subList.get(i).getSubscribedUserNickName() == nick) {
				pinID = subList.get(i).getPinboardID();
				this.selectionModel.setSelected(subList.get(i), true);
				this.pinboardForm.setCurrentPinboard(pinID);
				break;
			}
		}

	}

	class DeletePinboardCallback implements AsyncCallback<Void> {

		private DialogBox dialogBox;

		private DeletePinboardCallback(DialogBox dia) {
			// TODO Auto-generated constructor stub
			this.dialogBox = dia;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if(caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}

		}

		@Override
		public void onSuccess(Void result) {
			// TODO Auto-generated method stub
			pinboardForm.clearCurrentPinboard();
			dialogBox.removeFromParent();
		}

	}

	// true wenns neue inhalte gibt
	private boolean checkIfNew(Vector<Sub> result) {

		if (currentsubs.size() != result.size()) {
			return true;
		}

		for (int i = 0; i < result.size(); i++) {
			boolean found = false;
			for (int j = 0; j < result.size(); j++) {

				if (result.get(i).getId() == currentsubs.get(j).getId() && result.get(i)
						.getSubscribedUserNickName() == currentsubs.get(j).getSubscribedUserNickName()) {
					found = true;
				}
			}

			if (found == false) {
				return true;
			}
		}

		return false;
	}
	
	class FindPinboardIDCallback implements AsyncCallback<Integer>{
		
		SubForm subform;
		
		public FindPinboardIDCallback(SubForm sm) {
			// TODO Auto-generated constructor stub
			this.subform=sm;
		}

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			Window.alert(caught.getMessage());
		}

		@Override
		public void onSuccess(Integer result) {
			// TODO Auto-generated method stub
			
			ProvidesKey<Sub> keyProvider = new ProvidesKey<Sub>() {

				@Override
				public Object getKey(Sub item) {
					// TODO Auto-generated method stub
					if (item != null) {
						return item.getId();
					} else
						return null;
				}
			};

			pinboarIDCurrentUser = result;
			cellList = new CellList<>(new SubCell(pinboarIDCurrentUser), keyProvider);
			selectionModel = new SingleSelectionModel<>(keyProvider);
			cellList.setSelectionModel(selectionModel);
			selectionModel.addSelectionChangeHandler(new SelectionHandler());

			cellListDataProvider = new ListDataProvider<Sub>();
			cellListDataProvider.addDataDisplay(cellList);
			currentsubs = new Vector<>();

			findSubsCallback = new FindSubsByUserCallback();
			

			Label head = new Label("Deine Pinwände");
			subform.add(head);
			subform.add(cellList);
			
			removeSub  = new Button("Deabonnieren", new RemoveSubClickHandler());
			
			subform.add(removeSub);

			cellList.addStyleName("AboList");
			subform.addStyleName("SubForm");

			/**
			 * 
			 * Methode wird vor dem Timer schon aufgerufen, um die verzögerung um 5sek zu
			 * eleminieren
			 * 
			 **/
			editorAdministraion.findSubsByUser(user.getId(), findSubsCallback);

			/**
			 * 
			 * Jede 5 Sekunden wird geprüft, ob durch einen anderen Client eine neue Sub
			 * Beziehung hinzugefügt wurde
			 * 
			 **/
			Timer refresh = new Timer() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					editorAdministraion.findSubsByUser(user.getId(), findSubsCallback);
				}

			};

			/** Setzen der Refreshzeit auf 5000ms = 5s **/
			refresh.scheduleRepeating(5000);
			
		}
		
	}

}
