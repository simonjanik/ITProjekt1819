package de.hdm.itprojekt.client.gui;

import java.util.Vector;

import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.bo.*;

/**
 * 
 * @author FelixBieswanger
 * NewsFeed zeigt dem User alle neuen Posts (in Kurzform) von ihm/ihr selber und seinen Abonnements an.
 */
public class NewsFeed extends VerticalPanel {

	private EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	private User user;
	private Vector<Post> currentPost;
	private VerticalPanel postPanel;
	private PostForNewsFeedCallback callback;
	private SubForm subForm;
	
	
	
	/**
	 * Default-Konstruktor
	 */
	public NewsFeed() {
		// TODO Auto-generated constructor stub
	}
	
	
	/**
	 * Konstruktor des NewsFeed
	 * @param u ist der aktuelle Nutzer
	 */
	public NewsFeed(User u) {
		this.user = u;
		currentPost = new Vector<>();
		callback = new PostForNewsFeedCallback();
	}

	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
		super.onLoad();
		Label head = new Label("NewsFeed");
		head.setStyleName("NewsFeedTitle");
		
		postPanel = new VerticalPanel();
		this.add(head);
		this.add(postPanel);

		
		/*
		 * 	Bei Erstausführung der Anwendung werden alle neuen Posts sortiert nach Erstellungsdatum in den NewsFeed geladen, d.h.
		 * der Nutzer bekommt die neusten Posts ganz oben in seinem NewsFeed angezeigt.
		 */
		editorAdministration.getPostForNewsFeed(this.user, callback);

		/*
		 * Alle 5 Sekunden wird der NewsFeed aktualisiert.
		 */
		Timer refreshPosts = new Timer() {

			@Override
			public void run() {
				// TODO Auto-generated method stub
				editorAdministration.getPostForNewsFeed(user, callback);
			}
		};

		refreshPosts.scheduleRepeating(5000);

	}
	
	/**
	* PostForNewsFeedCallBack als Rückruf auf die Methode <code>getPostForNewsFeed(user, callback)</code>
	* Bei erfolgreichem Rückruf (onSucess):
	* Die aktuell angezeigten <code>currentPost</code> und die von der Datenbank zurückgegebenen <code>result</code>-Posts
	* werden miteinander verglichen. Wenn deren Inhalt nicht gleich ist (gleiche ID, gleicher Text), werden die
	* <code>result</code>-Posts in den <code>currentPost</code>-Vector geschrieben.
	* Alle bisherigen Einträge im NewsFeed werden anschließend entfernt und die neuen Posts aus dem
	* <code>result</code>-Vector eingefügt. Diese beinhalten den aktuellen Stand der Datenbank.
	*/
	
	class PostForNewsFeedCallback implements AsyncCallback<Vector<Post>> {

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub

		}

		@Override
		public void onSuccess(Vector<Post> result) {
			// TODO Auto-generated method stub

			if(vergleich(currentPost, result)== false) {
				currentPost = result;
				postPanel.clear();
				
				for(int i =0;i<result.size();i++) {
					postPanel.add(new PostFormShort(result.get(i),user,subForm));
				}
				
			}

		}

	}
	

	/**
	 * Vergleichsmethode, um zwei Post-Vectoren miteinander zu vergleichen.
	 * @param current ist der aktuelle Post-Vector
	 * @param result ist in dieser Klasse der Post-Vector, der bei dem CallBack von der Datenbank zurückgegeben wird.
	 * @return (siehe weiter)
	 * Methode gibt false zurück, wenn...
	 *  	- beide Vectoren nicht gleichgroß sind
	 * Methode gibt true zurück, wenn...
	 *  	- die ID der Posts gleich ist UND
	 *  	- der Text der Posts gleich ist
	 */
	public Boolean vergleich(Vector<Post> current, Vector<Post> result) {

		if (current.size() != result.size()) {
			return false;
		}

		for (int i = 0; i < result.size(); i++) {
			boolean found = false;
			for (int j = 0; j < result.size(); j++) {

				if (result.get(i).getId() == current.get(j).getId()
						&& result.get(i).getText() == current.get(j).getText()) {
					found = true;
				}

			}

			if (found == false) {
				return false;
			}
		}

		return true;
	}
	
	
	// Setter, um die SubForm zu setzen
	public void setSubForm(SubForm subf) {
		this.subForm = subf;
	}

}
