package de.hdm.itprojekt.client.gui.report;


import java.util.Date;


import com.google.gwt.i18n.client.DateTimeFormat;

import com.google.gwt.safehtml.shared.SafeHtml;

import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Vector;

import org.apache.commons.lang3.time.DateUtils;
import org.apache.james.mime4j.field.datetime.DateTime;

import com.gargoylesoftware.htmlunit.StorageHolder.Type;
import com.google.gwt.event.dom.client.ChangeEvent;
import com.google.gwt.event.dom.client.ChangeHandler;
import com.google.gwt.event.dom.client.ClickEvent;
import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.event.logical.shared.ValueChangeEvent;
import com.google.gwt.event.logical.shared.ValueChangeHandler;
import com.google.gwt.i18n.client.DateTimeFormat;
import com.google.gwt.user.client.Timer;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.CheckBox;
import com.google.gwt.user.client.ui.HTML;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.ListBox;
import com.google.gwt.user.client.ui.RadioButton;
import com.google.gwt.user.client.ui.TextBox;
import com.google.gwt.user.client.ui.VerticalPanel;
import com.google.gwt.user.datepicker.client.DateBox;
import com.google.gwt.user.datepicker.client.DatePicker;
import com.google.gwt.user.datepicker.client.CalendarUtil;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.client.gui.SearchUserForm;
import de.hdm.itprojekt.server.db.UserMapper;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.LoginAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.ReportAdministrationAsync;
import de.hdm.itprojekt.shared.bo.User;
import de.hdm.itprojekt.shared.report.CommentReport;
import de.hdm.itprojekt.shared.report.CompositeReport;
import de.hdm.itprojekt.shared.report.HTMLReportWriter;
import de.hdm.itprojekt.shared.report.LikeReport;
import de.hdm.itprojekt.shared.report.PostReport;
import de.hdm.itprojekt.shared.report.Report;
import de.hdm.itprojekt.shared.report.Row;
import de.hdm.itprojekt.shared.report.SimpleReport;
import de.hdm.itprojekt.shared.report.SubReport;

public class ReportFilterForm extends VerticalPanel {
	ReportAdministrationAsync reportAdministration = ClientSideSettings.getReportAdministration();
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();
	LoginAdministrationAsync loginAdministration = ClientSideSettings.getLoginAdministration();



	User clientBoUser = new User();
	ReportForm clientReportForm = new ReportForm();

	Vector<User> allUsers = null;

	Vector<String> allusersS = new Vector<String>();
	Vector<String> choosenUsersS = new Vector<String>();

	Date choosenStartDate = null;
	Date choosenEndDate = null;

	Date today;
	Date firstPossibleDate = new Date(119, 0, 1);
	Date secondPossibleDate = new Date(119, 0, 2);
	Date lastImpossibleDate = new Date(118, 11, 31);
	Date dateafterchosenstartDate = new Date(119, 0, 2);

	Vector<SimpleReport> choosenReportsS = new Vector<SimpleReport>();

	public ReportFilterForm() {

	}

	public ReportFilterForm(User cBU, ReportForm cRF) {
		this.clientBoUser = cBU;
		this.clientReportForm = cRF;
	}

	VerticalPanel pickUser = new VerticalPanel();
	Label chooseUser = new Label("Nutzer wählen");

	VerticalPanel radioButtons = new VerticalPanel();
	RadioButton selectOneUserButton = new RadioButton("UserGroup", "Nur für mich");
	RadioButton selectSpecificUserButton = new RadioButton("UserGroup", "Für spezifische User");
	RadioButton selectAllUserButton = new RadioButton("UserGroup", "Für alle User");

	VerticalPanel selectSpecificUserPanel = new VerticalPanel();
	VerticalPanel sSUSP = new VerticalPanel();

	VerticalPanel pickPeriod = new VerticalPanel();
	Label choosePeriodLabel = new Label("Zeitraum wählen");
	HorizontalPanel startEndHPanel = new HorizontalPanel();

	DateBox startDateBox = new DateBox();
	Label bindestrichlabel = new Label("-");
	DateBox endDateBox = new DateBox();



	HorizontalPanel periodShortcutsHor = new HorizontalPanel();
	Button last3DaysButton = new Button("Letzte 3 Tage");
	Button lastWeekButton = new Button("Letzte Woche");
	Button lastMonthButton = new Button("Letzter Monat");

	VerticalPanel pickKindOfReport = new VerticalPanel();
	Label kindOfReportLabel = new Label("Art des Reports");
	RadioButton allReportButton = new RadioButton("ReportGroup", "All-In-One");
	RadioButton specificReportButton = new RadioButton("ReportGroup", "Spezifische Auswahl");

	CheckBox subscriptionReportButton = new CheckBox("Anzahl von Abonnenten");
	CheckBox postReportButton = new CheckBox("Anzahl von Beiträgen");
	CheckBox commentReportButton = new CheckBox("Anzahl von Kommentaren");
	CheckBox likeReportButton = new CheckBox("Anzahl von Likes");
	VerticalPanel checkBoxContainer = new VerticalPanel();


	Button getReportButton = new Button("Report anfordern");

	public void onLoad() {
		super.onLoad();
		
		lastImpossibleDate.setHours(23);
		lastImpossibleDate.setMinutes(59);
		lastImpossibleDate.setSeconds(59);

		// STYLENAMES

		pickUser.addStyleName("PickUserVPanel");
		chooseUser.addStyleName("ChooseUserLabel");
		selectAllUserButton.addStyleName("Test");
		radioButtons.addStyleName("RadioButtonsVPanel");
		selectSpecificUserPanel.addStyleName("SpecificUserVPanel");
		pickPeriod.addStyleName("PickPeriodVPanel");
		choosePeriodLabel.addStyleName("ChoosePeriodLabel");
		startEndHPanel.addStyleName("StartEndHPanel");
		periodShortcutsHor.addStyleName("Shortcuts");
		pickKindOfReport.addStyleName("KindOfReportVPanel");

		startEndHPanel.setHorizontalAlignment(ALIGN_CENTER);
		checkBoxContainer.addStyleName("CheckBoxContainerVPanel");
		getReportButton.setStyleName("GetReportButton");

//		User auswählen
		radioButtons.add(selectOneUserButton);
		radioButtons.add(selectSpecificUserButton);
		radioButtons.add(sSUSP);
//		radioButtons.add(selectSpecificUserPanel);
		radioButtons.add(selectAllUserButton);

		pickUser.add(chooseUser);
		pickUser.add(radioButtons);

//		Zeitraum auswählen
		pickPeriod.add(choosePeriodLabel);
		pickPeriod.add(startEndHPanel);

		startEndHPanel.add(startDateBox);
		startEndHPanel.add(bindestrichlabel);

		startEndHPanel.add(endDateBox);

		periodShortcutsHor.add(last3DaysButton);
		periodShortcutsHor.add(lastWeekButton);
		periodShortcutsHor.add(lastMonthButton);



		pickPeriod.add(periodShortcutsHor);

//		Art des Reports auswählen
		pickKindOfReport.add(kindOfReportLabel);
		pickKindOfReport.add(allReportButton);
		pickKindOfReport.add(specificReportButton);



		this.add(pickUser);
		this.add(pickPeriod);
		this.add(pickKindOfReport);
		this.add(getReportButton);


		editorAdministration.findAllUsers(new AllUsersCallback());

//		Methode implementieren die schaut ob sich was verändert hat
		Timer userRefresh = new Timer() {
			public void run() {
				editorAdministration.findAllUsers(new AllUsersCallback());
			}
		};
		userRefresh.scheduleRepeating(1000);

//		Festlegen des choosenUser-Vector
		selectOneUserButton.addClickHandler(new SelectUserGroupHandler(selectOneUserButton));
		selectSpecificUserButton.addClickHandler(new SelectUserGroupHandler(selectSpecificUserButton));
		selectAllUserButton.addClickHandler(new SelectUserGroupHandler(selectAllUserButton));
		
		today = new Date();
		today.setHours(1);
		today.setMinutes(0);
		today.setSeconds(0);



//		Festlegen der choosenPeriod
		DateTimeFormat dateFormat = DateTimeFormat.getLongDateFormat();
		startDateBox.setFormat(new DateBox.DefaultFormat(dateFormat));
		startDateBox.getDatePicker().setYearArrowsVisible(true);
		startDateBox.getDatePicker().setYearAndMonthDropdownVisible(true);
		startDateBox.getDatePicker().setVisibleYearCount(1);
		startDateBox.addValueChangeHandler(new StartDateChangeHandler());


		endDateBox.setFormat(new DateBox.DefaultFormat(dateFormat));
		endDateBox.getDatePicker().setYearArrowsVisible(true);
		endDateBox.getDatePicker().setYearAndMonthDropdownVisible(true);
		endDateBox.getDatePicker().setVisibleYearCount(10);
		endDateBox.addValueChangeHandler(new EndDateChangeHandler());
		
		Window.alert("firstPossibleDate");
		startDateBox.setValue(firstPossibleDate);
		endDateBox.setValue(today);
		Window.alert("today");

		lastWeekButton.addClickHandler(new ShortcutHandler(lastWeekButton));
		lastMonthButton.addClickHandler(new ShortcutHandler(lastMonthButton));
		last3DaysButton.addClickHandler(new ShortcutHandler(last3DaysButton));

//		Festlegen der Art des Reports
		allReportButton.addClickHandler(new SelectAllReportGroupsHandler(allReportButton));
		specificReportButton.addClickHandler(new SelectSpecificReportGroupHandler(specificReportButton));

		checkBoxContainer.add(subscriptionReportButton);
		checkBoxContainer.add(postReportButton);
		checkBoxContainer.add(commentReportButton);
		checkBoxContainer.add(likeReportButton);

		subscriptionReportButton.addClickHandler(new SelectSpecificReportGroupHandler(subscriptionReportButton));
		postReportButton.addClickHandler(new SelectSpecificReportGroupHandler(postReportButton));
		commentReportButton.addClickHandler(new SelectSpecificReportGroupHandler(commentReportButton));
		likeReportButton.addClickHandler(new SelectSpecificReportGroupHandler(likeReportButton));

//		Anfordern des Reports
		getReportButton.addClickHandler(new getReportClickHandler());


	}

	class AllUsersCallback implements AsyncCallback<Vector<User>> {

		public void onFailure(Throwable caught) {

		}

		public void onSuccess(Vector<User> result) {
			allUsers = result;

			if (allusersS.size() != result.size()) {
				selectSpecificUserPanel.clear();
				allusersS.clear();

				for (int u = 0; u < result.size(); u++) {
					allusersS.add(result.elementAt(u).getNickName());
					CheckBox tempCheckBox = new CheckBox(allusersS.elementAt(u));
					tempCheckBox.addClickHandler(new UserCheckBoxClickHandler(tempCheckBox));
					selectSpecificUserPanel.add(tempCheckBox);

				}


			}

		}

		

	}

	class SelectUserGroupHandler implements ClickHandler {
		RadioButton radioButton = null;

		public SelectUserGroupHandler(RadioButton rb) {
			this.radioButton = rb;
		}

		public void onClick(ClickEvent event) {
			if (this.radioButton == selectOneUserButton) {
				sSUSP.remove(selectSpecificUserPanel);

				choosenUsersS.clear();
				choosenUsersS.add(clientBoUser.getNickName());

			}

			if (this.radioButton == selectSpecificUserButton) {

				choosenUsersS.clear();
				sSUSP.add(selectSpecificUserPanel);
			}

			else if (this.radioButton == selectAllUserButton) {
				sSUSP.remove(selectSpecificUserPanel);

				choosenUsersS.clear();
				for (int i = 0; i < allUsers.size(); i++) {
					choosenUsersS.add(allUsers.elementAt(i).getNickName());
				}
			}

		}

	}

	class UserCheckBoxClickHandler implements ClickHandler {
		CheckBox checkBox = null;

		public UserCheckBoxClickHandler(CheckBox cB) {
			this.checkBox = cB;
		}

		public void onClick(ClickEvent event) {
			if (choosenUsersS.contains(checkBox.getText())) {

				for (int i = 0; i < choosenUsersS.size(); i++) {
					if (choosenUsersS.elementAt(i) == checkBox.getText()) {
						choosenUsersS.removeElementAt(i);
					}
				}

			}

			else if (choosenUsersS.contains(checkBox.getText()) == false) {
				choosenUsersS.add(checkBox.getText());
			}

		}

	}

	public class StartDateChangeHandler implements ValueChangeHandler<Date> {
		public StartDateChangeHandler() {

		}

		@Override
		public void onValueChange(ValueChangeEvent<Date> event) {

			
			Date daybeforetoday = today;
			CalendarUtil.addDaysToDate(daybeforetoday, -1);
			
			Date daybeforeenddate;
			
			daybeforeenddate = endDateBox.getValue();
			CalendarUtil.addDaysToDate(daybeforeenddate, -1);
			
//			if(endDateBox.getValue() != null) {
//			daybeforeenddate = endDateBox.getValue();
//			CalendarUtil.addDaysToDate(daybeforeenddate, -1);
//			} else {
//				daybeforeenddate = daybeforetoday;
//			}
			

			
			if (startDateBox.getValue().after(endDateBox.getValue())) {
				startDateBox.setValue(daybeforeenddate);
				Window.alert(
						"Das Startdatum muss mindestens einen Tag vor dem Enddatum liegen. Die Auswahl wurde entsprechend angepasst.");
				return;
			}



			if (startDateBox.getValue().after(today)) {

				startDateBox.setValue(daybeforetoday);
				Window.alert(
						"Das späteste mögliche Startdatum ist der gestrige Tag. Die Auswahl wurde entsprechend angepasst");
				return;
			}

			if (startDateBox.getValue().before(lastImpossibleDate)) {
				startDateBox.setValue(firstPossibleDate);
				Window.alert(
						"Das frühestmögliche Startdatum ist der 1. Januar 2019. Die Auswahl wurde entsprechend angepasst");
				return;
			}





		}
	}

	public class EndDateChangeHandler implements ValueChangeHandler<Date> {

		public EndDateChangeHandler() {

		}

		@Override
		public void onValueChange(ValueChangeEvent<Date> event) {

			boolean trigger = false;

			// OK
			if (endDateBox.getValue().after(today)) {
				endDateBox.setValue(today);

				Window.alert(
						"Das späteste mögliche Enddatum ist der heutige Tag. Die Auswahl wurde entsprechend angepasst.");
				return;
			}

			
			
			Date dateafterchosenstartDateCOPY = startDateBox.getValue();
			CalendarUtil.addDaysToDate(dateafterchosenstartDateCOPY, 1);
			
			
			if (endDateBox.getValue().before(dateafterchosenstartDateCOPY)) {
				endDateBox.setValue(dateafterchosenstartDateCOPY);

				Window.alert(
						"Das Enddatum muss hinter dem Startdatum liegen. Die Auswahl wurde entsprechend angepasst.");
				return;
			}

			if (endDateBox.getValue().before(secondPossibleDate)) {
				endDateBox.setValue(secondPossibleDate);

				Window.alert(
						"Das frühestmögliche Enddatum ist der 2. Januar 2019. Die Auswahl wurde entsprechend angepasst.");
				return;
			}


		}
	}

	public class ShortcutHandler implements ClickHandler {
		Button shortcutButton;

		public ShortcutHandler(Button sB) {
			this.shortcutButton = sB;
		}

		public void onClick(ClickEvent event) {
			Date today = new Date();
			today.setHours(1);
			today.setMinutes(0);
			today.setSeconds(0);

			if (this.shortcutButton == lastWeekButton) {
				Date weekAgo = new Date();
				weekAgo.setHours(1);
				weekAgo.setMinutes(0);
				weekAgo.setSeconds(0);
				CalendarUtil.addDaysToDate(weekAgo, -7);

				if (weekAgo.before(lastImpossibleDate)) {
					weekAgo = new Date(119, 0, 1);
					Window.alert(
							"Das frühestmögliche Startdatum ist der 1. Januar 2019. Die Auswahl wurde entsprechend angepasst.");
				}

				startDateBox.setValue(weekAgo);

				endDateBox.setValue(today);


			}

			if (this.shortcutButton == lastMonthButton) {
				Date monthAgo = new Date();
				monthAgo.setHours(1);
				monthAgo.setMinutes(0);
				monthAgo.setSeconds(0);
				CalendarUtil.addMonthsToDate(monthAgo, -1);

				if (monthAgo.before(lastImpossibleDate)) {
					monthAgo = new Date(119, 0, 1);
					Window.alert(
							"Das frühestmögliche Startdatum ist der 1. Januar 2019. Die Auswahl wurde entsprechend angepasst");
				}

				startDateBox.setValue(monthAgo);

				endDateBox.setValue(today);
			}

			if (this.shortcutButton == last3DaysButton) {
				Date yearAgo = new Date();
				yearAgo.setHours(1);
				yearAgo.setMinutes(0);
				yearAgo.setSeconds(0);
				CalendarUtil.addDaysToDate(yearAgo, -3);

				if (yearAgo.before(lastImpossibleDate)) {
					yearAgo = new Date(119, 0, 1);
					Window.alert(
							"Das frühestmögliche Startdatum ist der 1. Januar 2019. Die Auswahl wurde entsprechend angepasst");
				}

				startDateBox.setValue(yearAgo);

				endDateBox.setValue(today);
			}

		}

	}

	public class SelectAllReportGroupsHandler implements ClickHandler {
		RadioButton radioButton = null;

		public SelectAllReportGroupsHandler(RadioButton rB) {
			this.radioButton = rB;
		}

		public void onClick(ClickEvent event) {
			pickKindOfReport.remove(checkBoxContainer);

			choosenReportsS.clear();
			SubReport sR = new SubReport();
			choosenReportsS.add(sR);
			choosenReportsS.add(new PostReport());
			choosenReportsS.add(new CommentReport());
			choosenReportsS.add(new LikeReport());
		}
	}

	public class SelectSpecificReportGroupHandler implements ClickHandler {
		RadioButton radioButton = null;
		CheckBox checkBox = null;

		public SelectSpecificReportGroupHandler(RadioButton rB) {
			this.radioButton = rB;
		}

		public SelectSpecificReportGroupHandler(CheckBox cB) {
			this.checkBox = cB;
		}

		public void onClick(ClickEvent event) {
			if (this.radioButton != null && this.checkBox == null) {
				choosenReportsS.clear();

				subscriptionReportButton.setChecked(false);
				postReportButton.setChecked(false);
				commentReportButton.setChecked(false);
				likeReportButton.setChecked(false);

				pickKindOfReport.add(checkBoxContainer);
			}

			if (this.checkBox != null) {

				if (this.checkBox == subscriptionReportButton) {
					Boolean isReportRemoved = false;
					for (int i = 0; i < choosenReportsS.size(); i++) {
						if (choosenReportsS.elementAt(i).getClass() == new SubReport().getClass()) {
							choosenReportsS.remove(i);
							isReportRemoved = true;
						}
					}
					if (isReportRemoved == false) {
						choosenReportsS.add(new SubReport());
					}
				}

				if (this.checkBox == postReportButton) {
					Boolean isReportRemoved = false;
					for (int i = 0; i < choosenReportsS.size(); i++) {
						if (choosenReportsS.elementAt(i).getClass() == new PostReport().getClass()) {
							choosenReportsS.remove(i);
							isReportRemoved = true;
						}
					}
					if (isReportRemoved == false) {
						choosenReportsS.add(new PostReport());
					}
				}

				if (this.checkBox == commentReportButton) {
					Boolean isReportRemoved = false;
					for (int i = 0; i < choosenReportsS.size(); i++) {
						if (choosenReportsS.elementAt(i).getClass() == new CommentReport().getClass()) {
							choosenReportsS.remove(i);
							isReportRemoved = true;
						}
					}
					if (isReportRemoved == false) {
						choosenReportsS.add(new CommentReport());
					}
				}

				if (this.checkBox == likeReportButton) {
					Boolean isReportRemoved = false;
					for (int i = 0; i < choosenReportsS.size(); i++) {
						if (choosenReportsS.elementAt(i).getClass() == new LikeReport().getClass()) {
							choosenReportsS.remove(i);
							isReportRemoved = true;
						}
					}
					if (isReportRemoved == false) {
						choosenReportsS.add(new LikeReport());
					}
				}

			}



		}
	}

	public class getReportClickHandler implements ClickHandler {
		public void onClick(ClickEvent event) {


			choosenStartDate = startDateBox.getValue();
			choosenStartDate.setHours(1);

			choosenEndDate = endDateBox.getValue();
			choosenEndDate.setHours(1);

			if (choosenUsersS == null || choosenStartDate == null || choosenEndDate == null
					|| choosenReportsS == null) {
				Window.alert("Bitte füllen Sie alle Felder aus.");
				return;
			}

			if (choosenUsersS.size() == 0 || choosenStartDate == null || choosenEndDate == null
					|| choosenReportsS.size() == 0) {
				Window.alert("Bitte füllen Sie alle Felder aus.");
				return;
			}



			if (choosenStartDate.equals(choosenEndDate)) {
				Window.alert("Das Startdatum darf nicht dem Enddatum entsprechen.");
				return;
			}

			else if (choosenUsersS.size() != 0 && choosenStartDate != null && choosenEndDate != null
					&& choosenReportsS.size() != 0) {

				Timestamp choosenStartDateTS = new Timestamp(choosenStartDate.getTime());
				Timestamp choosenEndDateTS = new Timestamp(choosenEndDate.getTime());

				Date choosenStartDatePl1 = choosenStartDate;
				CalendarUtil.addDaysToDate(choosenStartDatePl1, 1);
				Timestamp choosenStartDatePl1TS = new Timestamp(choosenStartDatePl1.getDate());

				Date choosenEndDatePl1 = choosenEndDate;
				CalendarUtil.addDaysToDate(choosenEndDatePl1, 1);
				Timestamp choosenEndDatePl1TS = new Timestamp(choosenEndDatePl1.getDate());

				reportAdministration.getReport(choosenUsersS, choosenStartDateTS, choosenEndDateTS,
						choosenStartDatePl1TS, choosenEndDatePl1TS, choosenReportsS, clientBoUser,
						new DisplayReportCallback());

			}

		}

	}



	class DisplayReportCallback implements AsyncCallback<CompositeReport> {

		public void onFailure(Throwable caught) {
			if (caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}

		}

		public void onSuccess(CompositeReport result) {

			HTMLReportWriter htmlWriter = new HTMLReportWriter();
			htmlWriter.process(result);


			HTML html = new HTML(htmlWriter.getReportText());
			clientReportForm.setReport(html);
		}

	}

}
