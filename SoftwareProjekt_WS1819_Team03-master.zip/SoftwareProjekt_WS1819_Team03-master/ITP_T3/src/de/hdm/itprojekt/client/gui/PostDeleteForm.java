package de.hdm.itprojekt.client.gui;

import com.google.gwt.event.dom.client.ClickEvent;


import com.google.gwt.event.dom.client.ClickHandler;
import com.google.gwt.user.client.Window;
import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.Button;
import com.google.gwt.user.client.ui.DialogBox;
import com.google.gwt.user.client.ui.HorizontalPanel;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.VerticalPanel;

import de.hdm.itprojekt.client.ClientSideSettings;
import de.hdm.itprojekt.client.gui.CommentDeleteForm.ConfirmDeleteCommentClickHandler;
import de.hdm.itprojekt.client.gui.CommentDeleteForm.DeleteCallBack;
import de.hdm.itprojekt.client.gui.CommentDeleteForm.DenialDeleteCommentClickHandler;
import de.hdm.itprojekt.shared.EditorAdministrationAsync;
import de.hdm.itprojekt.shared.NotLoggedInException;
import de.hdm.itprojekt.shared.bo.Comment;
import de.hdm.itprojekt.shared.bo.Post;


/**
 * 
 * @author SimonJanik
 * Diese Klasse enthält alle grafischen Elemente zum Löschen eines Posts
 */

public class PostDeleteForm extends DialogBox {
	
	Post post = null;
	PostForm postForm = null;
	PinboardForm pinboardForm;
	EditorAdministrationAsync editorAdministration = ClientSideSettings.getEditorAdministration();

	Label askText = new Label("Möchtest du deinen Beitrag wirklich löschen?");
	Button positiveButton = new Button("Ja");
	Button negativeButton = new Button("Nein");
	HorizontalPanel horizont = new HorizontalPanel();
	VerticalPanel vertical = new VerticalPanel();
	
	
	/**
	 * Konstruktor der PostDeleteForm
	 * @param p ist der zu-löschende Post
	 * @param pf ist die PostForm des zu-löschenden Posts
	 * @param pinf ist die Pinboard, auf der der Post angezeigt wird
	 */
	public PostDeleteForm(Post p, PostForm pf, PinboardForm pinf) {
		this.post = p;
		this.postForm = pf;
		this.pinboardForm = pinf;
		
	}
	
	/*
	 * onLoad-Methode: Wird ausgeführt, wenn das Panel, dem Browser hinzugefügt wurde. 
	 * Die dieser Klasse dazugehörigen grafischen Elemente werden dem Panel hinzugefügt.
	 * Den Buttons werden deren Funktion entsprechend ClickHandler zugewiesen. 
	 */
	public void onLoad() {
	super.onLoad();	
	vertical.add(askText);
	horizont.add(positiveButton);
	horizont.add(negativeButton);
	negativeButton.addClickHandler(new DenialDeleteCommentClickHandler());
	positiveButton.addClickHandler(new ConfirmDeletePostClickHandler(this.post,this.postForm, this));
	vertical.add(horizont);
	this.add(vertical);
	
	
	}
	
	/**
	 * <code> ConfirmDeletePostClickHandler </code>: ClickEvent wird beim Click auf den <code> positiveButton </code> ausgelöst.
	 * Der User bestätigt damit, dass der Post gelöscht werden soll.
	 *
	 */
	class ConfirmDeletePostClickHandler implements ClickHandler{
		
		private Post post = null;
		private PostForm postForm = null;
		private PostDeleteForm postDeleteForm = null;
		
		private ConfirmDeletePostClickHandler(Post p, PostForm pf, PostDeleteForm pdf) {
			this.post = p;
			this.postForm = pf;
			this.postDeleteForm = pdf;
		}
		@Override
		public void onClick(ClickEvent event) {
			// TODO Auto-generated method stub
			editorAdministration.deletePost(post.getId(),new DeleteCallBack(postDeleteForm,post));	
		}
			
	}
	
	/**
	 * <code> DenialDeleteCommentClickHandler </code>: ClickEvent wird beim Click auf den <code> negativeButton </code> ausgelöst.
	 * Der User bestätigt damit, dass der Post nicht gelöscht werden soll. Anschließend wird die <code> PostDeleteForm </code> 
	 * geschlossen.
	 *
	 */
	class DenialDeleteCommentClickHandler implements ClickHandler{
		@Override
		public void onClick(ClickEvent event) {
			closePostDeleteForm();
		}
		
	}
	
	//Callbacks
	
	/**
	 * CallBack des Clickhandlers <code> ConfirmDeletePostClickHandler </code>
	 * Bei erfolgreichem Rückruf (onSucess) wird der Post von dessen zugehörigen <code> pinboardForm</code> entfernt, dessen
	 * <code>postForm</code> und die <code> PostDeleteForm</code> werden geschlossen.
	 */
	class DeleteCallBack implements AsyncCallback<Void>{
		
		private PostDeleteForm postDeleteAsk = null;
		private Post post;
		
		private DeleteCallBack(PostDeleteForm post, Post p) {
			// TODO Auto-generated constructor stub
			this.postDeleteAsk = post;
			this.post = p;
		}
		

		@Override
		public void onFailure(Throwable caught) {
			// TODO Auto-generated method stub
			if(caught instanceof NotLoggedInException) {
				Window.Location.reload();
			}
		}

		@Override
		public void onSuccess(Void result) {
			// TODO Auto-generated method stub
			pinboardForm.removePostFromPinboard(post);
			postForm.closePostForm();
			closePostDeleteForm();
	
		}
		
	}
	
	//Zum Schließen dieser DialogBox
	public void closePostDeleteForm() {
		this.hide();
		this.clear();
		this.removeFromParent();
		this.setAnimationEnabled(false);
		this.setGlassEnabled(false);
	}
	
	//Zum Öffnen dieser DialogBox
	public void openPostDeleteForm() {
		this.setGlassEnabled(true);
		this.setAnimationEnabled(true);
		this.center();
		this.show();
	}
	

}
