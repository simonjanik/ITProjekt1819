package de.hdm.itprojekt.shared;

import com.google.gwt.user.client.rpc.AsyncCallback;

import de.hdm.itprojekt.server.LoginAdministrationImpl;
import de.hdm.itprojekt.shared.bo.User;

public interface LoginAdministrationAsync {
	
	void init(AsyncCallback<Void> callback);
	
	void login(String requestURI, AsyncCallback<User> callback);

	void registerUser(User clientBoUser, AsyncCallback<User> callback);
	void checkUserKnown(User clientBoUser, AsyncCallback<User> callback);
}
