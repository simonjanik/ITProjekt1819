package de.hdm.itprojekt.shared.report;

import java.io.Serializable;

public abstract class Report implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Diese Klasse definiert die Basis aller Reports.
	 * Alle (Sub)-Reports m�ssen, wie diese, Serialisierbar sein, um mittels GWT-RPC transferiert werden zu k�nnen.
	 * (Vom Server an den Client geschickt werden k�nnen)
	 * 
	 */
	
	
	/**
	 * Jeder Report beinhaltet, von welchem Nutzer (Nutzername) der Report ist 
	 * und f�r welchen Zeitraum dieser ist.
	 * diese Daten befinden sich in headerData.
	 */
	private CompositeParagraph headerData = null;
	
	/**
	 * Integer ist ein Objekt. Dadurch, dass es ein Objekt ist, k�nnen Methoden auf dieses Objekt
	 * aufgerufen werden. Dies ist hilfreich f�r beispielsweise die .toString Methode.
	 */


	public void setHeaderData(CompositeParagraph p) 
	{
		this.headerData = p;
	}

	public CompositeParagraph getHeaderData()
	{
		return this.headerData;
	}
	

	

}
