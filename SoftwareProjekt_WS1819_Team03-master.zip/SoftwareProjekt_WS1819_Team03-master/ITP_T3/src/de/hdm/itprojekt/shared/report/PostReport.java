package de.hdm.itprojekt.shared.report;

public class PostReport extends SimpleReport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Diese Klasse wird sämtliche Infos über Subs eines Nutzers in einem Report bereitstellen.
	 */

}