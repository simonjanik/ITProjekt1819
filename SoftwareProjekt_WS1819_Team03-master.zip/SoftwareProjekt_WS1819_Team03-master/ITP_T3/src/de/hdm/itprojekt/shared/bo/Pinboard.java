package de.hdm.itprojekt.shared.bo;

import java.sql.Timestamp;

public class Pinboard extends BusinessObject {
	
	private static final long serialversionUID = 1l;
	
	private int userID;
	
	public Pinboard() {
		// TODO Auto-generated constructor stub
	}
	
	public Pinboard(int userid) {
		this.userID = userid;
	}
	
	/**
	 * Konstruktor um eine Vollständige Pinboard Instanz zu erstellen
	 * @param id ist die PinboardID
	 * @param date ist das Erstellungsdatum der Pinboard
	 * @param userid ist der User, dem das Pinboard zugeordnet ist.
	 */
	public Pinboard(int id, Timestamp date ,int userid) {
		super(id, date);
		
		this.userID = userid;
	}


	public int getUserID() {
		return userID;
	}

	public void setUserID(int userID) {
		this.userID = userID;
	}


	
	

}
