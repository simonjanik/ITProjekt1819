package de.hdm.itprojekt.shared.bo;

import java.sql.Timestamp;

public class Sub extends BusinessObject {

	private static final long serialversionUID = 1l;

	private int userID;
	private int pinboardID;
	private String subscribedUserNickName;

	public Sub() {
		// TODO Auto-generated constructor stub
	}

	public Sub(int userid, int pinid) {
		this.userID = userid;
		this.pinboardID = pinid;
	}
	
	public Sub(int userid, String nick) {
		this.userID = userid;
		this.subscribedUserNickName = nick;
	}
	
	public Sub(int id, Timestamp date, int userid, int pinid) {
		super(id, date);

		this.userID = userid;
		this.pinboardID = pinid;
	}
	
	public Sub(int id, Timestamp date, int userid, int pinid,Timestamp deleteDate) {
		super(id, date, deleteDate);
		this.userID = userid;
		this.pinboardID = pinid;
	}

	public int getUserID() {
		return userID;
	}

	public int getPinboardID() {
		return pinboardID;
	}
	
	public String getSubscribedUserNickName() {
		return subscribedUserNickName;
	}

	public void setSubscribedUserNickName(String subscribedUserNickName) {
		this.subscribedUserNickName = subscribedUserNickName;
	}

}
