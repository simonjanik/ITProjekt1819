package de.hdm.itprojekt.shared.report;

import java.util.ArrayList;

public class CompositeParagraph extends Paragraph{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Ein <code>CompositeParagraph</code>-Objekt besteht aus mehreren 
	 * <code>SimpleParagraph</code>-Objekten, welche in einer ArrayList gespeichert sind.
	 * Diese Klasse stellt somit eine Menge einzelner Abs�tze dar.
	 */
	
	/**
	 * ArrayList um die einzelnen <code>SimpleParagraph</code>-Objekte zu speichern.
	 */
	private ArrayList<SimpleParagraph> simpleParas = new ArrayList<SimpleParagraph>();
	
 /**
  * Methode um ein <code>SimpleParagraph</code>-Objekt zu einem <code>CompositeParagraph</code>
  * hinzuzuf�gen. 
  * @param sp als SimpleParagraph-Objekt
  */
	public void addSimpleParagraph(SimpleParagraph sp)
	{
		this.simpleParas.add(sp);
	}
	
	/**
	 * Methode um ein <code>SimpleParagraph</code>-Objekt aus einem <code>CompositeParagraph</code>
	 * zu entfernen.
	 */
	public void deleteSimpleParagraph(SimpleParagraph sp)
	{
		this.simpleParas.remove(sp);
	}
	
	/**
	 * Methode um alle SimpleParagraph-Objekte des CompositeParagraphs auszugeben.
	 * Es werden also alle "Unterabschnitte" hier ausgegeben.
	 * @return ArrayList mit allen (Sub)SimpleParagraphs
	 */
	public ArrayList<SimpleParagraph> getAllSimpleParagraphs ()
	{
		return this.simpleParas;	
	}
	
	/**
	 * Auslesen eines einzelnen Unterabschnitts von einem <code>CompositeParagraph</code>-Objekt
	 * @param i ist der index des auszulesenden Abschnitts, wobei 0 <= i <= n und n = Anzahl der Unterabschnitte.
	 * @return das <code>SimpleParagraph</code>-Objekt and der stelle i
	 */
	public SimpleParagraph getElementAt(int i)
	{
		return this.simpleParas.get(i);
	}
	
	public String toString()
	{
		/**
		 * StringBuffer anlegen, in den nach und nach die einzelnen Abschnitte eingelesen werden.
		 */
		StringBuffer result = new StringBuffer();
		
		/**
		 * Schleife, die die ArrayList durchl�uft und jedes Element als String zu dem Stringbuffer hinzuf�gt, 
		 * gefolgt von /n um dem Umbruch zwischen den Abschnitten darzustellen.
		 */
		for(int i=0; i<simpleParas.size(); i++)
		{
			SimpleParagraph sp = this.simpleParas.get(i);
			result.append(sp.toString() + "/n");
		}
		
		/**
		 * R�ckgabe des StringBuffers als Ergebnis des <code>CompositeParagraph</code>-Objekts als einen String.
		 */
		return result.toString();
		
	}
	
	public int getNumberOfParagraphs()
	{
		return this.simpleParas.size();
	}
	
	public ArrayList<SimpleParagraph> getHeaderData(){
		return simpleParas;
	}

}
