package de.hdm.itprojekt.shared.bo;

import java.sql.Timestamp;

public class Post extends BusinessObject {

	private static final long serialversionUID = 1l;

	private String text;
	private int pinboardID;
	private String authorNickName;

	public Post() {
		// TODO Auto-generated constructor stub
	}

	public Post(int id, Timestamp date, String text, int pinId) {
		super(id, date);

		this.text = text;
		this.pinboardID = pinId;
	}
	
	public Post(int id, Timestamp date, Timestamp deletionDate, String text, int pinId) {
		super(id, date, deletionDate);

		this.text = text;
		this.pinboardID = pinId;
	}
	
	public Post(String text, int pinId) {
		this.text = text;
		this.pinboardID = pinId;
		
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getPinboardID() {
		return pinboardID;
	}
	
	public String getAuthorNickName() {
		return authorNickName;
	}
	
	public void setAuthorNickName(String aNN) {
		this.authorNickName=aNN;
	}

}
