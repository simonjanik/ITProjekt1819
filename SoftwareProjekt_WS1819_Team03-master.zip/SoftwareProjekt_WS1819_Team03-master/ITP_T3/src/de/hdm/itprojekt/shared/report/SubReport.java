package de.hdm.itprojekt.shared.report;

public class SubReport extends SimpleReport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Diese Klasse wird sämtliche Infos über Subs eines Nutzers in einem Report bereitstellen.
	 */

}