package de.hdm.itprojekt.shared.report;

import java.util.ArrayList;

public class PlainTextWriter {
	
	/**
	 * Plain Text bedeutet, kann der Text keine Formatierung besitzt.
	 * Der Text wird also nicht bold, italic oder sonst wie gesetzt.
	 * Der Text wird in einem String gespeichert und kann mit getReportText() ausgelesen werden.
	 */

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * String um den Text zu spichern.
	 */
	private String reportText = "";

	/**
	 * Methode um die Variable ReportText zur�ckzusetzen.
	 */
	public void resetReportText()
	{
		this.reportText = "";
	}
	
	/**
	 * Verarbeitet ein <code>Simple-Report</code> Objekt zu einem String
	 * @param sr ist das <code>SimpleReport</code>-Objekt, das zu einem String verarbeitet werden soll.
	 */
	private void simpleReportProcess(SimpleReport sr)
	{
		//Erst sicherstellen, dass wir mit einem leeren String beginnen
		this.resetReportText();
		
		/**
		 * StringBuffer um das Ergebnis darin zu speichern.
		 */
		StringBuffer result = new StringBuffer();

		
		/**
		 * ArrayList, die alle Reihen beinhaltet, die das <code>SimpleReport</code>-Objekt
		 * auch beinhalten.
		 */
		ArrayList<Row> allRows = sr.getRows();
		
		/**
		 * F�r jede Reihe in der Liste allRows soll:
		 * i erh�ht werden und zwar liegt i immer zwischen 0 und der Anzahl der Spalten in dieser Reihe
		 * und in jeder Iteration wird der Inhalt der sich in der Spalte i befindet, f�r die Zeile, die gerade verarbeitet wird
		 * an den StringBuffer namens result angeh�ngt.
		 * Zwischen den Spalten werden dann zwei Tabulatoren gesetzt, um diese zu trennen.
		 * see @Row, die Methode getColumnAt gibt das Element zur�ck, das sich darin befindet.
		 */
		for(Row rowToAppend : allRows)
		{
			for ( int i = 0 ; i < rowToAppend.getNumberOfColumns() ; i++ )
			{
				result.append(rowToAppend.getColumnAt(i) + "/t ; /t");
			}
			//Nach jeder abgearbeiteten Zeile erfolgt ein Umbruch
			result.append("/n");
		}
		
		//Nun wird das Ergebnis als String in der Variable reportText gespeichert.
		this.reportText = result.toString();
		
	}
	
//	Glaube ich unn�tig, w�re nur notwendig wenn weitere Elemente hinzugef�gt werden m�ssten wie etwa ein Impressum oder so
	public String getReportText()
	{
		return this.reportText.toString();
	}
	
	
	public void compositeReportProcess(CompositeReport cr) 
	{		
		
		//Variable leeren.
		this.resetReportText();
		
		//StringBuffer, in den das Ergebnis der Verarbeitung gespeichert wird.
		StringBuffer result = new StringBuffer();
		
		/**
		 * F�r jedes i, wobei i zwischen 0 und der Anzahl aller SimpleReports in dem CompositeReport ist, wird f�r jedes i:
		 * Ein String erstellt
		 * Der SimpleReport an der Stelle i wird prozessiert und dabei wird das Ergebnis des Prozesses immer als String in
		 * die Variable ReportText gespeichert.
		 * Das Ergebnis (also der Wert der zu dieser Zeit in reportText steckt) wird an den StringBuffer geh�ngt mit einem 
		 * anschlie�enden doppeltem Umbruch.
		 */
		for ( int i = 0; i < cr.getNumberOfSimpleReports(); i++ )
		{
			simpleReportProcess(cr.getElementAt(i));
			
			// Dann auch unn�tig, siehe Zeile 80
			// String test = new String();
			// test = this.getReportText();
			
			result.append(reportText + "/n ; /n");
			
			// Um sicherzustellen, dass die Variable geleert wird nach jedem durchlauf
			this.resetReportText();
		}
				
	}



	
	

}