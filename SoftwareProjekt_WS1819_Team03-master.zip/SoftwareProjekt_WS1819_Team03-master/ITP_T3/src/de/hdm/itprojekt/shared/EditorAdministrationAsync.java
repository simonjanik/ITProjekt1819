package de.hdm.itprojekt.shared;

import java.util.Vector;

import com.google.gwt.user.client.rpc.AsyncCallback;

import de.hdm.itprojekt.shared.bo.*;

public interface EditorAdministrationAsync {

	void init(AsyncCallback<Void> callback);

	
	//Like
	void addLike(Like like, AsyncCallback<Like> callback);
	void deleteLike(int likeID, AsyncCallback<Void> callback);
	void findAllLikesByPost(int postid, AsyncCallback<Vector<Like>> callback);

	//Comment
	void addComment(Comment comment, AsyncCallback<Comment> callback);
	void updateComment(Comment c, AsyncCallback<Comment> callback);
	void deleteComment(int commentID, AsyncCallback<Void> callback);
	void findCommentsByPost(int postID, AsyncCallback<Vector<Comment>> callback);

	void addPostToPinboard(Post post, AsyncCallback<Post> callback);
	void deletePost(int postID, AsyncCallback<Void> callback);
	void updatePost(Post p, AsyncCallback<Post> callback);
	void findPostsByPinboard(int pinboardID, AsyncCallback<Vector<Post>> callback);

	//Sub
	void addSub(Sub sub, AsyncCallback<Sub> callback);
	void deleteSub(int subID, AsyncCallback<Void> callback);
	void findSubsByUser(int userID, AsyncCallback<Vector<Sub>> callback);

	//User
	void addUser(User user, AsyncCallback<User> callback);
	void deleteUser(int userID, AsyncCallback<Void> callback);
	void updateUser(User updatedUser, AsyncCallback<User> callback);
	void findAllUserNickNames(AsyncCallback<Vector<String>> callback);
	void findUserByPinboardID(int pinId, AsyncCallback<User> callback);
	void findUserByID(int ID, AsyncCallback<User> callback);
	void findAllUsers(AsyncCallback<Vector<User>> callback);
	void findUserByNickname(String nn, AsyncCallback<User> callback);

	//Pinboard
//	void addPinboard(Pinboard pinbord, AsyncCallback<Void> callback);
	void deletePinboard(int pinboardID, AsyncCallback<Void> callback);








	void findPinboardIDByUserID(int userid, AsyncCallback<Integer> callback);


	void getPostForNewsFeed(User u, AsyncCallback<Vector<Post>> callback);


	void verifyField(String[] arr, AsyncCallback<String[]> callback);


	void findByEmail(User u, AsyncCallback<User> callback);


	




	

	
}
