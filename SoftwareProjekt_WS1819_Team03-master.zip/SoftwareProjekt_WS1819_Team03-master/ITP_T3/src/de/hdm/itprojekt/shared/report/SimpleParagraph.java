package de.hdm.itprojekt.shared.report;

import java.io.Serializable;

public class SimpleParagraph extends Paragraph implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/**
	 * Stellt einzelne Abs�tze in Form eines Strings dar.
	 */
	
	String text = "";
	
	/**
	 * Konstruktor zum setzen des Inhalts in einen String
	 */
	public SimpleParagraph (String s)
	{
		this.text = s;
	}
	
	/**
	 * Leerer Konstruktor
	 * Da Klassen, die mit GWT-RPC transportiert werden einen No-Argument-Konstruktor 
	 * besitzen m�ssen und wir den Default No-Argument-Konstruktor mit dem oberen 
	 * �berschrieben haben, muss zus�tzlich ein No-Argument-Konstruktor implementiert werden.
	 */
	public SimpleParagraph()
	{
		//No-Argument
	}

	/**
	 * Auslesen des Inhalts
	 * @return Inhalt als String
	 */
	public String getValue() {
		return this.text;
	}

	
	/**
	 * Setzen bzw. �berschreiben des Inhalts
	 * @param s als neuer Inhalt des Absatzes
	 */
	public void setValue(String s) {
		this.text = s;
	}
	
	/**
	 * Umwandeln des <code>SimpleParagraph</code>-Objekts in einen String
	 */
	public String toString()
	{
		return this.text;
	}
	
	
}
