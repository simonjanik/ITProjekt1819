package de.hdm.itprojekt.shared.report;

import java.io.Serializable;
import java.util.ArrayList;

public class Row implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Ein <Row>-Objekt muss Serialisierbar sein, um mittels GWT-RPC transferierbar zu sein.
	 * Ein <code>Row</code>-Objekt stellt eine Zeile eines <code>SimpleReport</code>-Objekts dar.
	 * Es besteht aus einer ArrayList von <code>Column</code> Objekten, 
	 * da eine Zeile nur mit min. einer Spalte bestehen kann.
	 * @see Column
	 */
	
	private ArrayList<Column> columns = new ArrayList<Column>();
	
	/**
	 * Hinzuf�gen einer Spalte (<code>Column</code>) zur Spalten-Liste (columns ArrayList)  
	 * @param c als Spalte, die hinzugef�gt wird.
	 */
	public void addColumn(Column c)
	{
		this.columns.add(c);
	}
	
	/**
	 * Entfernen einer bereits vorhandenen, benannten Spalte.
	 * @param c ist das zu entfernende Element
	 */
	public void deleteColumn(Column c)
	{
		this.columns.remove(c);
	}
	

	/**
	 * Auslesen eines einzelnen <code>Column</code>-Objekts
	 * @param i ist der Index der auszulesenden Spalte, wobei 0 <= i <= n mit n=Anzahl aller Spalten
	 * @return das gew�nschte Spalten-Objekt
	 */
	public Column getColumnAt(int i)
	{
		return this.columns.get(i);
		
	}
	
	public int getNumberOfColumns()
	{
		return this.columns.size();
	}
	
	

}
