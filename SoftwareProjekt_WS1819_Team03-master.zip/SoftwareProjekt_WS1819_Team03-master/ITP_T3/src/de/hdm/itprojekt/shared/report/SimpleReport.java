package de.hdm.itprojekt.shared.report;

import java.util.ArrayList;

public class SimpleReport extends Report {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Ein <code>SimpleReport</code>-Objekt stellt einen einzelnen Report dar,
	 * der zus�tzlich zu den Informationen aus der Superklasse Report auch Daten
	 * in Form einer Tabelle aufweist.
	 * Die Tabelle besteht aus Zeilen (see @Row) und Spalten (see @Column) und greift hierf�r
	 * auf die Klassen <code>Row</code> und <code>Column</code> zur�ck.
	 * 
	 * Die Tabelle wird Zeilenweise von Links nach Rechts ausgef�llt.
	 * 
	 */
	
	/**
	 * Eine ArrayList, in der die Zeilen gespeichert werden. 
	 * Eine Zeile besteht aus Spalten, somit sind beide Dimensionen einer Tabelle abgedeckt. (see @Row)
	 * Diese ArrayList stellt somit die Tabelle dar.
	 */
	private ArrayList<Row> table = new ArrayList<Row>();
	
	
	/**
	 * Hinzuf�gen einer Zeile zu der Tabelle
	 * @param r als Zeile, die Hinzugef�gt werden soll.
	 */
	public void addRow(Row r)
	{
		this.table.add(r);
	}
	
	/**
	 * Eine Zeile aus der Tabelle l�schen.
	 * @param r als Zeile, die gel�scht werden soll.
	 */
	public void deleteRow(Row r)
	{
		this.table.remove(r);
	}
	
	/**
	 * Auslesen aller Zeilen der Tabelle
	 * @return
	 */
	public ArrayList<Row> getRows()
	{
		return this.table;
	}

}
