package de.hdm.itprojekt.shared.report;

public class ReportHeader extends SimpleReport{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
