package de.hdm.itprojekt.shared.bo;

import java.sql.Timestamp;

public class Like extends BusinessObject {

	private static final long serialversionUID = 1l;

	private int postID;
	private int userID;
	private String likerNickName;

	public Like() {
		// TODO Auto-generated constructor stub
	}

//	Konstruktor für Objekt zu Tupel
//	In DB wird likerNickName nicht abgespeichert um Redundanzen zu verhindern.
	public Like(int id, Timestamp date, int postid, int userid) {
		super(id, date);

		this.postID = postid;
		this.userID = userid;
	}
	
	
	public Like(int id, Timestamp date, Timestamp deletionDate, int postid, int userid) {
		super(id, date, deletionDate);

		this.postID = postid;
		this.userID = userid;
	}
	
//	Konstruktor für Tupel zu Objekt
	public Like(int id, Timestamp date, int postid, int userid, String lNN) {
		super(id, date);

		this.postID = postid;
		this.userID = userid;
		this.likerNickName= lNN;
	}
	
	public Like(int postid,int userid) {
		this.postID = postid;
		this.userID = userid;
	}

	public int getPostID() {
		return postID;
	}

	public int getUserID() {
		return userID;
	}
	
	public String getLikerNickName() {
		return likerNickName;
	}
	
//	Evtl. nötig falls NickName während Session angepasst wird und gleichzeitig im Client angezeigt wird.
	public void setLikerNickName(String lNN) {
		this.likerNickName=lNN;
	}

}
