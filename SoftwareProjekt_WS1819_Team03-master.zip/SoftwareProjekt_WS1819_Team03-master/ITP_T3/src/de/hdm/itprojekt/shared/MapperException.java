package de.hdm.itprojekt.shared;

import java.io.Serializable;

public class MapperException extends Exception implements Serializable {

	public MapperException(Exception e) {
		// TODO Auto-generated constructor stub
		super("Es gab ein Fehler in der DatenBank: \n"+e.getMessage());
	}
	public MapperException() {
		
	}
	

}
