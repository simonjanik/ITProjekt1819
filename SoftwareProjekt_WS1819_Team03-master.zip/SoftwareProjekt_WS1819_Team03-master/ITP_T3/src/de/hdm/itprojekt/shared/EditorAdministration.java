package de.hdm.itprojekt.shared;

import java.util.Vector;

import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;

import de.hdm.itprojekt.shared.bo.*;



@RemoteServiceRelativePath("editor")
public interface EditorAdministration extends RemoteService {

	void init();
	
	//Like
	Like addLike(Like like) throws MapperException, NotLoggedInException;
	void deleteLike(int likeID) throws MapperException, NotLoggedInException;
	Vector<Like> findAllLikesByPost(int postid) throws MapperException, NotLoggedInException;
	
	//Comment
	Comment addComment(Comment comment)throws MapperException, NotLoggedInException;
	void deleteComment(int commentID)throws MapperException, NotLoggedInException;
	Comment updateComment(Comment c)throws MapperException, NotLoggedInException;
	Vector<Comment> findCommentsByPost(int postID)throws MapperException, NotLoggedInException;
	
	//Post 
	Post addPostToPinboard(Post post)throws MapperException, NotLoggedInException;
	void deletePost(int postID)throws MapperException, NotLoggedInException;
	Post updatePost(Post p)throws MapperException, NotLoggedInException;
	Vector<Post> findPostsByPinboard(int pinboardID)throws MapperException, NotLoggedInException;
	
	//Sub
	Sub addSub(Sub sub)throws MapperException, NotLoggedInException;
	void deleteSub(int subID)throws MapperException, NotLoggedInException;
	Vector<Sub> findSubsByUser(int userID)throws MapperException, NotLoggedInException;
	
	//User
	User addUser(User user)throws MapperException, NotLoggedInException;
	void deleteUser(int userID)throws MapperException, NotLoggedInException;
	User updateUser(User updatedUser)throws MapperException, NotLoggedInException;
	Vector<String> findAllUserNickNames()throws MapperException, NotLoggedInException;
	User findUserByPinboardID(int pinId)throws MapperException, NotLoggedInException;
	User findUserByID(int ID)throws MapperException, NotLoggedInException;
	Vector<User> findAllUsers() throws MapperException, NotLoggedInException;
	User findUserByNickname(String nn) throws MapperException, NotLoggedInException;
	User findByEmail(User u) throws MapperException, NotLoggedInException;

	
	//Pinboard
//	void addPinboard(Pinboard pinbord);
	void deletePinboard(int pinboardID)throws MapperException, NotLoggedInException;
	int findPinboardIDByUserID(int userid) throws MapperException, NotLoggedInException;
	
	
	//NewsFeed
	Vector<Post> getPostForNewsFeed(User u)throws MapperException, NotLoggedInException;
	
	
	//
	String[] verifyField(String[] arr);
	
}
