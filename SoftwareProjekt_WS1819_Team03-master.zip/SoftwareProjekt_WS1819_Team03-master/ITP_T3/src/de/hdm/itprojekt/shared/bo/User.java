package de.hdm.itprojekt.shared.bo;

import java.sql.Timestamp;

public class User extends BusinessObject {

	private static final long serialversionUID = 1l;

	private String firstName;
	private String lastName;
	private String nickName;
	private Boolean isUserKnown = false;
	private Boolean isLoggedIn = false;
	private String loginURL = null;
	private String logoutURL = null;
	private String email = null;


	public User() {
		// TODO Auto-generated constructor stub
	}
	
//	Bei Registrierung (Schritt 1/2) verwendet
	public User(int id) {
		super(id);
	}

	public User(int id, Timestamp date, String first, String last, String nick) {
		super(id, date);

		this.firstName = first;
		this.lastName = last;
		this.nickName = nick;
	}
	
	public User(int id, Timestamp date, String first, String last, String nick, String email) {
		super(id, date);

		this.firstName = first;
		this.lastName = last;
		this.nickName = nick;
		this.email = email;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	
	public Boolean getIsUserKnown() {
		return isUserKnown;
	}

	public void setIsUserKnown(Boolean isUserKnown) {
		this.isUserKnown = isUserKnown;
	}

	public Boolean getIsLoggedIn() {
		return isLoggedIn;
	}

	public void setIsLoggedIn(Boolean isLoggedIn) {
		this.isLoggedIn = isLoggedIn;
	}

	public String getLoginURL() {
		return loginURL;
	}

	public void setLoginURL(String loginURL) {
		this.loginURL = loginURL;
	}

	public String getLogoutURL() {
		return logoutURL;
	}

	public void setLogoutURL(String logoutURL) {
		this.logoutURL = logoutURL;
	}
	
	

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String toString() {
		return firstName + " " + lastName + " // " + nickName;
	}

}
