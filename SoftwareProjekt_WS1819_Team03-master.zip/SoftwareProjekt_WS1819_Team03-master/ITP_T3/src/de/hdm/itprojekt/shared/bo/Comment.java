package de.hdm.itprojekt.shared.bo;

import java.sql.Timestamp;

public class Comment extends BusinessObject {

	private static final long serialversionUID = 1l;

	private String text;
	private int authorID;
	private String authorNickName;
	private int postID;

	public Comment() {
		// TODO Auto-generated constructor stub
	}

//	Konstruktor für Objekt zu Tupel
	public Comment(int id, Timestamp date, String text, int authID, int postID) {
		super(id, date);

		this.text = text;
		this.authorID = authID;
		this.postID = postID;
	}
	
	public Comment(int id, Timestamp date, Timestamp deletionDate, String text, int authID, int postID) {
		super(id, date, deletionDate);

		this.text = text;
		this.authorID = authID;
		this.postID = postID;
	}
	
//	Konstruktor für Tupel zu Objekt
	public Comment(int id, Timestamp date, String text, int authID, int postID, String aNN) {
		super(id, date);

		this.text = text;
		this.authorID = authID;
		this.postID = postID;
		
		this.authorNickName= aNN;
		
	}
	
	public Comment(String text, int authID, int postid) {
		this.text = text;
		this.authorID = authID;
		this.postID = postid;
	}
	

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public int getAuthorID() {
		return authorID;
	}
	
	public String getAuthorNickName() {
		return authorNickName;
	}
	
	public void setAuthorNickName(String authNN) {
		this.authorNickName= authNN;
	}

	public int getPostID() {
		return postID;
	}

}
