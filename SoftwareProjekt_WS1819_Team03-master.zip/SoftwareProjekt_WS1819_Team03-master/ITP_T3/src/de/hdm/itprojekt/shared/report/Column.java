package de.hdm.itprojekt.shared.report;

import java.io.Serializable;

public class Column implements Serializable {
	
	 private static final long serialVersionUID = 1L;
	 
	 /**
	  * Der Inhalt eines Column-Objekts entspricht dem Zelleneintrag einer <code>SimpleReport</code>-Tabelle.
	  * In diesem Fall handelt es sich beim Inhalt um einen rein textuellen Wert. 
	  */
	 private String value = "";
	 
	 /**
	   * Konstruktor, der den Inhalt eines Wertes (Spalteneitrag) erzwingt.
	   * 
	   * @param s ist der Inhalt, der durch das Column-Objekt dargestellt werden soll.
	   */
	 public Column (String s) {
		 this.value = s;
	 }
	 
	 /**<p>
	  * Serialisierbare Klassen, die mittels GWT-RPC transportiert werden sollen, m�ssen einen 
	  * No-Argument-Konstruktor besitzen. Da wir (siehe oben) einen eigenen Konstruktor erstellt haben, 
	  * wird der Default-Konstruktor, welche auch ein No-Argument-Konstruktor ist, �berschrieben.
	  * Aus diesem Grund muss zus�tzlich ein No-Argument-Konstruktor implementiert werden.
	  * </p>
	  */
	 public Column() {
		 //No-Argument
	 }

	 
	/**
	 * Auslesen des Wertes in der Zelle
	 * @return der Eintrag als String-Wert
	 */
	public String getValue() {
		return value;
	}

	/**
	 * Setzen bzw. �berschreiben des aktuellen Wertes in der Zelle
	 * 
	 * @param value neuer Spaltenwert
	 */
	public void setValue(String value) {
		this.value = value;
	}
	
	/**
	 * Umwandeln des <code>Column</code>-Objekts in einen String-Wert
	 */
	@Override
	public String toString() {
		return this.value;
	}
	 

}
