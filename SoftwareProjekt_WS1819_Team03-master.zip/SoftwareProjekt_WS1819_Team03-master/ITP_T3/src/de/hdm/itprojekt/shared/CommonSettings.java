package de.hdm.itprojekt.shared;

public class CommonSettings {

}
