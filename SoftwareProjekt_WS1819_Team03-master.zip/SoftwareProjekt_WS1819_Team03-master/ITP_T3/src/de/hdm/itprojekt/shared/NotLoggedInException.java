package de.hdm.itprojekt.shared;

import java.io.Serializable;

import de.hdm.itprojekt.shared.bo.User;

//Compiled als extends Throwable nicht, da eine checkedException vorliegen muss (Throwable kann auch Error sein).
//public class NotLoggedInException extends Throwable implements Serializable {


public class NotLoggedInException extends Exception implements Serializable {
	User clientBoUser= new User();
	
	  public NotLoggedInException() {
		    super();
		  }
	  
	  public NotLoggedInException(String message) {
		  super(message);
	  }

}
