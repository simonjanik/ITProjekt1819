package de.hdm.itprojekt.shared;

import java.util.Date;


import java.util.Vector;
import java.sql.Timestamp;

import com.google.gwt.user.client.rpc.AsyncCallback;
//import java.time.Period;
import com.google.gwt.user.client.rpc.RemoteService;
import com.google.gwt.user.client.rpc.RemoteServiceRelativePath;
import com.google.gwt.user.client.ui.HTML;

import de.hdm.itprojekt.shared.bo.User;
import de.hdm.itprojekt.shared.report.CommentReport;
import de.hdm.itprojekt.shared.report.CompositeReport;
import de.hdm.itprojekt.shared.report.LikeReport;
import de.hdm.itprojekt.shared.report.PostReport;
import de.hdm.itprojekt.shared.report.ReportHeader;
import de.hdm.itprojekt.shared.report.SimpleReport;
import de.hdm.itprojekt.shared.report.SubReport;



@RemoteServiceRelativePath("report")
public interface ReportAdministration extends RemoteService{
		

		/**
		 * Initializing the Object.
		 * This Method is necessary for GWT RPC and it must be called right after the instantiation.
		 * @throws IllegalArgumentException
		 */
		  public void init() throws IllegalArgumentException;
		  
		  public CompositeReport getReport(Vector<String> choosenUsers, 
				  		Timestamp choosenStartDate, Timestamp choosenEndDate, 
				  		Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
				  		Vector<SimpleReport> choosenReports, User clientUser) throws MapperException, NotLoggedInException; 
		  
		  public abstract LikeReport createLikeReport1 (User u, 
				  Timestamp chosenStartDate, Timestamp chosenEndDate,
				  Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) 
						throws MapperException;
		  
		  public abstract LikeReport createLikeReport2 (User u, 
				  Timestamp chosenStartDate, Timestamp chosenEndDate,
				  Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) 
						throws MapperException;
		  
		  public abstract SubReport createSubReport1 (User u, 
				  Timestamp chosenStartDate, Timestamp chosenEndDate,
				  Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException;
		  
		  public abstract SubReport createSubReport2 (User u, 
				  Timestamp chosenStartDate, Timestamp chosenEndDate,
				  Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException;
		  
		  public abstract PostReport createPostReport1 (User u, 
				  Timestamp chosenStartDate, Timestamp chosenEndDate,
				  Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException;
		  
		  public abstract CommentReport createCommentReport1 (User u, 
				  Timestamp chosenStartDate, Timestamp chosenEndDate,
				  Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException;
		  
		  public abstract CommentReport createCommentReport2 (User u, 
				  Timestamp chosenStartDate, Timestamp chosenEndDate,
				  Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS) throws MapperException;

		  
  
		  
		  
}
