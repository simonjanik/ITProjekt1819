package de.hdm.itprojekt.shared.report;

import java.io.Serializable;
import java.util.ArrayList;

public class CompositeReport extends Report implements Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	/**
	 * Diese Klasse stellt einen zusammengesetzten Report dar,
	 * welcher aus mehreren <code>SimpleReport</code>-Objekten besteht.
	 * 
	 */
	
	/**
	 * ArrayList, in der alle (Sub) <code>SimpleReport</code>-Objekte gespeichert werden.
	 */
	private ArrayList<SimpleReport> simpleReports = new ArrayList<SimpleReport>();
	
	/**
	 * Methode um ein <code>SimpleReport</code>-Objekt zu dem <code>CompositeReport</code>-Objekt
	 * hinzuzuf�gen.
	 * @param sr als das SimpleReport-Objekt, das hinzugef�gt werden soll.
	 */
	public void addsimpleReport(SimpleReport sr)
	{
		this.simpleReports.add(sr);
	}
	
	/**
	 * L�schen eines SimpleReport-Objekts aus dem CompositeReport.
	 * @param sr als das zu l�schende Element.
	 */
	public void removeSimpleReport(SimpleReport sr)
	{
		this.simpleReports.remove(sr);
	}
	
	/**
	 * Anzahl aller SimpleReports in dem CompositeReport auslesen.
	 * @return
	 */
	public int getNumberOfSimpleReports()
	{
		return this.simpleReports.size();
	}
	
	/**
	 * Auslesen eines bestimmten SimpleReport-Objektes 
	 * @param i ist der Index des gewollten Elements.
	 * @return das Element an der Stelle i, wobei 0 <= i <= n, wobei n = Anzahl aller Elemente
	 */
	public SimpleReport getElementAt(int i)
	{
		return this.simpleReports.get(i);
	}
	
	
	

}
