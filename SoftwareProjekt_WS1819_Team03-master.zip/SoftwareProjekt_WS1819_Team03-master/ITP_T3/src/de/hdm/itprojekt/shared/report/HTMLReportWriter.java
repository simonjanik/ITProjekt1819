package de.hdm.itprojekt.shared.report;

import java.util.ArrayList;

public class HTMLReportWriter {

	/**
	 * Ein ReportWriter, der Reports mit HTML formatiert.
	 * 
	 */

	/**
	 * Variable um das Ergebnis abzuspeichern.
	 */
	private String reportText = "";

	/**
	 * Methode zum Zur�cksetzen bzw. leeren des Strings
	 */
	public void resetReportText() {
		this.reportText = "";
	}

	public String getReportText() {
		return this.reportText;
	}

	/**
	 * Jedes HTML f�ngt so an.
	 * 
	 * @return Beginn des HTML Codes
	 */
	public String getHTMLStart() {
		return "<html><head><title></title></head><body>";
	}

	/**
	 * Jedes HTML endet mit diesem code.
	 * 
	 * @return Ende des HTML Codes.
	 */
	public String getHTMLEnd() {
		return "</body></html>";
	}

	/**
	 * Umwandeln eines <code>Paragraph</code>-Objektes (Also
	 * <code>SimpleParagraph</code> oder <code>CompositeParagraph</code> in einen
	 * String in Form von HTML
	 * 
	 * @param p ist der Umzuwandelnde Paragraph
	 * @return String, der den neuen HTML Text beinhaltet
	 */
	public String paragraphToHTML(Paragraph p) {
		if (p instanceof SimpleParagraph) {
			return this.paragraphToHTML((SimpleParagraph) p);
		}

		else {
			return this.paragraphToHTML((CompositeParagraph) p);
		}

	}

	public String paragraphToHTML(SimpleParagraph sp) {
		reportText = "<p>" + sp.toString() + "</p>";
		return reportText;
	}

	public String paragraphToHTML(CompositeParagraph cp) {
		StringBuffer result = new StringBuffer();

		for (int i = 0; i < cp.getNumberOfParagraphs(); i++) {
			reportText = paragraphToHTML(cp.getElementAt(i));
			result.append(reportText + "/n");
			reportText = "";
		}
		return result.toString();

	}

	public void simpleReportProcess(SimpleReport sr) {
		StringBuffer result = new StringBuffer();

		result.append("<table class=\"SimpleReportTabelle\">");

		if (sr.getHeaderData() != null) {
			result.append("<hr><br>");

			ArrayList<SimpleParagraph> headerDataSP = sr.getHeaderData().getAllSimpleParagraphs();
			for (int i = 0; i < headerDataSP.size(); i++) {
				SimpleParagraph tempSP = headerDataSP.get(i);

				result.append("<tr>");
				result.append("<td class=\"SimpleReportHeaderData\"><b>" + tempSP.getValue() + "</b></td>");
				result.append("</tr>");

			}
		}

		// Hinzufügen der Zeilen in HTML Form
		if (sr.getRows() != null) {
			ArrayList<Row> alleZeilen = sr.getRows();
			for (int i = 0; i < alleZeilen.size(); i++) {
				Row row = alleZeilen.get(i);

				result.append("<tr>");

				for (int j = 0; j < row.getNumberOfColumns(); j++) {
					result.append("<td class=\"ReportSpaltenInhalt\">" + row.getColumnAt(j) + "</td>");
				}

				result.append("</tr>");
			}
		}
		result.append("</table>");

		// Gesamtes Ergbnis in String speichern
		this.reportText = result.toString();

	}

//	David	
	public void process(CompositeReport cR) {
		StringBuffer result = new StringBuffer();
		this.resetReportText();

		if (cR.getHeaderData() != null) {
			ArrayList<SimpleParagraph> headerDataCP = cR.getHeaderData().getAllSimpleParagraphs();
			for (int i = 0; i < headerDataCP.size(); i++) {
				SimpleParagraph tempCP = headerDataCP.get(i);

				result.append("<tr>");
				result.append("<td class=\"CompositeReportHeaderData\"><b>" + tempCP.getValue() + "</b></td>");
				result.append("</tr>");
				result.append("<br>");

			}

			result.append("<br><hr><br>");

		}

		for (int i = 0; i < cR.getNumberOfSimpleReports(); i++) {
			simpleReportProcess(cR.getElementAt(i));
			result.append(reportText);
			result.append("<br>");
		}
		reportText = result.toString();

	}

}
