package de.hdm.itprojekt.shared;

import java.util.Date;


import java.util.Vector;
import java.sql.Timestamp;

//import java.time.Period;

import com.google.gwt.user.client.rpc.AsyncCallback;
import com.google.gwt.user.client.ui.HTML;

import de.hdm.itprojekt.shared.bo.User;
import de.hdm.itprojekt.shared.report.CommentReport;
import de.hdm.itprojekt.shared.report.CompositeReport;
import de.hdm.itprojekt.shared.report.LikeReport;
import de.hdm.itprojekt.shared.report.PostReport;
import de.hdm.itprojekt.shared.report.ReportHeader;
import de.hdm.itprojekt.shared.report.SimpleReport;
import de.hdm.itprojekt.shared.report.SubReport;

public interface ReportAdministrationAsync {

	
	void init(AsyncCallback<Void> callback);
	
	void getReport(Vector<String> choosenUsers, 
			Timestamp choosenStartDate, Timestamp choosenEndDate, 
			Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			Vector<SimpleReport> choosenReports, User clientUser, 
			AsyncCallback<CompositeReport> callback); 

	void createLikeReport1(User u, 
			Timestamp chosenStartDate, Timestamp chosenEndDate, 
			 Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			 AsyncCallback<LikeReport> callback);

	void createLikeReport2(User u, 
			Timestamp chosenStartDate, Timestamp chosenEndDate, 
			 Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			 AsyncCallback<LikeReport> callback);
	
	void createSubReport1(User u, 
			Timestamp chosenStartDate, Timestamp chosenEndDate, 
			 Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			 AsyncCallback<SubReport> callback);
	
	void createSubReport2(User u, 
			Timestamp chosenStartDate, Timestamp chosenEndDate, 
			 Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			 AsyncCallback<SubReport> callback);
	
	void createPostReport1(User u, 
			Timestamp chosenStartDate, Timestamp chosenEndDate, 
			 Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			 AsyncCallback<PostReport> callback);
	
	void createCommentReport1(User u, 
			Timestamp chosenStartDate, Timestamp chosenEndDate, 
			 Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			 AsyncCallback<CommentReport> callback);
	
	void createCommentReport2(User u, 
			Timestamp chosenStartDate, Timestamp chosenEndDate, 
			 Timestamp choosenStartDatePl1TS, Timestamp choosenEndDatePl1TS,
			 AsyncCallback<CommentReport> callback);



}
